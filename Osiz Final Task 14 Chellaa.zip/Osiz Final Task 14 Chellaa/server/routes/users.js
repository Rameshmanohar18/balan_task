var express = require("express");
var router = express.Router();
const multer = require("multer");
const User = require("../model/userModel");

//Controllers
const userController = require('../controllers/userController');
const ticketController = require('../controllers/ticketController');
const reportController = require('../controllers/reportController')


//userRoutes
router.get("/", userController.get);

router.post("/", userController.post);

router.post("/verifiedUser", userController.verifiedUser);

router.get("/fetchuser/:id", userController.fetchUserbyID);

router.delete("/deleteuser/:id",userController.deleteUser);

router.put("/updateuser/:id", userController.updateUser);

router.post("/login", userController.login);
router.post("/loginOtp", userController.loginOtp);

router.get("/getSingle", userController.getSingle);

router.post("/forgetPwd", userController.forgetPwd);
router.post("/setNewPwd", userController.setNewPwd);
router.post("/changeNewPwd", userController.changeNewPwd);

router.post("/kyc/:id", userController.kyc);

//Tickets
router.post("/tickets/:id", ticketController.tickets);
router.get("/gettickets", ticketController.gettickets);
router.delete("/deleteticket/:id", ticketController.deleteticket);
// router.post("/updateticket/:id", ticketController.updateticket);
router.post("/updateticket/:id", ticketController.updateticket);
router.get("/getticketbyid/:id", ticketController.getticketbyid);
router.get("/getticketreplies", ticketController.getticketreplies);
router.post("/updateuserReply/:id", ticketController.updateuserReply);

//Reports
router.post("/reports/:id", reportController.reports);
router.get("/getreports", reportController.getreports);
router.delete("/deletereport/:id", reportController.deletereport);
router.get("/getreportbyid/:id", reportController.getreportbyid);
router.post("/updatereport/:id", reportController.updatereport);
router.post("/addreply/:id", reportController.addreply);
router.get("/getreportreplies", reportController.getreportreplies);


module.exports = router;
