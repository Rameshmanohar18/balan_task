var express = require("express");
var router = express.Router();

const adminController = require('../controllers/adminController');
const projectController = require('../controllers/projectController');
const contentController = require('../controllers/contentController');
const passwordController = require('../controllers/passwordController');

router.post("/", adminController.post);
// router.get("/", adminController.get);
router.post("/login", adminController.login);
router.get("/regadmins", adminController.regadmins);


//CONTENTS ENDPOINTS
router.post("/contents", contentController.contents);
router.get("/getcontents", contentController.getcontents);
router.get("/getcontent/:id", contentController.getcontent);
router.post("/updatecontent/:id", contentController.updatecontent);

router.get("/getreport/:id", adminController.getreport);


//PROJECTS ENDPOINTS
router.post("/projects", projectController.projects);
router.get("/getprojects", projectController.getprojects);
router.post("/updateproject/:id", projectController.updateproject);

//KYC UPDATE 
router.post("/kycupdate/:id", adminController.kycupdate);

//Admin deatils 
router.get("/adminDetails", adminController.getAdminDetails);

//2FA
router.post("/twoFactorAuth/getSecertKey",adminController.getTwoFactorAuthentication)
router.post("/twoFactorAuth/verifySecret",adminController.verifyTwoFactorAuthentication)
router.post("/twoFactorAuth/disableAuthCode",adminController.disableTwoFactorAuthentication)

router.post("/loginauth/verify",adminController.logInAuthVerification)
router.get("/getQr/:email", adminController.getQr);

//Change Password 
router.post("/generateOtp", passwordController.generateOtp)
router.post("/setNewPwd", passwordController.setNewPwd)
router.post("/setNewPattern", passwordController.setNewPattern)
router.post("/changeAdminPwd", passwordController.changeAdminPassword)
router.post("/changeAdminPattern", passwordController.changeAdminPattern)

module.exports = router;