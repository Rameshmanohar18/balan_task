const jwt = require('jsonwebtoken');
require('dotenv').config(); 

const verifyToken = (token) => {
  try {
    
    if (!token || !token.startsWith('Bearer ')) {
      return { error: "Unauthorized: No token provided" };
    }
    const tokenValue = token.split(' ')[1];
    // console.log(tokenValue);

    //secret Key
    const secretKey = "ygihih@#^gfj4535tst";

    const decoded = jwt.verify(tokenValue, secretKey);
    // console.log(decoded);

    return { decoded };
  } catch (error) {
    return { error: "Unauthorized: Invalid token" };
  }
};

module.exports = { verifyToken };
