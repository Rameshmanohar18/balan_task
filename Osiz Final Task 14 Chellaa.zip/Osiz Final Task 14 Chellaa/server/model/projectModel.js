const mongoose = require("mongoose");

const projectSchema = new mongoose.Schema(
  {
    projectName: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      required: true,
    },
    createdBy: {
      type: String,
      required: true,
    },
    createdAt: { type: Date },
  },
  {
    collection: "projects",
  }
);

const Project = mongoose.model("Project", projectSchema);

module.exports = Project;
