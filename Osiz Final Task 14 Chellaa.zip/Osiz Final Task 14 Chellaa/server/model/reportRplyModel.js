const mongoose = require("mongoose");

const reportReplySchema = new mongoose.Schema(
  {
    reportId: { type: String },

    repliedAt: { type: Date, default: "" },
    userComment: { type: String, default: "" },
  },
  {
    collection: "ReportReplies",
  }
);

const ReportReply = mongoose.model("ReportReply", reportReplySchema);

module.exports = ReportReply;
