const mongoose = require("mongoose");

const reportSchema = new mongoose.Schema(
  {
    department: String,
    type: String,
    status: String,
    subject: String,
    description: String,
    notify: String,
    upload: String,
    createdAt: { type: Date },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    adminComment: { type: String, default: "" },
    adminReplyStatus:  { type: Boolean, default: false },
    repliedAt: { type: Date, default: "" },
    userReply:  { type: String, default: "" },
    userReplyStatus:  { type: Boolean, default: false },
  },
  {
    collection: "reports",
  }
);
const Report = mongoose.model("Report", reportSchema);

module.exports = Report;
