const mongoose = require("mongoose");

const contentSchema = new mongoose.Schema(
  {
    content: {
      type: String,
      lowercase: true,
      required: true,
      // trim: true
    },
    editorData: {
      type: String,
      required: true,
    },
  },
  {
    collection: "contents",
  }
);

const Content = mongoose.model('Content', contentSchema);

module.exports = Content;