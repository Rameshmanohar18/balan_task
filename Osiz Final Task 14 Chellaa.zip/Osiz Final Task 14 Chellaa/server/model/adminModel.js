const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    pattern: {
      type: String,
      required: true,
    },
    temp_secret: {
      type: Object,
    },
    secret: {
      type: Object,
    },
    twoFactorAuth: {
      type: Boolean,
      default: false,
    },
   
  },
  { collection: "admin" }
);

const Admin = mongoose.model("Admin", adminSchema);

module.exports = Admin;
