const mongoose = require("mongoose");

const ticketSchema = new mongoose.Schema(
  {
    department: String,
    type: String,
    status: String,
    subject: String,
    description: String,
    notify: String,
    upload: String,
    createdAt: { type: Date },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    // adminComment: { type: String, default: "" },
    // repliedAt: { type: Date, default: "" },
  },
  {
    collection: "tickets",
  }
);

const Ticket = mongoose.model("Ticket", ticketSchema);

module.exports = Ticket;
