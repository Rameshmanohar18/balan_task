const mongoose = require("mongoose");


const replySchema = new mongoose.Schema(
    {
      ticketId : { type: String },
      adminComment: { type: String, default: "" },
      repliedAt: { type: Date, default: "" },
     userComment: { type: String, default: "" },
     userRepliedAt: { type: Date, default: "" },
    },
    {
      collection: "replies",
    }
  );
  
  const Reply = mongoose.model("Reply", replySchema);
  
  module.exports = Reply;