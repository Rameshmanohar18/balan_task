const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    username: {
      type: String,
      required: true,
      unique: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    profilePic: {
      type: String,
    },
    acceptTerms: {
      type: Boolean,
      required: true,
    },
    address: {
      mobile: {
        type: String,
      },
      addressLine1: {
        type: String,
      },
      addressLine2: {
        type: String,
      },
      country: {
        type: String,
      },
      pincode: {
        type: String,
      },
    },

    kyc: {
      accountNo: String,
      proofType: String,
      username: String,
      email: String,
      mobile: String,
      address: String,
      upload: {
        frontProof: {
          type: String,
        },
        backProof: {
          type: String,
        },
        frontSideStatus: {
          type: String,
          default: "pending",
        },
        backSideStatus: {
          type: String,
          default: "pending",
        },
      },
      isApproved: {
        type: Boolean,
        default: false,
      },
    
      adminComment: { type: String, default: "" },
      repliedAt: { type: Date, default: "" },
      userLastUpdate: { type: Date, default: "" },
      userUpdateStatus: { type: Boolean, default: false },
    },
  
  },
  {
    collection: "users",
  }
);

const User = mongoose.model("User", userSchema);

module.exports = User;
