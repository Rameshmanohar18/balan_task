const Content = require("../model/contentModel");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const { verifyToken } = require("../middlewares/verifyToken");
require("dotenv").config();
const multer = require("multer");
const path = require("path");
const { generateOTP } = require('../middlewares/otpGenerator')
const speakEasy = require('@levminer/speakeasy')
const qrCode = require('qrcode')


const User = require("../model/userModel");
const Admin = require("../model/adminModel");

//admin reg
exports.post = async (req, res) => {
  try {
   console.log(req.body.formData);
    const username = req.body.formData.username
    const email = req.body.formData.email 
    const password = req.body.formData.password 
    const pattern = req.body.formData.pattern 
    const patternString = JSON.stringify(pattern);

    const newAdmin = new Admin({
      username,
      email,
      password,
      pattern: patternString,
    })
    await newAdmin.save();
    res.status(201).json({ message: "Admin created successfully" });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Verification failed", error: error.message });
  }
};

//admin login
exports.login = async (req, res) => {
  try {
  //  console.log(req.body.formData);

    const email = req.body.formData.email 
    const password = req.body.formData.password 
    const pattern = req.body.formData.pattern 
    const patternString = JSON.stringify(pattern);

    const admin = await Admin.findOne({ email });

    // Check if the admin user exists
    if (!admin) {
      throw new Error("Incorrect email");
    }

    // Compare the provided password with the hashed password stored in the database
        
    if (admin.password != password) {
      throw new Error("Incorrect  password");
    }
   
    if(admin.pattern !== patternString){
      throw new Error("Incorrect pattern!");
    }

    const jwtToken = jwt.sign(
      { id: admin._id },
      "ygihih@#^gfj4535tst",
      { expiresIn: '1hr' }
    );

    res.status(201).json({ message: "Loginsuccessfully", email: email, admin: admin, token: jwtToken });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Verification failed", error: error.message });
  }
};

//reg admins
exports.regadmins = async (req, res) => {
  try {
    await Admin.find({})
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    console.log(error);
  }
};

//Get Admin Details
exports.getAdminDetails = async (req, res) => {
  try {
    const token = req.headers.authorization;
   

    const tokenVerification = verifyToken(token);

    if (tokenVerification.error) {
      return res.status(401).json({ message: tokenVerification.error });
    }

    const { decoded } = tokenVerification;

    const userID = decoded.id;
    // console.log(userID);

    const foundUser = await Admin.findOne({ _id: userID });

    if (!foundUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ data: foundUser });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching user", error: error.message });
  }
};

//Get Reports 
exports.getreport = async (req, res) => {
  try {
    const reportID = req.params.id;
    // console.log(ticketID);

    const xUsername = req.headers["x-username"];
    // console.log(xUsername);

    const user = await User.findOne({ username: xUsername });
    // console.log(user);

    const report = user.reports.find((report) => report._id == reportID);
    // console.log(ticket);

    if (report) {
      return res.status(200).json({ report });
    }

    if (!report) {
      return res.status(400).json({ message: "ticket not found!" });
    }
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

//Kyc Update

exports.kycupdate = async (req, res) => {
  try {
    const userID = req.params.id;
    const { frontSideStatus, backSideStatus, editorData } = req.body.formData;

    console.log(req.body);

    const updatedUser = await User.findByIdAndUpdate(
      { _id: userID },
      {
        $set: {
          "kyc.upload.frontSideStatus": frontSideStatus,
          "kyc.upload.backSideStatus": backSideStatus,
          "kyc.adminComment": editorData,
          "kyc.repliedAt": new Date(),
          "kyc.userUpdateStatus": false
        },
      }
    );

    if (updatedUser) {
      // Check if both frontSideStatus and backSideStatus are "Approved"
      if (frontSideStatus === "Approved" && backSideStatus === "Approved") {
        // If both are approved, update the kyc.isApproved field to true
        updatedUser.kyc.isApproved = true;
        await updatedUser.save();
      }

      return res.status(200).json({ message: "KYC details updated successfully", user: updatedUser });

  
    } else{
      return res.status(400).json({ message: "KYC details not found" });
    }
  } catch (error) {
    res.status(400).json({ message: "Kyc Update failed", error: error.message });
  }
};


//2FA
exports.getTwoFactorAuthentication = async (req, res) => {
  try {
   console.log(req.body.body);
   const email = req.body.body
      
      const secretCode = speakEasy.generateSecret()
      await Admin.updateOne({ email: email}, { $set: { temp_secret: secretCode } })
      const twoFactorAuthData = await Admin.findOne({ email: email })
      
      // generating QrCode Img Src
      qrCode.toDataURL(twoFactorAuthData.temp_secret.otpauth_url, function (err, data) {
          if (err) {
              return res.status(404).json({ message: 'Generating QrCode Error' })
          }
          res.status(200).json({ message: 'Generate TwoFactorAuth', twoFactorAuthData, qrCodeImgSrc: data })
      })

  } catch (error) {
      res.status(500).json({ message: 'Something Went Wrong' })
  }
}


exports.verifyTwoFactorAuthentication = async (req, res) => {
  try {
    const { email, token } = req.body;
    const getUser = await Admin.findOne({ email: email });

    console.log("Temp Secret from Database:", getUser.temp_secret);

    if (!getUser || !getUser.temp_secret) {
      return res.status(401).json({ message: 'User or temp_secret not found' });
    }

    const { base32: secret } = getUser.temp_secret;

    console.log("Base32 Secret:", secret);
    console.log("Received Token:", token);

    let tokenValidates = speakEasy.totp.verify({
      secret,
      encoding: 'base32',
      token,
    });

    console.log("Token Validation Result:", tokenValidates);

    if (!tokenValidates) {
      return res.status(401).json({ message: 'Authentication Invalid Token' });
    }

  

    await Admin.updateOne(
      { email: email },
      { $set: { temp_secret: null, secret: getUser.temp_secret, twoFactorAuth: true } }
    );

    const updateUser = await Admin.findOne({ email: email });
    res.status(200).json({
      message: '2FA Enabled',
      twoFactorAuth: updateUser.twoFactorAuth,
 
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error Generating Authentication' });
  }
};


exports.disableTwoFactorAuthentication = async (req, res) => {
  try {
    const { email } = req.body;
    
    // Reset temp_secret to null when disabling two-factor authentication
    await Admin.updateOne({ email: email }, { $set: { temp_secret: null, secret: null, twoFactorAuth: false } });

    res.status(200).json({ message: '2FA disabled' });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error Disabling Your Authentication' });
  }
};


// 2FA LOGIN
exports.logInAuthVerification = async (req, res) => {
  // console.log(req.body);
  try {
      const { email, token } = req.body

      const admin = await Admin.findOne({ email: email })
     
      // console.log(getUser);
      let tokenValidates = speakEasy.totp.verify({
          secret: admin.secret.base32,
          encoding: "base32",
          token,
      })
      let qrCodeVerify = speakEasy.totp.verify({
          secret: admin.secret.ascii,
          encoding: 'ascii',
          token
      })
      if (!qrCodeVerify) {
          return res.status(401).json({ message: 'Authentication Token Invalid' })
      }
      if (!tokenValidates) {
          return res.status(401).json({ message: 'Authentication Invalid Token' })
      }
      const jwtToken = jwt.sign(
        { id: admin._id },
        "ygihih@#^gfj4535tst",
        { expiresIn: '1hr' }
      );
  
      res.status(200).json({ message: 'Authentication Verified', token: jwtToken })

  } catch (err) {
      res.status(500).json({ message: 'Error Generating Authencation verify ', error: err.message })
  }
}

//Get QR image
exports.getQr = async (req, res) => {
  try {
    // console.log(req.params);
    const foundAdmin = await Admin.findOne({ email: req.params.email });
    // console.log(foundAdmin.secret.otpauth_url);
    const otpAuth = foundAdmin.secret.otpauth_url
    const base32 = foundAdmin.secret.base32

     // generating QrCode Img Src
     qrCode.toDataURL(otpAuth, function (err, data) {
      if (err) {
          return res.status(404).json({ message: 'Generating QrCode Error' })
      }
      res.status(200).json({ message: 'Generate TwoFactorAuth', qrCodeImgSrc: data, base32: base32 })
  })

  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};