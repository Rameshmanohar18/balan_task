
const Admin = require("../model/adminModel");
const { generateOTP } = require("../middlewares/otpGenerator")

  //Generate OTP
  exports.generateOtp = async (req, res) => {
    try {
      console.log(req.body);
      const adminMail = req.body.email;

      const existingAdmin = await Admin.findOne({ email: adminMail });
  
      if (!existingAdmin) {
        throw new Error("Admin not found");
      }

      const OTP = generateOTP();
      console.log(OTP);
  
      res.status(200).json({ message: "OTP generated successfully", OTP });
    } catch (error) {
      res.status(400).json({ message: "Something went wrong", error: error.message });
    }
  };
  

  exports.setNewPwd = async (req, res) => {
    try {
      console.log(req.body);
      const adminMail = req.body.adminEmail;
      const updatedPassword = req.body.confirmNewPassword;

      const existingAdmin = await Admin.findOne({ email: adminMail });
  
      if (!existingAdmin) {
        throw new Error("Admin not found");
      }

      const result = await Admin.updateOne(
        { email: adminMail },
        { $set: { password: updatedPassword } }
      );
  
      res.status(200).json({ message: "Password updated successfully", result });


    } catch (error) {
      res.status(400).json({ message: "Something went wrong", error: error.message });
    }
  };

  exports.setNewPattern = async (req, res) => {
    try {
      console.log(req.body);
      const adminMail = req.body.adminEmail;
      const newPattern = req.body.patternTwo;
      const updatedPattern = JSON.stringify(newPattern);
      
      

      const existingAdmin = await Admin.findOne({ email: adminMail });
  
      if (!existingAdmin) {
        throw new Error("Admin not found");
      }

      const result = await Admin.updateOne(
        { email: adminMail },
        { $set: { pattern: updatedPattern } }
      );
  
      res.status(200).json({ message: "Pattern updated successfully", result });


    } catch (error) {
      res.status(400).json({ message: "Something went wrong", error: error.message });
    }
  };


  //CHange admin passwod
  exports.changeAdminPassword = async (req, res) => {
    try {
      console.log(req.body);
      const adminID = req.body.adminID;
      const oldPassword = req.body.password;
      const updatedPassword = req.body.confirmNewPassword;
   
      const existingAdmin = await Admin.findOne({ _id : adminID });
   
      if (!existingAdmin) {
        throw new Error("Admin not found");
      }

      if (oldPassword !== existingAdmin.password) {
        throw new Error("Old password doesn't match!");
      }

      const result = await Admin.updateOne(
        { _id: adminID },
        { $set: { password: updatedPassword } }
      );
  
      res.status(200).json({ message: "Password updated successfully", result });


    } catch (error) {
      res.status(400).json({ message: "Something went wrong", error: error.message });
    }
  };


   //CHange admin pattern
   exports.changeAdminPattern = async (req, res) => {
    try {
      console.log(req.body);
      const adminID = req.body.adminID;
      const oldPattern = req.body.oldPattern;
      const stringOldPattern = JSON.stringify(oldPattern);
      const updatedPattern = req.body.patternTwo;
      const updatedAdminPattern = JSON.stringify(updatedPattern)
   
      const existingAdmin = await Admin.findOne({ _id : adminID });
      
      if (!existingAdmin) {
        throw new Error("Admin not found");
      }



     if (stringOldPattern !== existingAdmin.pattern) {
       throw new Error("Old pattern is incorrect");
     }
 
      const result = await Admin.updateOne(
        { _id: adminID },
        { $set: { pattern: updatedAdminPattern } }
      );
  
      res.status(200).json({ message: "Pattern updated successfully", result });


    } catch (error) {
      res.status(400).json({ message: "Something went wrong", error: error.message });
    }
  };