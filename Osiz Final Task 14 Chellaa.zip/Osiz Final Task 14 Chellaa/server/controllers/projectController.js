const Project = require("../model/projectModel");

exports.projects = async (req, res) => {
  try {
    console.log(req.body.projectData);
    const newProject = new Project({
      projectName: req.body.projectData.projectName,
      type: req.body.projectData.type,
      createdBy: req.body.projectData.createdBy,
      createdAt: new Date(),
    });

    await newProject.save();

    res.status(200).json({ message: "Project Added Successfully!" });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

exports.getprojects = async (req, res) => {
  try {
    await Project.find({})
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

exports.updateproject = async (req, res) => {
  try {
    const { projectName, type, createdBy } = req.body;

    const projectID = req.params.id;

    await Project.findByIdAndUpdate(
      { _id: projectID },
      { $set: { projectName: projectName, type: type, createdBy: createdBy } },
      { new: true }
    );

    res.status(200).json({ message: "Project updated successfully!" });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};
