const User = require("../model/userModel");
const axios = require("axios");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const { verifyToken } = require("../middlewares/verifyToken");
require("dotenv").config();
const multer = require("multer");
const path = require("path");
const mongoose = require("mongoose");
const { generateOTP } = require("../middlewares/otpGenerator")


//Multer Config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "public/uploads");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({
  storage: storage,
  fileFilter: function (req, file, cb) {
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(
      path.extname(file.originalname).toLowerCase()
    );
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb("Error: Images Only!");
    }
  },
}).fields([
  { name: "profilePic", maxCount: 1 },
  { name: "frontProof", maxCount: 1 },
  { name: "backProof", maxCount: 1 },
  { name: "upload", maxCount: 1 },
]);

exports.get = async (req, res) => {
  try {
    await User.find({})
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    console.log(error);
  }
};

//Otp generation function
// const generateOTP = () => {
//   return Math.floor(100000 + Math.random() * 900000).toString();
// };

//Otp will send as response(Register Form)
exports.post = async (req, res) => {
  try {
    const { email } = req.body;

    const emailExists = await User.findOne({ email: email });

    if (emailExists) {
      return res.status(400).json({
        message: "Email already exists. Please use a different email.",
      });
    }

    const otp = generateOTP();

    res.status(200).json({ message: "Email verified successfully", otp });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Verification failed", error: error.message });
  }
};
//registration After Verification
exports.verifiedUser = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res
        .status(400)
        .json({ message: "Image upload failed", error: err });
    }

    try {
      const {
        firstName,
        lastName,
        username,
        email,
        password,
        profilePic,
        acceptTerms,
      } = req.body;

      const emailExists = await User.findOne({ email });

      if (emailExists) {
        return res.status(400).json({
          message: "Email already exists. Please use a different email.",
        });
      }

      const encrptPassword = await bcrypt.hash(password, 10);

      const newUser = new User({
        firstName,
        lastName,
        username,
        email,
        password: encrptPassword,
        profilePic: path.join("uploads/", req.files["profilePic"][0].filename),
        acceptTerms,
  
      });

      const savedUser = await newUser.save();

      console.log('User saved successfully:', savedUser);

      res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
      console.error('Error during user registration:', error.message);
      res.status(400).json({ message: "Registration failed", error: error.message });
    }
  });
};

//Login
exports.loginOtp = async (req, res) => {
  try {
    const { username, password, captchaValue } = req.body;

    // Verify reCAPTCHA
    const recaptchaSecretKey = "6LfVIB4pAAAAAOsZwtq_XK-Fk_3mbBVqdViTigTW"; // Replace with your actual reCAPTCHA secret key
    const recaptchaVerifyUrl = `https://www.google.com/recaptcha/api/siteverify?secret=${recaptchaSecretKey}&response=${captchaValue}`;

    const recaptchaResponse = await axios.post(recaptchaVerifyUrl);
    const recaptchaSuccess = recaptchaResponse.data.success;

    if (!recaptchaSuccess) {
      return res.status(400).json({ message: "reCAPTCHA verification failed" });
    }

    const user = await User.findOne({ username: username });

    if (!user) {
      return res
        .status(400)
        .json({ message: "Login failed! UserName is Invalid" });
    }

    const comparePwd = await bcrypt.compare(password, user.password);

    if (!comparePwd) {
      return res
        .status(400)
        .json({ message: "Login failed! Password is incorrect" });
    }

    const OTP = generateOTP();

    return res.status(201).json({ message: "Otp Send", username, OTP });
  } catch (error) {
    return res
      .status(400)
      .json({ message: "Verification failed", error: error.message });
  }
};

exports.login = async (req, res) => {
  // console.log(req.body);
  try {
    const { username } = req.body;
    // const secretKey = process.env.SECRET_KEY;

    // if (email == "admin@mail.com" && password == "123") {
    //   const adminToken = jwt.sign({ role: "admin" }, secretKey, {
    //     expiresIn: "1hr",
    //   });
    //   return res.status(201).json({
    //     token: adminToken,
    //     message: "Admin login success",
    //   });
    // }

    const user = await User.findOne({ username: username });

    if (!user) {
      res.status(400).json({ message: "Login failed!", error: error.message });
    } else {
      const secretKey = "ygihih@#^gfj4535tst";

      const token = jwt.sign(
        {
          data: user._id,
        },
        secretKey,
        { expiresIn: "1hr" }
      );

      res.status(201).json({ token, message: "login Success" });
    }
  } catch (error) {
    res.status(400).json({
      message: "Login failed! Incorrect UserName or Password",
      error: error.message,
    });
  }
};

//Update User
exports.updateUser = async (req, res) => {
  // console.log(req.body);
  // console.log(req.params.id);
  upload(req, res, async (err) => {
    if (err) {
      return res
        .status(400)
        .json({ message: "Image upload failed", error: err });
    }
    try {
      const {
        firstName,
        lastName,
        email,
        username,
        mobile,
        addressLine1,
        addressLine2,
        pincode,
        country,
        profile,
      } = req.body;

      const updateObject = {
        firstName: firstName,
        lastName: lastName,
        email: email,
        username: username,
        address: {
          mobile: mobile,
          addressLine1: addressLine1,
          addressLine2: addressLine2,
          pincode: pincode,
          country: country,
        },
      };

      // Check if profilePic is sent from the frontend
      if (req.files["profilePic"]) {
        updateObject.profilePic = path.join(
          "uploads/",
          req.files["profilePic"][0].filename
        );
      }

      const result = await User.findByIdAndUpdate(
        { _id: req.params.id },
        updateObject
      );
      res.status(200).json({ message: "User updated successfully", result });
    } catch (error) {
      res.status(400).json({ message: "Request failed", error: error.message });
    }
  });
};

exports.getSingle = async (req, res) => {
  try {
    const token = req.headers.authorization;

    const tokenVerification = verifyToken(token);

    if (tokenVerification.error) {
      return res.status(401).json({ message: tokenVerification.error });
    }

    const { decoded } = tokenVerification;

    const userID = decoded.data;

    const foundUser = await User.findOne({ _id: userID });

    if (!foundUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ data: foundUser });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching user", error: error.message });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const ID = req.params.id;
    await User.deleteOne({ _id: ID })
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    console.log(error);
  }
};

exports.fetchUserbyID = async (req, res, next) => {
  try {
    const ID = req.params.id;
    await User.findOne({ _id: ID })
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    console.log(error);
  }
};

//ForgotPasswrd
exports.forgetPwd = async (req, res) => {
  try {
    const { email } = req.body;

    const emailExists = await User.findOne({ email: email });

    const OTP = generateOTP();

    if (emailExists) {
      return res.status(200).json({ otp: OTP });
    } else {
      return res.status(400).json({ msg: "Invalid Email" });
    }
  } catch (error) {
    res
      .status(400)
      .json({ message: "Registration failed", error: error.message });
  }
};

//SET NEW PASSWORD
exports.setNewPwd = async (req, res) => {
  // console.log(req.body.userEmail);
  try {
    const userMail = req.body.userEmail;
    const newPassword = req.body.data.confirmPassword;

    const user = await User.findOne({ email: userMail });

    if (!user) {
      return res.status(400).json({ error: "Invalid User!" });
    }

    const encrptPassword = await bcrypt.hash(newPassword, 10);

    const result = await User.findByIdAndUpdate(
      { _id: user._id },
      {
        password: encrptPassword,
      }
    );
    return res.status(200).json({
      message: "Password Updated Successfully!",
      result,
    });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something Went Wrong!", error: error.message });
  }
};

//CHANGE PASSWORD
exports.changeNewPwd = async (req, res) => {
  // console.log(req.body);
  try {
    const ID = req.body.userID;

    const user = await User.findOne({ _id: ID });

    const comparePwd = await bcrypt.compare(
      req.body.oldPassword,
      user.password
    );

    if (!comparePwd) {
      throw new Error("Old Password is invalid!");
    }

    const newPassword = req.body.confirmPassword;
    const encrptPassword = await bcrypt.hash(newPassword, 10);

    const result = await User.findByIdAndUpdate(
      { _id: user._id },
      {
        password: encrptPassword,
      }
    );
    return res.status(200).json({
      message: "Password Updated Successfully!",
      result,
    });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something Went Wrong!", error: error.message });
  }
};


//kyc 
exports.kyc = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res
        .status(400)
        .json({ message: "Image upload failed", error: err });
    }

    try {
      const userId = req.params.id;
      const { accountNo, proofType, username, email, mobile, address } =
        req.body;

        const user = await User.findById(userId);

        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }
  
        // Access the kyc property from the user document
        const kyc = user.kyc || {};

      const updateFields = {
        $set: {
          "kyc.accountNo": accountNo,
          "kyc.proofType": proofType,
          "kyc.username": username,
          "kyc.email": email,
          "kyc.mobile": mobile,
          "kyc.address": address,
        
          "kyc.isApproved": false,
          "kyc.userLastUpdate": new Date(),
          "kyc.userUpdateStatus": true,
        },
      };

      // Check and update frontProof if available
      if (req.files && req.files["frontProof"]) {
        updateFields.$set["kyc.upload.frontProof"] = path.join(
          "uploads/",
          req.files["frontProof"][0].filename
        );
      }

      // Check and update backProof if available
      if (req.files && req.files["backProof"]) {
        updateFields.$set["kyc.upload.backProof"] = path.join(
          "uploads/",
          req.files["backProof"][0].filename
        );
      }

      if (kyc.upload?.frontSideStatus !== "Approved") {
        updateFields.$set["kyc.upload.frontSideStatus"] = "pending";
      }

      // Check if backSideStatus is not approved
      if (kyc.upload?.backSideStatus !== "Approved") {
        updateFields.$set["kyc.upload.backSideStatus"] = "pending";
      }

      const result = await User.findByIdAndUpdate(
        { _id: userId },
        updateFields,
        { new: true }
      );

      if (result) {
        res.status(200).json({
          message: "KYC details added/updated successfully",
          data: result,
        });
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      res
        .status(400)
        .json({ message: "Registration failed", error: error.message });
    }
  });
};


//REPORTS DETAILS COPY
exports.reports = async (req, res) => {
  // console.log(req.body);
  upload(req, res, async (err) => {
    if (err) {
      return res
        .status(400)
        .json({ message: "Image upload failed", error: err });
    }

    // console.log(req.files);

    try {
      const userId = req.params.id;
      const { department, type, status, subject, description, notify } =
        req.body;

      const user = await User.findOne({ _id: userId });

      if (user) {
        if (!Array.isArray(user.tickets)) {
          user.reports = [];
        }

        const newReport = {
          createdBy: user.username,
          department: department,
          type: type,
          status: status,
          subject: subject,
          description: description,
          notify: notify,
          upload: path.join("uploads/", req.files["upload"][0].filename),
          createdAt: new Date(),
          adminComment: "",
        };
        // console.log(newTicket);
        const result = await User.updateOne(
          { _id: userId },
          {
            $push: { reports: newReport },
          }
        );

        res.status(200).json({
          message: "ticket details added/updated successfully",
          result,
        });
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      res
        .status(400)
        .json({ message: "Registration failed", error: error.message });
    }
  });
};

