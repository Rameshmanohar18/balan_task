const Ticket = require("../model/ticketModel");
const { storage, upload } = require("../middlewares/multerConfig");
const User = require("../model/userModel");
const path = require("path");
const Content = require("../model/contentModel");
const Reply = require("../model/replyModel");

exports.tickets = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res
        .status(400)
        .json({ message: "Image upload failed", error: err });
    }

    //   console.log(req.files);
    //   console.log(req.body);
    //   console.log(req.params.id);

    try {
      const userId = req.params.id;
      const { department, type, status, subject, description, notify } =
        req.body;

      const user = await User.findOne({ _id: userId });

      const newTicket = new Ticket({
        createdBy: user._id,
        department: department,
        type: type,
        status: status,
        subject: subject,
        description: description,
        notify: notify,
        upload: path.join("uploads/", req.files["upload"][0].filename),
        createdAt: new Date(),
        // adminComment: "",
      });

      await newTicket.save();

      res.status(200).json({
        message: "Ticket details added/updated successfully",
        ticket: newTicket,
      });
    } catch (error) {
      res
        .status(400)
        .json({ message: "Registration failed", error: error.message });
    }
  });
};

exports.gettickets = async (req, res) => {
  try {
    await Ticket.find({})
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

exports.deleteticket = async (req, res) => {
  try {
    const ticketID = req.params.id;

    await Ticket.findByIdAndDelete(ticketID);
    await Reply.deleteMany({ ticketId: ticketID });

    res.json({ message: "Ticket deleted successfully!" });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
};

//Get ticket By Id
exports.getticketbyid = async (req, res) => {
  try {
    const ticketID = req.params.id;

    const ticket = await Ticket.findById(ticketID);

    if (!ticket) {
      return res.status(404).json({ message: "Ticket not found" });
    }

    res.status(200).json({ data: ticket });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

// UPDATE TICKET
exports.updateticket = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res
        .status(400)
        .json({ message: "Image upload failed", error: err });
    }

    try {
      const ticketID = req.params.id;

      const {
        department,
        type,
        status,
        subject,
        description,
        notify,
        content,
      } = req.body;

      const updatedFields = {};
      if (department) updatedFields.department = department;
      if (type) updatedFields.type = type;
      if (status) updatedFields.status = status;
      if (subject) updatedFields.subject = subject;
      if (description) updatedFields.description = description;
      if (notify) updatedFields.notify = notify;

      // if (replyTime) {
      //   updatedFields.repliedAt = replyTime;
      // }
      if (req.files && req.files["upload"]) {
        updatedFields.upload = path.join(
          "uploads/",
          req.files["upload"][0].filename
        );
      }
      const updatedTicket = await Ticket.findByIdAndUpdate(
        ticketID,
        { $set: updatedFields },
        { new: true }
      );

      if (content) {
        const adminReply = content;

        const newReply = new Reply({
          ticketId: ticketID,
          adminComment: adminReply,
          repliedAt: new Date(),
          userComment: "",
          userRepliedAt: ''
        });

        await newReply.save();
      }

      if (!updatedTicket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.status(200).json({ message: "Ticket updated successfully" });
    } catch (error) {
      res
        .status(400)
        .json({ message: "Something went wrong", error: error.message });
    }
  });
};

exports.getticketreplies = async (req, res) => {
  try {
    await Reply.find({})
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

//Reply Comp
exports.updateuserReply = async (req, res) => {
  try {
    const replyID = req.params.id;
    const { replyData } = req.body;
    // console.log(reportID, replyData);

    const updatedReply = await Reply.findByIdAndUpdate(
      { _id: replyID },
      {
        $set: {
          userComment: replyData,
          userRepliedAt: new Date()
        },
      },
      { new: true }
    );

    if (!updatedReply) {
      return res.status(404).json({ message: "reply not found" });
    }

    res.status(200).json({
      message: "reply updated successfully",
      data: updatedReply,
    });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};
