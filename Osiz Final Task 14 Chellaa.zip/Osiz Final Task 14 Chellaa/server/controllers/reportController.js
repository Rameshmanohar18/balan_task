const Report = require("../model/reportModel");
const { storage, upload } = require("../middlewares/multerConfig");
const User = require("../model/userModel");
const ReportReply = require("../model/reportRplyModel");
const path = require("path");

exports.reports = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res
        .status(400)
        .json({ message: "Image upload failed", error: err });
    }
    try {
      const userId = req.params.id;
      const { department, type, status, subject, description, notify } =
        req.body;

      const user = await User.findOne({ _id: userId });

      const newReport = new Report({
        createdBy: user._id,
        department: department,
        type: type,
        status: status,
        subject: subject,
        description: description,
        notify: notify,
        upload: path.join("uploads/", req.files["upload"][0].filename),
        createdAt: new Date(),
        adminComment: "",
        adminReplyStatus: false,
        userReply: "",
        userReplyStatus: false,
      });

      await newReport.save();

      res.status(200).json({
        message: "Ticket details added/updated successfully",
        report: newReport,
      });
    } catch (error) {
      res
        .status(400)
        .json({ message: "Registration failed", error: error.message });
    }
  });
};

exports.getreports = async (req, res) => {
  try {
    await Report.find({})
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

exports.deletereport = async (req, res) => {
  try {
    const reportID = req.params.id;

    await Report.findByIdAndDelete(reportID);
    await ReportReply.deleteMany({
      reportId: reportID
      });

    res.json({ message: "Report deleted successfully!" });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
};

//Get report By Id
exports.getreportbyid = async (req, res) => {
  try {
    const reportID = req.params.id;

    const report = await Report.findById(reportID);

    if (!report) {
      return res.status(404).json({ message: "Ticket not found" });
    }

    res.status(200).json({ data: report });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

// UPDATE report
exports.updatereport = async (req, res) => {
  try {
    const reportID = req.params.id;
    const { status, content } = req.body;

    const updatedReport = await Report.findByIdAndUpdate(
      reportID,
      {
        $set: {
          status: status,
          adminComment: content,
          repliedAt: new Date(),
          adminReplyStatus: true,
          userReplyStatus: false,
        },
      },
      { new: true }
    );

    if (!updatedReport) {
      return res.status(404).json({ message: "Report not found" });
    }

    res.status(200).json({
      message: "Report updated successfully",
      data: updatedReport,
    });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

//getAll replies
exports.getreportreplies = async (req, res) => {
  try {
    await ReportReply.find({})
      .then((data) => res.json({ data }))
      .catch((err) => res.json(err));
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};

//Reply Comp
exports.addreply = async (req, res) => {
  try {
    const reportID = req.params.id;
    const { replyData } = req.body;
    // console.log(reportID, replyData);

    const updatedReport = await Report.findByIdAndUpdate(
      reportID,
      {
        $set: {
          userReply: replyData,
          userReplyStatus: true,
          adminReplyStatus: false,
          adminComment: ''
        },
      },
      { new: true }
    );

    const newReportReply = new ReportReply({
      reportId: reportID,

      repliedAt: new Date(),
      userComment: replyData,
    });

    await newReportReply.save();

    if (!updatedReport) {
      return res.status(404).json({ message: "Report not found" });
    }

    res.status(200).json({
      message: "Report updated successfully",
      data: updatedReport,
    });
  } catch (error) {
    res
      .status(400)
      .json({ message: "Something went wrong", error: error.message });
  }
};
