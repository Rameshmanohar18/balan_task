import { configureStore } from "@reduxjs/toolkit";
import { adminApi } from "./services/adminAPI";
import { ticketApi } from "./services/ticketApi/ticketApi";
import { reportApi } from "./services/reportApi/reportApi";
import { projectsApi } from "./services/projectApi/projectApi";
import { contentApi } from "./services/contentsApi/contentsApi";
import { securityApi } from "./services/securityApi/securityApi";
import { passwordApi } from "./services/changePasswordApi/changePasswordApi";


const store = configureStore({
  reducer: {
    [adminApi.reducerPath]: adminApi.reducer,
    [ticketApi.reducerPath]: ticketApi.reducer,
    [reportApi.reducerPath]: reportApi.reducer,
    [projectsApi.reducerPath]: projectsApi.reducer,
    [contentApi.reducerPath]: contentApi.reducer,
    [securityApi.reducerPath]: securityApi.reducer,
    [passwordApi.reducerPath]: passwordApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      adminApi.middleware,
      ticketApi.middleware,
      reportApi.middleware,
      projectsApi.middleware,
      contentApi.middleware,
      securityApi.middleware,
      passwordApi.middleware
    ),
});

export default store;
