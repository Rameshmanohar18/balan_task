// projects.js

import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const projectsApi = createApi({
  reducerPath: 'projectsApi',
  baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:8000/' }),
  endpoints: (builder) => ({
    addProject: builder.mutation({
      query: (projectData) => ({
        url: 'admin/projects',
        method: 'POST',
        body: projectData,
      }),
      invalidatesTags: [{ type: 'Admin', id: 'Projects' }],
    }),
    getProjects: builder.query({
      query: () => 'admin/getprojects',
      providesTags: [{ type: 'Admin', id: 'Projects' }],
    }),
    updateProjectById: builder.mutation({
      query: ({ id, updatedData }) => ({
        url: `admin/updateproject/${id}`,
        method: 'POST',
        body: updatedData,
      }),
      invalidatesTags: [{ type: 'Admin', id: 'Projects' }],
    }),
  }),
});

export const {
  useAddProjectMutation,
  useGetProjectsQuery,
  useUpdateProjectByIdMutation,
} = projectsApi;
