import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const securityApi = createApi({
  reducerPath: "securityApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  endpoints: (builder) => ({
    handleTwofactorAuth: builder.mutation({
      query: (body) => ({
        url: "admin/twoFactorAuth/getSecertKey",
        method: "POST",
        body,
      }),
      // Add providesTags and invalidatesTags for cache refetching
      providesTags: (result, error, body) => [
        { type: 'Security', id: 'TwofactorAuth' },
      ],
      invalidatesTags: [{ type: 'Security', id: 'TwofactorAuth' }],
    }),

    twoFactorverifySecretCode: builder.mutation({
      query: ({ email, token }) => ({
        url: "admin/twoFactorAuth/verifySecret",
        method: "POST",
        body: { email, token },
      }),
      providesTags: (result, error, { email, token }) => [
        { type: 'Security', id: 'TwoFactorVerification', email, token },
      ],
      invalidatesTags: [{ type: 'Security', id: 'TwoFactorVerification' }],
    }),

    twoFactorDisable: builder.mutation({
      query: (body) => ({
        url: "admin/twoFactorAuth/disableAuthCode",
        method: "POST",
        body,
      }),
      providesTags: (result, error, body) => [
        { type: 'Security', id: 'TwofactorAuth' },
        { type: 'Security', id: 'TwoFactorVerification' },
      ],
      invalidatesTags: [
        { type: 'Security', id: 'TwofactorAuth' },
        { type: 'Security', id: 'TwoFactorVerification' },
      ],
    }),

    logInAuthVerification: builder.mutation({
      query: ({ email, token }) => ({
        url: "admin/loginauth/verify",
        method: "POST",
        body: { email, token },
      }),
      providesTags: (result, error, { email, token }) => [
        { type: 'Security', id: 'LogInAuthVerification', email, token },
      ],
      invalidatesTags: [{ type: 'Security', id: 'LogInAuthVerification' }],
    }),

    getQrImg: builder.query({
      query: (email) => `admin/getQr/${email}`,
      providesTags: ["Admin"],
    }),
  }),
});

export const {
  useLogInAuthVerificationMutation,
  useHandleTwofactorAuthMutation,
  useTwoFactorDisableMutation,
  useTwoFactorverifySecretCodeMutation,
  useGetQrImgQuery
} = securityApi;
