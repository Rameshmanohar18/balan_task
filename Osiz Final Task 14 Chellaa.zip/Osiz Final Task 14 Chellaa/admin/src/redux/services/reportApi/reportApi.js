// api/reports/reportApi.js
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const reportApi = createApi({
  reducerPath: 'reportApi',
  baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:8000/' }),
  endpoints: (builder) => ({
    getReports: builder.query({
      query: () => 'users/getreports',
      providesTags: (result) =>
        result
          ? [{ type: "Report", id: "all" }, { type: "ReportList" }]
          : [], 
    }),

    getReportByID: builder.query({
      query: ({ id }) => ({
        url: `users/getreportbyid/${id}`,
        method: 'GET',
      }),
      providesTags: (result, error, { id }) =>
        result ? [{ type: "Report", id }] : [],
      invalidatesTags: ['ReportList'], 
    }),

    updateReportById: builder.mutation({
      query: ({ id, updatedData }) => ({
        url: `users/updatereport/${id}`,
        method: 'POST',
        body: updatedData,
      }),
      invalidatesTags: ['ReportList'], 
    }),
    getReportReplies: builder.query({
      query: () => `users/getreportreplies`,
      providesTags: (result) => (result ? [{ type: "ReportList", id: "all" }] : []),
      invalidatesTags: ["ReportList"],
    }),
  }),
});

export const {
  useGetReportsQuery,
  useGetReportByIDQuery,
  useUpdateReportByIdMutation,
  useGetReportRepliesQuery
} = reportApi;
