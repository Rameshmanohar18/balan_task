import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export const ticketApi = createApi({
    reducerPath: 'ticketApi',
    baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:8000/' }),
    endpoints: (builder) => ({
      getTickets: builder.query({
        query: () => 'users/gettickets',
        providesTags: (result) =>
          result ? [{ type: "Ticket", id: "all" }, { type: "TicketList" }] : [], 
      }),
      getTicketByID: builder.query({
        query: ({ id }) => ({
          url: `users/getticketbyid/${id}`,
          method: 'GET',
        }),
        providesTags: (result, error, { id }) =>
          result ? [{ type: "Ticket", id }] : [],
        invalidatesTags: [{ type: "TicketList" }], 
      }),
      updateTicketById: builder.mutation({
        query: ({ id, updatedData }) => ({
          url: `users/updateticket/${id}`,
          method: 'POST',
          body: updatedData,
        }),
        invalidatesTags: [{ type: "Ticket", id: "all" }, { type: "TicketList" }],
      }),
      getTicketReplies: builder.query({
        query: () => `users/getticketreplies`,
        providesTags: (result) => (result ? [{ type: "Ticket", id: "all" }] : []),
        invalidatesTags: ["Ticket"],
      }),
    }),
  });
  
  export const {
    useGetTicketsQuery,
    useGetTicketByIDQuery,
    useUpdateTicketByIdMutation,
    useGetTicketRepliesQuery
  } = ticketApi;
  