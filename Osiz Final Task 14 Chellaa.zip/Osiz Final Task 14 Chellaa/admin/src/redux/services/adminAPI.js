import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const getToken = () => {
  return localStorage.getItem("AdminToken");
};

export const adminApi = createApi({
  reducerPath: "adminApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  endpoints: (builder) => ({
    getUsers: builder.query({
      query: () => "users",
      providesTags: ["Admin"],
    }),
    // getAdmin: builder.query({
    //   query: () => "admin/regadmins",
    //   providesTags: ["Admin"],
    // }),
    getUserById: builder.query({
      query: (id) => `users/fetchuser/${id}`,
    }),

    //admin reg
    adminReg: builder.mutation({
      query: ({ formData }) => ({
        url: "admin",
        method: "POST",
        body: { formData },
      }),
      invalidatesTags: ["Admin"],
    }),
    adminLogin: builder.mutation({
      query: ({ formData }) => ({
        url: "admin/login",
        method: "POST",
        body: { formData },
      }),
      invalidatesTags: ["Admin"],
    }),
    getAdminDetails: builder.query({
      query: () => ({
        url: `admin/adminDetails`,
        headers: {
          Authorization: `Bearer ${getToken()}`,
        },
      }),
      providesTags: ["Admin"],
    }),
    kycUpdate: builder.mutation({
      query: ({ id, formData }) => ({
        url: `admin/kycupdate/${id}`,
        method: "POST",
        body: { formData },
      }),
      invalidatesTags: ["Admin"],
    }),
  }),
});

export const {
  useGetUsersQuery,
  useGetAdminDetailsQuery,
  useGetUserByIdQuery,
  useKycUpdateMutation,
  useAdminRegMutation,
  useAdminLoginMutation,
} = adminApi;
