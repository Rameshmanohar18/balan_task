// contentApi.js
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const passwordApi = createApi({
  reducerPath: "passwordApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  endpoints: (builder) => ({
    generateOtp: builder.mutation({
      query: (data) => ({
        url: "admin/generateOtp",
        method: "POST",
        body: data,
      }),
    }),
    setNewPwd: builder.mutation({
      query: (updatedData) => ({
        url: "admin/setNewPwd",
        method: "POST",
        body: updatedData,
      }),
    }),
    setNewPattern: builder.mutation({
      query: (updatedPattern) => ({
        url: "admin/setNewPattern",
        method: "POST",
        body: updatedPattern,
      }),
    }),
    changeAdminPassword: builder.mutation({
      query: (updatedAdminPassword) => ({
        url: "admin/changeAdminPwd",
        method: "POST",
        body: updatedAdminPassword,
      }),
    }),
    changeAdminPattern: builder.mutation({
      query: (updatedAdminPattern) => ({
        url: "admin/changeAdminPattern",
        method: "POST",
        body: updatedAdminPattern,
      }),
    }),
  }),
});

export const {
  useGenerateOtpMutation,
  useSetNewPwdMutation,
  useSetNewPatternMutation,
  useChangeAdminPasswordMutation,
  useChangeAdminPatternMutation
} = passwordApi;
