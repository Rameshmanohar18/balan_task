import React, { Component, Suspense } from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import "./scss/style.scss";
import DefaultLayout from "./layout/DefaultLayout";
import Register from "./views/pages/register/Register";
import Page404 from "./views/pages/page404/Page404";
import Page500 from "./views/pages/page500/Page500";
import Login from "./views/pages/login/Login";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import TwoFAuth from "./views/securityPage/TwoFAuth";
import ForgotPassword from "./views/admin/forgotPassword/ForgotPassword";
import SetNewPassword from "./views/admin/setNewPassword/SetNewPassword";
import SetNewPattern from "./views/admin/setNewPattern/SetNewPattern";
import PrivateRoute from "./components/privateRoute/PrivateRoute";
import LoginRoute from "./components/privateRoute/LoginRoute";

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
);

class App extends Component {
  render() {
    return (
      <>
        <Routes>
          <Route
            exact
            path="*"
            element={
              <PrivateRoute>
                <DefaultLayout />
              </PrivateRoute>
            }
          />

          <Route
            path="/"
            element={
              <LoginRoute>
                <Login />
              </LoginRoute>
            }
          />
          <Route
            path="/register"
            element={
              <LoginRoute>
                <Register />
              </LoginRoute>
            }
          />
          {/* <Route exact path="/register" name="Register Page" element={<Register />} /> */}
          <Route exact path="/404" element={<Page404 />} />
          <Route exact path="/500" element={<Page500 />} />
          {/* <Route path="/" element={<Login />} /> */}

          <Route exact path="/500" element={<Page500 />} />
          <Route
            path="/2fauth/:email"
            element={
              <LoginRoute>
                <TwoFAuth />
              </LoginRoute>
            }
          />
          <Route
            path="/forgotpassword"
            element={
              <LoginRoute>
                <ForgotPassword />
              </LoginRoute>
            }
          />
          <Route
            path="/setnewpassword/:email"
            element={
              <LoginRoute>
                <SetNewPassword />
              </LoginRoute>
            }
          />
          <Route
            path="/setnewpattern/:email"
            element={
              <LoginRoute>
                <SetNewPattern />
              </LoginRoute>
            }
          />
        </Routes>
        <ToastContainer />
      </>
    );
  }
}

export default App;
