import React from 'react';
import { Navigate } from 'react-router-dom';

const LoginRoute = ({ children }) => {
  const token = localStorage.getItem('AdminToken');

  if (!token) {
    return <>{children}</>;
  } else {
 
    return <Navigate to="/dash/dashboard" />;
  }
};



export default LoginRoute;
