import React from 'react'
import {
  CAvatar,
  CBadge,
  CDropdown,
  CDropdownDivider,
  CDropdownHeader,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from '@coreui/react'
import {
  cilBell,
  cilCreditCard,
  cilCommentSquare,
  cilEnvelopeOpen,
  cilFile,
  cilLockLocked,
  cilSettings,
  cilTask,
  cilUser,
} from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import adminPro from '../../assets/images/adminProfile.png'
import { useNavigate } from 'react-router-dom'
import { useGetProjectsQuery } from "../../redux/services/projectApi/projectApi";


const AppHeaderDropdown = () => {
  const { data, isLoading } = useGetProjectsQuery();
  const projects = data?.data;
  // console.log(projects.length);
  const navigate = useNavigate();
  const logout = () =>{
    localStorage.removeItem('AdminToken');
     navigate('/');
  }
  return (
    <CDropdown variant="nav-item">
      <CDropdownToggle placement="bottom-end" className="py-0" caret={false}>
        <CAvatar src={adminPro} size="md" />
      </CDropdownToggle>
      <CDropdownMenu className="pt-0" placement="bottom-end">
        
       
        <CDropdownItem onClick={()=>navigate('/dash/dashboard')} style={{cursor: "pointer"}}>
          <CIcon icon={cilUser} className="me-2" />
          Profile
        </CDropdownItem>
      
        <CDropdownItem onClick={()=>navigate('/admin/projectslist')} style={{cursor: "pointer"}}>
          <CIcon icon={cilFile} className="me-2" />
          Projects
          <CBadge color="primary" className="ms-2">
            {projects?.length}
          </CBadge>
        </CDropdownItem>
        <CDropdownDivider />
        <CDropdownItem onClick={logout} style={{cursor: "pointer"}}>
          <CIcon icon={cilLockLocked} className="me-2" />
         <span>Log Out</span>
        </CDropdownItem>
      </CDropdownMenu>
    </CDropdown>
  )
}

export default AppHeaderDropdown
