import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  useGetTicketByIDQuery,
  useUpdateTicketByIdMutation,
  useGetTicketRepliesQuery,
} from "../../redux/services/ticketApi/ticketApi";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import Swal from "sweetalert2";

const schema = yup.object().shape({
  createdAt: yup.string().required("CreatedAt is required"),
  createdBy: yup.string().required("CreatedBy is required"),
  department: yup.string().required("Department is required"),
  description: yup.string().required("Description is required"),
  notify: yup.string().required("Notify is required"),
  status: yup.string().required("Status is required"),
  subject: yup.string().required("Subject is required"),
  type: yup.string().required("Type is required"),
});

const TicketDetail = () => {
  const [content, setContent] = useState(null);
  const [isEditorEmpty, setIsEditorEmpty] = useState(true);
  const params = useParams();
  // console.log(params.id)
  const navigate = useNavigate();

  const { data, isLoading, isError } = useGetTicketByIDQuery({ id: params.id });
  const ticket = data?.data;

  const ticketStatus = ticket?.status;
  //  console.log(ticketStatus);

  const [updateTicket] = useUpdateTicketByIdMutation();

  const { data: replies, isLoading: loading } = useGetTicketRepliesQuery();
  // console.log(replies);

  const adminReplies = replies?.data.filter(
    (reply) => reply.ticketId == params.id
  );

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    if (ticket) {
      setValue("createdAt", ticket.createdAt);
      setValue("createdBy", ticket.createdBy);
      setValue("department", ticket.department);
      setValue("description", ticket.description);
      setValue("notify", ticket.notify);
      setValue("status", ticket.status);
      setValue("subject", ticket.subject);
      setValue("type", ticket.type);
    }
  }, [ticket, setValue]);

  if (isLoading) {
    return <h4>Loading...</h4>;
  }

  const handleData = (event, editor) => {
    const data = editor.getData();
    setContent(data);
    setIsEditorEmpty(data.length === 0);
  };

  const onSubmit = async (formData) => {
    const updatedData = {
      status: formData.status,
      content,
    };
    const res = await updateTicket({ id: params.id, updatedData });

    setContent("");
    if (res.data) {
      Swal.fire({
        icon: "success",
        title: "Ticket Updated Successfully!",
        showConfirmButton: false,
        timer: 1500,
      }).then(() => {
        navigate("/tickets");
      });
    }

    //  console.log(updatedData);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="container">
      <h4>Ticket Details</h4>
      <div className="row">
        <div className="col-md-6 mb-3">
          <label className="form-label">CreatedAt:</label>
          <input
            {...register("createdAt")}
            className="form-control"
            readOnly
            style={{ pointerEvents: "none" }}
          />
          <p className="text-danger">{errors.createdAt?.message}</p>
        </div>

        <div className="col-md-6 mb-3">
          <label className="form-label">CreatedBy:</label>
          <input
            {...register("createdBy")}
            className="form-control"
            readOnly
            style={{ pointerEvents: "none" }}
          />
          <p className="text-danger">{errors.createdBy?.message}</p>
        </div>
      </div>

      <div className="row">
        <div className="col-md-6 mb-3">
          <label className="form-label">Department:</label>
          <input
            {...register("department")}
            className="form-control"
            readOnly
            style={{ pointerEvents: "none" }}
          />
          <p className="text-danger">{errors.department?.message}</p>
        </div>

        <div className="col-md-6 mb-3">
          <label className="form-label">Description:</label>
          <input
            {...register("description")}
            className="form-control"
            readOnly
            style={{ pointerEvents: "none" }}
          />
          <p className="text-danger">{errors.description?.message}</p>
        </div>
      </div>

      <div className="row">
        <div className="col-md-6 mb-3">
          <label className="form-label">Notify:</label>
          <input
            {...register("notify")}
            className="form-control"
            readOnly
            style={{ pointerEvents: "none" }}
          />
          <p className="text-danger">{errors.notify?.message}</p>
        </div>

        <div className="col-md-6 mb-3">
          <label className="form-label">Status:</label>
          <select {...register("status")} className="form-select">
            <option value="">Select Status</option>
            <option value="New">New</option>
            <option value="Open">Open</option>
            <option value="Re-opened">Re-opened</option>
            <option value="Resolved">Resolved</option>
            <option value="Waiting">Waiting</option>
            <option value="Closed">Closed</option>
            <option value="Cancel">Cancel</option>
          </select>
          <p className="text-danger">{errors.status?.message}</p>
        </div>
      </div>

      <div className="row">
        <div className="col-md-6 mb-3">
          <label className="form-label">Subject:</label>
          <input
            {...register("subject")}
            className="form-control"
            readOnly
            style={{ pointerEvents: "none" }}
          />
          <p className="text-danger">{errors.subject?.message}</p>
        </div>

        <div className="col-md-6 mb-3">
          <label className="form-label">Type:</label>
          <input
            {...register("type")}
            className="form-control"
            readOnly
            style={{ pointerEvents: "none" }}
          />
          <p className="text-danger">{errors.type?.message}</p>
        </div>
      </div>

      <div className="col-md-6 mb-3">
        <h5>Uploads:</h5>
        <div>
          <img
            src={`http://localhost:8000/${ticket?.upload}`}
            alt="Ticket"
            style={{ width: "300px", height: "250px" }}
          />
        </div>
      </div>
      <div className="col-md-6 mb-3 border p-4">
        <h5>Conversation:</h5>
        <div>
          {adminReplies?.map((reply) => {
            return (
              <>
                <div
                  className="rounded m-4 p-4"
                  style={{ border: "2px solid red" }}
                >
                  {" "}
                  <span>Replied At:</span>
                  <span>
                    <span>
                      {" "}
                      {reply?.repliedAt === null
                        ? "--"
                        : new Date(reply?.repliedAt).toLocaleDateString()}
                    </span>
                    ({" "}
                    {reply?.repliedAt === null
                      ? "--"
                      : new Date(reply?.repliedAt).toLocaleTimeString()}
                    )
                  </span>
                  <br />
                  <span className="text-warning ">You:</span>{" "}
                  <i
                    dangerouslySetInnerHTML={{
                      __html: reply?.adminComment,
                    }}
                  ></i>
                
                  <br />
                  <span className="text-danger">User Reply:</span>{" "}
                  <br/>
                  <i>{reply?.userComment}</i> <br />
                  
                  <span>User Replied On:</span>
                  <span>
                    <span>
                      {" "}
                      {reply?.userRepliedAt === null
                        ? "--"
                        : new Date(reply?.repliedAt).toLocaleDateString()}
                    </span>
                    ({" "}
                    {reply?.userRepliedAt === null
                      ? "--"
                      : new Date(reply?.userRepliedAt).toLocaleTimeString()}
                    )
                  </span>
                  <hr style={{ color: "red" }} />
                </div>
              </>
            );
          })}
        </div>
      </div>

      <div>
        <h3>Comments:</h3>

        <CKEditor
          editor={ClassicEditor}
          data={content}
          style={{ height: "200px" }}
          onChange={handleData}
        />
      </div>

      <button
        type="submit"
        className="btn btn-primary mt-3 mb-3"
        disabled={isEditorEmpty}
      >
        Submit
      </button>
    </form>
  );
};

export default TicketDetail;
