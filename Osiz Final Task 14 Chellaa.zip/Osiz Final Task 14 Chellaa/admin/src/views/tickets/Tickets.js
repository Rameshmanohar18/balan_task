import React from "react";
import DataTable from "react-data-table-component";
import { useGetTicketsQuery } from "../../redux/services/ticketApi/ticketApi";
import { useNavigate } from "react-router-dom";

const Tickets = () => {
  const navigate = useNavigate();

  const { data, isLoading } = useGetTicketsQuery();
  const tickets = data?.data;
  console.log(tickets);

  const columns = [
    {
      name: "Serial No.",
      selector: (row, index) => index + 1,
      sortable: true,
    },
    {
      name: "Ticket ID",
      selector: "_id",
      sortable: true,
      style: {
        background: "#d3d3d3",
      },
    },
    {
      name: "Status",
      selector: "status",
      sortable: true,
    },
    {
      name: "Created By",
      selector: "createdBy",
      sortable: true,
    
    },
    {
      name: "Actions",
      cell: (row) => (
        <button className="btn btn-primary" onClick={() => navigate(`/ticketdetail/${row._id}`)}>
          View Details
        </button>
      ),
    },
  ];

  if (isLoading) {
    return <h3>Loading...</h3>;
  }

  return (
    <div>
      <h2>All Tickets</h2>
      <DataTable
        columns={columns}
        data={tickets || []}
        pagination
        paginationPerPage={10}
        striped
        highlightOnHover
        responsive
      />
    </div>
  );
};

export default Tickets;
