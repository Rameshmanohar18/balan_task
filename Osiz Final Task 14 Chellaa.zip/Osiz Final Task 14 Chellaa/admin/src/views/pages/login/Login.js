import React from "react";

import {
  CButton,
  CCard,
  CCardBody,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInputGroup,
  CInputGroupText,
  CRow,
} from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { cilLockLocked, cilUser } from "@coreui/icons";
import { toast } from "react-toastify";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import PatternLock from "react-pattern-lock";
import { useAdminLoginMutation } from "../../../redux/services/adminAPI";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import Swal from "sweetalert2";

const validationSchema = Yup.object().shape({
  email: Yup.string()
    .required("Email is required")
    .email("Email is invalid")
    .matches(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g, "Invalid email format")
    .trim(),
  password: Yup.string().required("Password is required"),
});

const Login = () => {
  const [pattern, setPattern] = useState([]);
  const [adminLogin] = useAdminLoginMutation();
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    resetField,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "all",
  });

  const handlePatternFinish = (newPattern) => {
    console.log("Pattern completed:", newPattern);
  };
  const onChange = (newPattern) => {
    setPattern(newPattern);
  };

  const onSubmit = async (data) => {
    try {
      if (!pattern.length) {
        toast.error("Please draw a pattern");
        return;
      }
      if (pattern.length < 3) {
        toast.error("Pattern should be in atleat 3 dots");
        return;
      }
      const email = data.email;
      // console.log(email);

      const formData = {
        ...data,
        pattern,
      };
      // console.log(formData)

      const res = await adminLogin({ formData });

      if (res.error) {
        toast.error(res.error.data.error);
        setPattern([]);
        return;
      }

      const authStatus = res?.data?.admin?.twoFactorAuth;
      if (authStatus === false) {
        const token = res?.data?.token;
        localStorage.setItem("AdminToken", token);
      }

      const path = authStatus ? `/2fauth/${email}` : `/dash/dashboard`;

      navigate(path);

      if (res.error) {
        toast.error(res.error.data.error);
        setPattern([]);
        return;
      }

      // const toastMessage = authStatus
      //   ? "Please verify!"
      //   : "Authentication successful!";
      // toast.warning(toastMessage);
      // navigate(`/security/${email}`)
    } catch (error) {
      console.log(error);
    }
  };

  const handleReset = () => {
    setPattern([]);
  };

  //PASSWORD VISIBILITY
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="bg-light min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={8}>
            <CCardGroup>
              <CCard className="p-5">
                <CCardBody>
                  <CForm className="text-center">
                    <h1>Login</h1>
                    <p className="text-medium-emphasis">
                      Sign In to your account
                    </p>
                    <CInputGroup className="mb-3">
                      <CInputGroupText>
                        <CIcon icon={cilUser} />
                      </CInputGroupText>
                      <input
                        type="text"
                        className="form-control"
                        name="email"
                        {...register("email")}
                      />
                    </CInputGroup>
                    <div className="text-danger">{errors.email?.message}</div>
                    <CInputGroup className="mb-4">
                      <div className="input-group">
                        <button
                          type="button"
                          className="input-group-text bg-none border"
                          onClick={togglePasswordVisibility}
                          style={{
                            borderRadius: "none",
                          }}
                        >
                          {showPassword ? (
                            <FontAwesomeIcon
                              icon={faEyeSlash}
                              style={{ color: "black" }}
                            />
                          ) : (
                            <FontAwesomeIcon
                              icon={faEye}
                              style={{ color: "black" }}
                            />
                          )}
                        </button>
                        <input
                          type={showPassword ? "text" : "password"}
                          className="form-control"
                          name="password"
                          {...register("password")}
                        />{" "}
                      </div>
                      <div className="text-danger">
                        {errors.password?.message}
                      </div>
                    </CInputGroup>

                    <CRow className="justify-content-center">
                      <CCol xs={6}>
                        <CButton
                          color="primary"
                          className="px-4"
                          onClick={handleSubmit(onSubmit)}
                        >
                          Login
                        </CButton>
                      </CCol>
                    </CRow>
                    <CRow className="mt-2 justify-content-center">
                      <CCol>
                        <Link
                          to="/forgotpassword"
                          state={{ method: "forgot password" }}
                        >
                          Forgot Password?
                        </Link>
                      </CCol>
                    </CRow>
                  </CForm>
                </CCardBody>
                <CRow className="mt-2 justify-content-center">
                  <CCol>
                    <Link to="/register">Create Your Account?</Link>
                  </CCol>
                </CRow>
              </CCard>
              <CCard
                className="text-white bg-primary py-5"
                style={{ width: "44%" }}
              >
                <CCardBody className="text-center">
                  <div>
                    <div className="my-2">
                      <label>Pattern</label>
                      <div className="d-flex justify-content-center">
                        <PatternLock
                          width={300}
                          pointSize={15}
                          size={3}
                          path={pattern}
                          onChange={onChange}
                          onFinish={handlePatternFinish}
                          style={{
                            background: "#0b80f2",
                            borderRadius: "16px",
                          }}
                        />
                      </div>
                    </div>
                    <Link
                      onClick={handleReset}
                      state={{ method: "forgot pattern" }}
                    >
                      <CButton
                        color="primary"
                        className="mt-3 me-2"
                        active
                        tabIndex={-1}
                      >
                        reset
                      </CButton>
                    </Link>
                    <Link
                      to="/forgotpassword"
                      state={{ method: "forgot pattern" }}
                    >
                      <CButton
                        color="primary"
                        className="mt-3"
                        active
                        tabIndex={-1}
                      >
                        Forgot Pattern!
                      </CButton>
                    </Link>
                  </div>
                </CCardBody>
              </CCard>
            </CCardGroup>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  );
};

export default Login;
