import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CInputGroup,
  CInputGroupText,
  CRow,
} from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { cilUser, cilLockLocked } from "@coreui/icons";
import PatternLock from "react-pattern-lock";
import { useAdminRegMutation } from "../../../redux/services/adminAPI";
import Swal from "sweetalert2";
import { toast } from "react-toastify";

const validationSchema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .email("Email is invalid")
    .matches(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g, "Invalid email format")
    .trim(),
  password: yup
    .string()
    .required("Password is required")
    .matches(/[A-Z]/, "Password Must Contain atlease One UpperCase Letter")
    .matches(/[0-9]/, "Password Must Contain atlease One Number")
    .matches(
      /[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/,
      "Password Must Contain atlease One Special Character.. like @#$"
    )
    .trim()
    .min(8, "Password must be at least 8 characters"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("password"), null], "Passwords must match")
    .required("Confirm Password is required")
    .trim(),
});

const Register = () => {
  const [pattern, setPattern] = useState([]);
  const [regAdmin] = useAdminRegMutation();

  const {
    register,
    handleSubmit,
    formState: { errors },reset
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "all",
  });
  const handlePatternFinish = (newPattern) => {
    console.log("Pattern completed:", newPattern);
  };
  const onChange = (newPattern) => {
    setPattern(newPattern);
  };

  const onSubmit = async (data) => {
    if (!pattern.length) {
      toast.error("Please draw a pattern");
      return;
    }
    const formData = {
      ...data,
      pattern,
    };
    // console.log(formData);
    const res = await regAdmin({ formData });
    if(res.data){
      Swal.fire("User Registered!", "", "success");
      reset();
    }
  };
  return (
    <div className="bg-light min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={9} lg={7} xl={6}>
            <CCard className="mx-4">
              <CCardBody className="p-4">
                <CForm onSubmit={handleSubmit(onSubmit)}>
                  <h1>Register</h1>
                  <p className="text-medium-emphasis">Create your account</p>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilUser} />
                    </CInputGroupText>
                    <CFormInput
                      {...register("username", { required: true })}
                      placeholder="Username"
                      autoComplete="username"
                      error={errors.username}
                    />
                  </CInputGroup>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>@</CInputGroupText>
                    <CFormInput
                      {...register("email", { required: true })}
                      placeholder="Email"
                      autoComplete="email"
                      error={errors.email}
                    />
                  </CInputGroup>
                  <div className="text-danger">{errors.email?.message}</div>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilLockLocked} />
                    </CInputGroupText>
                    <CFormInput
                      {...register("password", {
                        required: true,
                        minLength: 3,
                      })}
                      type="password"
                      placeholder="Password"
                      autoComplete="new-password"
                      error={errors.password}
                    />
                  </CInputGroup>
                  <div className="text-danger">{errors.password?.message}</div>
                  <CInputGroup className="mb-4">
                    <CInputGroupText>
                      <CIcon icon={cilLockLocked} />
                    </CInputGroupText>
                    <CFormInput
                      {...register("confirmPassword", {
                        required: true,
                      })}
                      type="password"
                      placeholder="Repeat password"
                      autoComplete="new-password"
                      error={errors.confirmPassword}
                    />
                  </CInputGroup>
                  {errors.confirmPassword && (
                    <div className="invalid-feedback">
                      {errors.confirmPassword.message}
                    </div>
                  )}
                  <div className="my-2">
                    <label>Pattern</label>
                    <div className="d-flex justify-content-center">
                      <PatternLock
                        width={300}
                        pointSize={15}
                        size={3}
                        path={pattern}
                        onChange={onChange}
                        onFinish={handlePatternFinish}
                        style={{
                          background: "#0b80f2",
                          borderRadius: "16px",
                        }}
                      />
                    </div>
                  </div>

                  <div className="d-grid">
                    <CButton color="success" type="submit">
                      Create Account
                    </CButton>
                  </div>
                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  );
};

export default Register;
