import React from "react";
import DataTable from "react-data-table-component";
import { useGetUsersQuery } from "../../redux/services/adminAPI";
import { useNavigate } from "react-router-dom";
import onlineActive from "../../assets/images/onlineActive.png";
import offline from "../../assets/images/offline.jpeg";

const Users = () => {
  const { data, isFetching } = useGetUsersQuery();
  const users = data?.data;
  const navigate = useNavigate();

  const columns = [
    {
      name: "S.No",
      cell: (_, index) => index + 1,
      sortable: true,
    },
    {
      name: "Profile",
      cell: (row) =>
        row.profilePic ? (
          <img
            src={`http://localhost:8000/${row?.profilePic}`}
            alt="profile"
            style={{ width: "40px", height: "40px" }}
          />
        ) : null,
      sortable: true,
    },

    {
      name: "Username",
      cell: (row) => row.username,
      sortable: true,
    },
    {
      name: "Email",
      cell: (row) => row.email,
      sortable: true,
      style: {
        background: "#d3d3d3",
      },
    },
    {
      name: "Kyc Status",
      cell: (row) => (row.kyc.isApproved ? "Approved" : "Pending"),
      sortable: true,
    },
    {
      name: "User Last update on KYC",
      cell: (row) =>
        row.kyc && row.kyc.userLastUpdate
          ? new Date(row.kyc.userLastUpdate).toLocaleDateString() +
            " " +
            new Date(row.kyc.userLastUpdate).toLocaleTimeString()
          : "--",
      sortable: true,
      style: {
        minWidth: "100px",
      },
    },
    {
      name: "Actions",
      cell: (row) => (
        <button
          className="btn btn-primary"
          onClick={() => navigate(`/kycdetail/${row._id}`)}
        >
          Kyc Details
        </button>
      ),
    },
  ];

  if (isFetching) {
    return <div>Loading...</div>;
  }

  return (
    <div className="user-table-container">
      <h2>Users</h2>
      <DataTable
        columns={columns}
        data={users}
        pagination
        paginationPerPage={10}
        striped
        highlightOnHover
        responsive
      />
    </div>
  );
};

export default Users;
