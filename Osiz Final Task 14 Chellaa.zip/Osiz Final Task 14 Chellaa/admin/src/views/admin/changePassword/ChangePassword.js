import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { useParams } from "react-router-dom";
import * as yup from "yup";
import { useChangeAdminPasswordMutation } from "../../../redux/services/changePasswordApi/changePasswordApi";
import Swal from "sweetalert2";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";

const schema = yup.object().shape({
  password: yup
    .string()
    .required("password is required")
    .matches(/[A-Z]/, "Invalid")
    .matches(/[0-9]/, "Invalid")
    .matches(/[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/, "Invalid")
    .trim()
    .min(8, "Invalid"),
  newPassword: yup
    .string()
    .required("newPassword is required")
    .matches(/[A-Z]/, "Password Must Contain One or More UpperCase Letters")
    .matches(/[0-9]/, "Password Must Contain One or More Numbers")
    .matches(
      /[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/,
      "Password Must Contain One or More Special Characters"
    )
    .trim()
    .min(8, "newPassword must be at least 8 characters"),
  confirmNewPassword: yup
    .string()
    .oneOf([yup.ref("newPassword"), null], "Passwords does not match")
    .required("Confirm New Password is required")
    .trim(),
});

const ChangePassword = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showCnfrmPassword, setShowCnfrmPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const navigate = useNavigate();
  const [changeAdminPwd] = useChangeAdminPasswordMutation();
  const params = useParams();
  const adminID = params.id;
  // console.log(adminID);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema),
    mode: "all",
  });

  const onSubmit = async (data) => {
    // console.log(data);

    try {
      const updatedAdminPassword = { ...data, adminID };
      const response = await changeAdminPwd(updatedAdminPassword);
      console.log(response);
      reset();
      if (response.error) {
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "Incorrect old password",
        });
      } else {
        Swal.fire({
          position: "center",
          icon: "success",
          title: `Your password has been changed successfully`,
          showConfirmButton: false,
          timer: 2500,
        });
        setTimeout(() => {
          navigate("/dash/dashboard");
        }, 4000);
      }
    } catch (error) {
      console.log(error);
    }
  };

  //PASSWORD VISIBILITY
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  //PASSWORD VISIBILITY
  const toggleCnfrmPasswordVisibility = () => {
    setShowCnfrmPassword(!showCnfrmPassword);
  };
  //PASSWORD VISIBILITY
  const toggleNewPasswordVisibility = () => {
    setShowNewPassword(!showNewPassword);
  };

  return (
    <div>
      <div>
        <form action="">
          <div className="col-md-6">
            <label>Old Password</label>
            <br />
            <br />
            <div className="input-group">
              <input
                className={`form-control py-3 ${
                  errors?.password ? "is-invalid" : ""
                }`}
                {...register("password")}
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Enter Your Old Password"
              />
              <button
                type="button"
                className="input-group-text border"
                onClick={togglePasswordVisibility}
                style={{
                  borderRadius: "none",
                }}
              >
                {showPassword ? (
                  <FontAwesomeIcon
                    icon={faEyeSlash}
                    style={{ color: "black" }}
                  />
                ) : (
                  <FontAwesomeIcon icon={faEye} style={{ color: "black" }} />
                )}
              </button>
              <div className="invalid-feedback ">
                <span style={{ margin: "13px" }}>
                  {errors?.password?.message}
                </span>
              </div>
            </div>
          </div>
          <br />
          <div className="col-md-6">
            <label>Enter New Password</label>
            <br />
            <br />
            <div className="input-group">
              <input
                className={`form-control py-3 ${
                  errors?.newPassword ? "is-invalid" : ""
                }`}
                type={showCnfrmPassword ? "text" : "password"}
                {...register("newPassword")}
                name="newPassword"
                placeholder="Enter Your New Password"
              />
              <button
                type="button"
                className="input-group-text border"
                onClick={toggleCnfrmPasswordVisibility}
                style={{
                  borderRadius: "none",
                }}
              >
                {showCnfrmPassword ? (
                  <FontAwesomeIcon
                    icon={faEyeSlash}
                    style={{ color: "black" }}
                  />
                ) : (
                  <FontAwesomeIcon icon={faEye} style={{ color: "black" }} />
                )}
              </button>
              <div className="invalid-feedback ">
                <span style={{ margin: "13px" }}>
                  {errors?.newPassword?.message}
                </span>
              </div>
            </div>
          </div>
          <br />
          <div className="col-md-6">
            <label>Enter Confirm New Password</label>
            <br />
            <br />
            <div className="input-group">
              <input
                className={`form-control py-3 ${
                  errors?.confirmNewPassword ? "is-invalid" : ""
                }`}
                {...register("confirmNewPassword")}
                type={showNewPassword ? "text" : "password"}
                name="confirmNewPassword"
                placeholder="Enter Your Confirm Password"
              />
              <button
                type="button"
                className="input-group-text border"
                onClick={toggleNewPasswordVisibility}
                style={{
                  borderRadius: "none",
                }}
              >
                {showNewPassword ? (
                  <FontAwesomeIcon
                    icon={faEyeSlash}
                    style={{ color: "black" }}
                  />
                ) : (
                  <FontAwesomeIcon icon={faEye} style={{ color: "black" }} />
                )}
              </button>
              <div className="invalid-feedback ">
                <span style={{ margin: "13px" }}>
                  {errors?.confirmNewPassword?.message}
                </span>
              </div>
            </div>
          </div>
          <br />
          <div className="row mb-4">
            <div className="col-md-12">
              <button
                className="btn btn-primary"
                type="submit"
                onClick={handleSubmit(onSubmit)}
              >
                Submit
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ChangePassword;
