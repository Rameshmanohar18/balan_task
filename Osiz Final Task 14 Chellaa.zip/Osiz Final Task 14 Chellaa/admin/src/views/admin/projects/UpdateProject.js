import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useParams } from "react-router-dom";
import {
  useGetProjectsQuery,
  useUpdateProjectByIdMutation,
} from "../../../redux/services/projectApi/projectApi";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { toast } from "react-toastify";

const schema = yup.object().shape({
  projectName: yup
    .string()
    .required("Project name is required")
    .min(3, "ProjectName should contain atleaset 3 characters")
    .matches(/[A-Za-z]/, "ProjectName should contain alphabets")
    .trim(),
  type: yup.string().required("Project type is required"),
  createdBy: yup.string().required("Created by is required"),
});

const UpdateProject = () => {
  const params = useParams();
  console.log(params.id);
  const projectId = params.id;
  const navigate = useNavigate();
  const { data, isLoading } = useGetProjectsQuery();
  const projects = data?.data;
  //   console.log(projects)
  const [updateProject] = useUpdateProjectByIdMutation();

  // Find the single project using the ID
  const singleProject = projects?.find((project) => project._id === projectId);
  // console.log(singleProject)
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    if (singleProject) {
      reset({
        projectName: singleProject.projectName,
        type: singleProject.type,
        createdBy: singleProject.createdBy,
      });
    }
  }, [singleProject, reset]);

  const onSubmit = async (data) => {
    try {
      console.log("Form submitted:", data);
      const res = await updateProject({ updatedData: data, id: params.id });

      if (res.error) {
        toast.error("Error adding project:", res.error);
        return;
      }
      if (res.data) {
        Swal.fire({
          icon: "success",
          title: "Project Updated Successfully!",
          showConfirmButton: false,
          timer: 1500,
        });
      }
    } catch (error) {
      console.error("Error adding project:", error);
    }
  };

  return (
    <div
      className="container"
      style={{ padding: 20, border: "1px solid #ccc" }}
    >
      <h1>UpdateProject</h1>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="form-group mb-3">
          <label className="form-label">Project Name:</label>
          <input
            type="text"
            id="projectName"
            className="form-control"
            style={{ borderColor: errors.projectName ? "red" : "#ced4da" }}
            {...register("projectName")}
          />
          {errors.projectName && (
            <div className="text-danger">{errors.projectName.message}</div>
          )}
        </div>

        <div className="form-group mb-3">
          <label className="form-label">Project Type:</label>
          <select
            id="type"
            className="form-select"
            style={{ borderColor: errors.type ? "red" : "#ced4da" }}
            {...register("type")}
          >
            <option value="">Select Type</option>
            <option value="New">New</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Closed">Closed</option>
            <option value="Re-opened">Re-opened</option>
          </select>
          {errors.type && (
            <div className="text-danger">{errors.type.message}</div>
          )}
        </div>

        <div className="form-group mb-3">
          <label className="form-label">Created By:</label>
          <select
            id="createdBy"
            className="form-select"
            style={{ borderColor: errors.createdBy ? "red" : "#ced4da" }}
            {...register("createdBy")}
          >
            <option value="">Select Role</option>
            <option value="designManager">Design Manager</option>
            <option value="itTeamLead">IT Team Lead</option>
            <option value="projectManager">Project Manager</option>
            <option value="admin">Admin</option>
          </select>
          {errors.createdBy && (
            <div className="text-danger">{errors.createdBy.message}</div>
          )}
        </div>

        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>
    </div>
  );
};

export default UpdateProject;
