import React from "react";
import DataTable from "react-data-table-component";
import { useGetProjectsQuery } from "../../../redux/services/projectApi/projectApi";
import { useNavigate, Link } from "react-router-dom";

const ProjectLists = () => {
  const navigate = useNavigate();

  const { data, isLoading } = useGetProjectsQuery();
  const projects = data?.data;
  // console.log(projects);

  const columns = [
    {
      name: "S.no",
      selector: (row, index) => index + 1,
      sortable: true,
    },
    {
      name: "Project Name",
      selector: "projectName",
      sortable: true,
      style: {
        background: "#d3d3d3",
      },
    },
    {
      name: "Type",
      selector: "type",
      sortable: true,
    },
    {
      name: "Created By",
      selector: "createdBy",
      sortable: true,
      style: {
        background: "#d3d3d3",
      },
    },
    {
      name: "createdAt",
      selector: (row) => (
        <>
          <div>{new Date(row.createdAt).toLocaleDateString()}</div>
          <div>{new Date(row.createdAt).toLocaleTimeString()}</div>
        </>
      ),
      sortable: true,
    },
    {
      name: "Actions",
      cell: (row) => (
        <button className="btn btn-primary" onClick={() => navigate(`/updateproject/${row._id}`)}>
          Update
        </button>
      ),
    },
  ];

  if (isLoading) {
    return <h5>Loading...</h5>;
  }

  return (
    <>
      <h1>Projects</h1>
      <div className="mb-4">
        <Link className="btn btn-primary" to={"/admin/projects"}>Add Project</Link>
      </div>

      <div>
        <h5>Existing Projects</h5>
      </div>
      <DataTable
        columns={columns}
        data={projects || []}
        pagination
        paginationPerPage={10}
        striped
        highlightOnHover
        responsive
      />
    </>
  );
};

export default ProjectLists;
