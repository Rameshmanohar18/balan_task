import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup';
import {useAddProjectMutation} from '../../../redux/services/projectApi/projectApi'
import { useNavigate, Link } from 'react-router-dom';
import Swal from 'sweetalert2';

const schema = yup.object().shape({
  projectName: yup.string().required('Project name is required').min(3, "ProjectName should contain atleaset 3 characters")
  .matches(/[A-Za-z]/, "ProjectName should contain alphabets")
  .trim(),
  type: yup.string().required('Project type is required'),
  createdBy: yup.string().required('Created by is required'),
});

const Projects = () => {
  const navigate = useNavigate();
  const [addProject] = useAddProjectMutation();

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    resolver: yupResolver(schema),mode:"all"
  });

  const onSubmit = async (data) => {
    try {
      console.log('Form submitted:', data);
      const res = await addProject({ projectData: data });
      
      if (res.error) {
       
        console.error('Error adding project:', res.error);
        return;
      }
  
    
      Swal.fire({
        icon: 'success',
        title: 'Project Added Successfully!',
        showConfirmButton: false,
        timer: 1500,
      }).then(() => {
     
        reset();
        navigate('/admin/projectslist');
      });
      
  
    } catch (error) {
      console.error('Error adding project:', error);
   
    }
  };
  

  return (
    <div className="container" style={{ padding: 20, border: '1px solid #ccc' }}>
    <h1>Add Projects</h1>
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="form-group mb-3">
        <label className="form-label">Project Name:</label>
        <input
          type="text"
          id="projectName"
          className="form-control"
          style={{ borderColor: errors.projectName ? 'red' : '#ced4da' }}
          {...register('projectName')}
        />
        {errors.projectName && <div className="text-danger">{errors.projectName.message}</div>}
      </div>

      <div className="form-group mb-3">
        <label className="form-label">Project Type:</label>
        <select id="type" className="form-select" style={{ borderColor: errors.type ? 'red' : '#ced4da' }} {...register('type')}>
        <option value="">Select Type</option>
            <option value="New">New</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Closed">Closed</option>
            <option value="Re-opened">Re-opened</option>
        </select>
        {errors.type && <div className="text-danger">{errors.type.message}</div>}
      </div>

      <div className="form-group mb-3">
        <label className="form-label">Created By:</label>
        <select id="createdBy" className="form-select" style={{ borderColor: errors.createdBy ? 'red' : '#ced4da' }} {...register('createdBy')}>
          <option value="">Select Role</option>
          <option value="designManager">Design Manager</option>
          <option value="itTeamLead">IT Team Lead</option>
          <option value="projectManager">Project Manager</option>
          <option value="admin">Admin</option>
        </select>
        {errors.createdBy && <div className="text-danger">{errors.createdBy.message}</div>}
      </div>

      <button type="submit" className="btn btn-primary">Submit</button>
    </form>
  </div>
  );
};

export default Projects;