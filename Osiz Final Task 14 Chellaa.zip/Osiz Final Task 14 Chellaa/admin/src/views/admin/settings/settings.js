import React from "react";
import { Link } from "react-router-dom";
import { useGetAdminDetailsQuery } from "../../../redux/services/adminAPI"

const settings = () => {
    const {data, isLoading, isError} = useGetAdminDetailsQuery();

    const adminId = data?.data?._id;
    const adminMail = data?.data?.email
    console.log(adminId);
  return (
    <div>
      {" "}
      <div>
        <div>
          <Link className="btn btn-primary mt-3" to={`/changePassword/${adminId}`}>Change Password</Link>
        </div>
      </div>
      <div>
        <div>
          <Link className="btn btn-primary mt-3" to={`/changePattern/${adminId}`}>Change Pattern</Link>
        </div>
      </div>
      <div>
        <div>
          <Link className="btn btn-primary mt-3" to={`/security/${adminMail}`}>2FA(Enable/Disable)</Link>
        </div>
      </div>
    </div>
  );
};

export default settings;
