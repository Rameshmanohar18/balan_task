import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useLocation, Link, useNavigate } from "react-router-dom";
import { useGenerateOtpMutation } from "../../../redux/services/changePasswordApi/changePasswordApi";
import { toast } from "react-toastify";
import OTPInput from "react-otp-input";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import Swal from "sweetalert2";

const schema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .email("Invalid email address").trim(),
});

const ForgotPassword = () => {
  const [modal, setModal] = useState(false);
  const [modatOTP, setModalOTP] = useState("");
  const [responseOTP, setResponseOTP] = useState(null);
  const [otpAttempts, setOtpAttempts] = useState(0);
  const [adminMail, setAdminMail] = useState("");
  const [processMethod, setProcessMethod] = useState("");
  const [generateOTP] = useGenerateOtpMutation();
  const location = useLocation();
  const { method } = location.state || {};

  const navigate = useNavigate();

  useEffect(() => {
    if (method) {
      localStorage.setItem("ProcessMethod", method);
    }
    const timeoutId = setTimeout(() => {
        if (responseOTP !== null) {
          setResponseOTP(null);
          toast.warning("OTP expired");
          setModal(false)
          reset();
        }
      }, 30000);
  
   
      return () => clearTimeout(timeoutId);
  }, [method, responseOTP]);

  const renderInput = (props, index) => {
    return (
      <input
        key={index}
        {...props}
        style={{
          width: "40px",
          height: "40px",
          marginRight: "5px",
          textAlign: "center",
          backgroundColor: "gray",
        }}
      />
    );
  };

  const {
    register,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = async (data) => {
    try {
   
      setAdminMail(data.email);
      const res = await generateOTP(data);

      if (res.error) {
        toast.error(res?.error?.data.error);
        reset();
        return;
      } else {
        const otp = res?.data?.OTP;
        toast.success(`Your OTP is ${otp}`);
        setResponseOTP(otp);
      }

      const alert = Swal.fire({
        position: "center",
        icon: "success",
        title: "OTP has been sent to your mail",
        showConfirmButton: false,
        timer: 2000,
      });
      if (alert) {
        setTimeout(() => {
          toggle();
        }, 2000);
      }
    } catch (error) {
      console.error("An error occurred:", error);
      toast.error("Something went wrong");
    }
  };

  const toggle = () => {
    setModal(!modal);
    setModalOTP("");
  };


  const handleVerify = () => {
    const storedProcessMethod = localStorage.getItem("ProcessMethod");

    if (modatOTP == responseOTP) {
      setOtpAttempts(0);
      setModalOTP("");
      toggle();
      toast.success("OTP verified");
      setTimeout(() => {
        if (storedProcessMethod === "forgot password") {
          navigate(`/setnewpassword/${adminMail}`);
        } else if (storedProcessMethod === "forgot pattern") {
          navigate(`/setnewpattern/${adminMail}`);
        }

        localStorage.removeItem("ProcessMethod");
      }, 2000);
    } else {
      setOtpAttempts(otpAttempts + 1);

      if (otpAttempts >= 2) {
        toast.error("Process Cancelled! Please Try again!");
        setResponseOTP(null);
        setOtpAttempts(0);
        toggle();
        reset();
      } else {
        toast.error("Incorrect OTP! Try again");
      }
    }
  };

  const handleCancel = () => {
    setOtpAttempts(0);
    toggle();
    setResponseOTP(null);
    reset();
    // navigate("/register");
    toast.error(" Process cancelled");
  };


  console.log(responseOTP);

  return (
    <main>
      <div className="container d-flex justify-content-center align-items-center vh-100">
        <form className="col-12 col-md-6" onSubmit={handleSubmit(onSubmit)}>
          <h4>Forgot Password?</h4>
          <h6>Submit your email</h6>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">
              Email:
            </label>
            <input
              {...register("email")}
              type="text"
              className={`form-control ${errors.email ? "is-invalid" : ""}`}
              id="email"
              placeholder="Enter your email"
            />
            {errors.email && (
              <div className="invalid-feedback">{errors.email.message}</div>
            )}
          </div>
          <div className="mb-3">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </form>
      </div>

      {/* Modal */}
      <Modal
        isOpen={modal}
        toggle={toggle}
        modalClassName="CmmnMdl"
        className="modal-md "
        backdrop="static"
      >
        <ModalBody>
          <div class="MdlHdr BrdBttm pb-3 mb-3 ">
            <div class="StkMdlHdd ">
              <h4 class="mb-0 ">
                <span>Verfiy </span> Your Mail
              </h4>
            </div>
            <div class="MdlClose ">
              <button class="btn btn-link p-0 " type="button " onClick={toggle}>
                <svg
                  xmlns="http://www.w3.org/2000/svg "
                  width="11 "
                  height="11 "
                  viewBox="0 0 11 11 "
                  fill="none "
                >
                  <path d="M1 1L10.5 10.5 " stroke="white " />
                  <path d="M1 10.5L10.5 1 " stroke="white " />
                </svg>
              </button>
            </div>
          </div>
          <div className="modal-body">
            <OTPInput
              value={modatOTP}
              onChange={(modatOTP) => setModalOTP(modatOTP)}
              numInputs={6}
              renderSeparator={
                <span
                  style={{
                    color: "gold",
                    marginRight: "5px",
                  }}
                >
                  -
                </span>
              }
              containerStyle={{ display: "flex", justifyContent: "center" }}
              renderInput={renderInput}
            />
          </div>
        </ModalBody>
        <div class="modal-footer">
          <Link
            onClick={handleCancel}
            className="btn BtnPrimry Btn-182-44 BtnInrpg me-3"
          >
            Cancel
          </Link>
          <button
            onClick={handleVerify}
            className="btn BtnPrimry Btn-182-44 BtnInrpg"
          >
            verify
          </button>
        </div>
      </Modal>
    </main>
  );
};

export default ForgotPassword;
