import React, { useState, useEffect } from "react";
import { useParams, useNavigate, useNavigation } from "react-router-dom";
import PatternLock from "react-pattern-lock";
import { CCard, CCardBody, CButton } from "@coreui/react";
import Swal from "sweetalert2";
import { useChangeAdminPatternMutation } from "../../../redux/services/changePasswordApi/changePasswordApi"
import { toast } from "react-toastify";

const ChangePattern = () => {
    const params = useParams();
    const adminID = params.id;
    // console.log(adminID);
    const [oldPattern, setOldPattern] = useState([]);
    const [patternOne, setPatternOne] = useState([]);
    const [patternTwo, setPatternTwo] = useState([]);
    const [isPatternMatched, setIsPatternMatched] = useState(true);
    const [arePatternsInitiallySet, setArePatternsInitiallySet] = useState(false);

    const [changeAdminPattern] = useChangeAdminPatternMutation();
     
    const navigate = useNavigate();
  
    useEffect(() => {
  
      const arePatternsEqual = JSON.stringify(patternOne) === JSON.stringify(patternTwo);
      setIsPatternMatched(arePatternsEqual);
    }, [patternOne, patternTwo]);
  
    const handlePatternFinish = (newPattern) => {
      console.log("Pattern completed:", newPattern);
    };
  
    const onChange = (newPattern, patternType) => {
      
      if (patternType === "patternOne") {
        setPatternOne(newPattern);
      } else {
        setPatternTwo(newPattern);
        setArePatternsInitiallySet(true); 
      }
    };
  
    const handleSubmit = async () => {

      if (!patternTwo.length) {
        toast.error("Please draw a pattern");
        return;
      }
      if (patternTwo.length < 3) {
        toast.error("Pattern should be in atleat 3 dots");
        return;
      }
      
      const updatedAdminPattern = ({oldPattern, patternTwo, adminID});
    //   console.log(updatedPattern);
      const result = await changeAdminPattern(updatedAdminPattern);
      console.log(result);
      if(result.error){
        toast.error(result.error.data.error)
        return
      }
      if(result.data){
        Swal.fire({
          icon: "success",
          title: "Pattern Updated Successfully!",
          text: result.data.message,
          confirmButtonColor: "#3085d6",
          confirmButtonText: "OK",
        }).then((result) => {
          if (result.isConfirmed) {
            setOldPattern([])
            setPatternOne([])
            setPatternTwo([])
            navigate('/dash/dashboard');
          }
        });
      }
  
    };
  
    const handleReset = (patternType) => {
      if (patternType === "patternOne") {
        setPatternOne([]);
      } else {
        setPatternTwo([]);
        setIsPatternMatched(true);
        setArePatternsInitiallySet(false); 
      }
    };

    // console.log(oldPattern);
  
  return (
    <main>
    <h3 className="text-center mt-5">Set New Pattern</h3>
    <div className="mt-5" style={{ display: "flex", justifyContent: "center" }}>
        {/* Old Pattern */}
    <CCard className="text-dark py-5" style={{ width: "44%" }}>
        <CCardBody className="text-center">
          <div>
            <div className="my-2">
              <label>Old Pattern</label>
              <div className="d-flex justify-content-center">
                <PatternLock
                  width={200}
                  pointSize={15}
                  size={3}
                  
                  path={oldPattern}
                  onChange={(newPattern) => setOldPattern(newPattern)}
                  onFinish={handlePatternFinish}
                  style={{
                    background: "#0b80f2",
                    borderRadius: "16px",
                  }}
                />
              </div>
            </div>
            <CButton onClick={() => setOldPattern([])} color="warning" className="mt-2">
              Reset Pattern
            </CButton>
          </div>
        </CCardBody>
      </CCard>

      {/* New Patterns  */}
      <CCard className="text-dark py-5" style={{ width: "44%" }}>
        <CCardBody className="text-center">
          <div>
            <div className="my-2">
              <label>New Pattern</label>
              <div className="d-flex justify-content-center">
                <PatternLock
                  width={200}
                  pointSize={15}
                  size={3}
                  
                  path={patternOne}
                  onChange={(newPattern) => onChange(newPattern, "patternOne")}
                  onFinish={handlePatternFinish}
                  style={{
                    background: "#0b80f2",
                    borderRadius: "16px",
                  }}
                />
              </div>
            </div>
            <CButton onClick={() => handleReset("patternOne")} color="warning" className="mt-2">
              Reset Pattern
            </CButton>
          </div>
        </CCardBody>
      </CCard>
      <CCard className="text-dark py-5" style={{ width: "44%" }}>
        <CCardBody className="text-center">
          <div>
            <div className="my-2">
              <label>Confirm New Pattern</label>
              <div className="d-flex justify-content-center">
                <PatternLock
                  width={200}
                  pointSize={15}
                  size={3}
              
                  path={patternTwo}
                  onChange={(newPattern) => onChange(newPattern, "patternTwo")}
                  onFinish={handlePatternFinish}
                  style={{
                    background: isPatternMatched ? "#0b80f2" : "#f24949",
                    borderRadius: "16px",
                  }}
                />
              </div>
            </div>
            <CButton onClick={() => handleReset("patternTwo")} color="warning" className="mt-2">
              Reset Pattern
            </CButton>
          </div>
        </CCardBody>
      </CCard>
    </div>
    <div className="text-center mt-3">
      <CButton
        onClick={handleSubmit}
        color="primary"
        className="mr-2"
        disabled={!arePatternsInitiallySet || !isPatternMatched}
      >
        Submit
      </CButton>
      {!isPatternMatched && arePatternsInitiallySet && (
        <p className="text-danger mt-2">Patterns do not match. Please try again.</p>
      )}
    </div>
  </main>
  )
}

export default ChangePattern