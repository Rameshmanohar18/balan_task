import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useParams, useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useSetNewPwdMutation } from "../../../redux/services/changePasswordApi/changePasswordApi";
import Swal from "sweetalert2";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";

const schema = yup.object().shape({
  newPassword: yup
    .string()
    .required("Password is required")
    .matches(/[A-Z]/, "Password Must Contain atlease One UpperCase Letter")
    .matches(/[0-9]/, "Password Must Contain atlease One Number")
    .matches(
      /[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/,
      "Password Must Contain atlease One Special Character.. like @#$"
    )
    .trim()
    .min(8, "Password must be at least 8 characters"),
  confirmNewPassword: yup
    .string()
    .oneOf([yup.ref("newPassword"), null], "Passwords must match")
    .required("Confirm New Password is required"),
});

const SetNewPassword = () => {
  const params = useParams();
  const adminEmail = params.email;
  const [setNewPwd] = useSetNewPwdMutation();
  const [showPassword, setShowPassword] = useState(false);
  const [showCnfrmPassword, setShowCnfrmPassword] = useState(false);
  const navigate = useNavigate();
  const {
    handleSubmit,
    reset,
    register,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    mode: "all",
  });

  const onSubmit = async (data) => {
    // Handle form submission logic here

    const updatedData = { ...data, adminEmail };
    const response = await setNewPwd(updatedData);
    // console.log(response);
    if (response.data) {
      Swal.fire({
        icon: "success",
        title: "Password Updated Successfully!",
        text: response.data.message,
        confirmButtonColor: "#3085d6",
        confirmButtonText: "OK",
      }).then((result) => {
        if (result.isConfirmed) {
          reset();
          navigate("/");
        }
      });
    }
  };

  //PASSWORD VISIBILITY
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  //PASSWORD VISIBILITY
  const toggleCnfrmPasswordVisibility = () => {
    setShowCnfrmPassword(!showCnfrmPassword);
  };

  return (
    <div className="container d-flex align-items-center justify-content-center min-vh-100">
      <div className="card p-4">
        <h2 className="text-center mb-4">Set New Password</h2>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="mb-3">
            <label htmlFor="newPassword" className="form-label">
              New Password:
            </label>
            <div className="input-group">
              <input
                type={showPassword ? "text" : "password"}
                className={`form-control ${
                  errors.newPassword ? "is-invalid" : ""
                }`}
                {...register("newPassword")}
              />
              <button
                type="button"
                className="input-group-text border"
                onClick={togglePasswordVisibility}
                style={{
                  borderRadius: "none",
                }}
              >
                {showPassword ? (
                  <FontAwesomeIcon
                    icon={faEyeSlash}
                    style={{ color: "black" }}
                  />
                ) : (
                  <FontAwesomeIcon icon={faEye} style={{ color: "black" }} />
                )}
              </button>
              <div className="invalid-feedback">
                {errors.newPassword?.message}
              </div>
            </div>
          </div>
          <div className="mb-3">
            <label htmlFor="confirmNewPassword" className="form-label">
              Confirm New Password:
            </label>
            <div className="input-group">
              <input
                type={showCnfrmPassword ? "text" : "password"}
                className={`form-control ${
                  errors.confirmNewPassword ? "is-invalid" : ""
                }`}
                {...register("confirmNewPassword")}
              />
              <button
                type="button"
                className="input-group-text border"
                onClick={toggleCnfrmPasswordVisibility}
                style={{
                  borderRadius: "none",
                }}
              >
                {showCnfrmPassword ? (
                  <FontAwesomeIcon
                    icon={faEyeSlash}
                    style={{ color: "black" }}
                  />
                ) : (
                  <FontAwesomeIcon icon={faEye} style={{ color: "black" }} />
                )}
              </button>
              <div className="invalid-feedback">
                {errors.confirmNewPassword?.message}
              </div>
            </div>
          </div>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default SetNewPassword;
