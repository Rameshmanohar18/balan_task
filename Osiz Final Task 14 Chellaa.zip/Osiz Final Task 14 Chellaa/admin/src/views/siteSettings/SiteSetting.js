import React from "react";
import DataTable from "react-data-table-component";
import { useNavigate } from "react-router-dom";
import { useGetContentQuery } from "../../redux/services/contentsApi/contentsApi";

const SiteSetting = () => {
  const navigate = useNavigate();
  const { data, isLoading, isError } = useGetContentQuery();
  const contents = data?.data;
  console.log(contents);

  const columns = [
    {
      name: "S.No",
      selector: (row, index) => index + 1,
      sortable: true,
    },
    {
      name: "Content ID",
      selector: "_id",
      sortable: true,
      style: {
        background: "#d3d3d3",
      },
    },
    {
      name: "Content",
      selector: "content",
      sortable: true,
    },
    {
      name: "Data",
      cell: (row) => (
        <div dangerouslySetInnerHTML={{ __html: row?.editorData }} />
      ),
    },
    {
      name: "Action",
      cell: (row) => (
        <button
          className="btn btn-primary"
          onClick={() => navigate(`/ckeditor/${row?._id}`)}
        >
          Edit
        </button>
      ),
    },
  ];

  if (isLoading) {
    return <h1>Loading...</h1>;
  }

  return (
    <>
      <div>
        <h3>Add Content</h3>
        <button
          className="btn btn-primary mt-3"
          onClick={() => navigate("/addcontent")}
        >
          Add Content
        </button>
      </div>
      <div className="mt-5">
        <h2>Contents Table</h2>
        <DataTable
          columns={columns}
          data={contents || []}
          pagination
          paginationPerPage={10}
          striped
          highlightOnHover
          responsive
        />
      </div>
    </>
  );
};

export default SiteSetting;
