
import React, { useEffect, useState } from "react";
import {
  useGetUserByIdQuery,
  useKycUpdateMutation,
} from "../../redux/services/adminAPI";
import { useParams, useNavigate } from "react-router-dom";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import Swal from "sweetalert2";

const KycDetail = () => {
  const [frontsideStatus, setFrontsideStatus] = useState(null);
  const [backsideStatus, setBacksideStatus] = useState(null);
  const [showFrontsideButtons, setShowFrontsideButtons] = useState(true);
  const [showBacksideButtons, setShowBacksideButtons] = useState(true);
  const [content, setContent] = useState(null);

  const [isEditorEmpty, setIsEditorEmpty] = useState(true);
  const params = useParams();
  const userID = params.id;
  const navigate = useNavigate();
  // console.log(userID);

  const { data, isLoading, isError } = useGetUserByIdQuery(userID);
  const userDetail = data?.data.kyc;
  // console.log(userDetail);


  const userKycStatus = userDetail?.isApproved;
  // console.log(userKycStatus);

  const [kycUpdate] = useKycUpdateMutation();

  // Ck editor Data
  const handleData = (event, editor) => {
    const data = editor.getData();
    setContent(data);
    setIsEditorEmpty(data.length === 0);
  };

  const handleApprove = (side) => {
    if (side === "front") {
      setFrontsideStatus("approved");
      setShowFrontsideButtons(false);
      document.getElementById("frontside-error").innerHTML = ""; // Clear error message
    } else {
      setBacksideStatus("approved");
      setShowBacksideButtons(false);
      document.getElementById("backside-error").innerHTML = ""; // Clear error message
    }
  };

  const handleDecline = (side) => {
    if (side === "front") {
      setFrontsideStatus("declined");
      setShowFrontsideButtons(false);
      document.getElementById("frontside-error").innerHTML = ""; // Clear error message
    } else {
      setBacksideStatus("declined");
      setShowBacksideButtons(false);
      document.getElementById("backside-error").innerHTML = ""; // Clear error message
    }
  };

  const getStatusColorClass = (status) => {
    switch (status) {
      case "approved":
        return "text-success";
      case "declined":
        return "text-danger";
      default:
        return "";
    }
  };

  const handleSubmit = async () => {
    // Check for frontside image status
    if (frontsideStatus !== "approved" && frontsideStatus !== "declined") {
      document.getElementById("frontside-error").innerHTML = "Action required";
      return;
    } else {
      document.getElementById("frontside-error").innerHTML = ""; // Clear error message
    }

    // Check for backside image status
    if (backsideStatus !== "approved" && backsideStatus !== "declined") {
      document.getElementById("backside-error").innerHTML = "Action required";
      return;
    } else {
      document.getElementById("backside-error").innerHTML = ""; // Clear error message
    }

    const approvalStatus = {
      frontSideStatus: frontsideStatus === "approved" ? "Approved" : "Declined",
      backSideStatus: backsideStatus === "approved" ? "Approved" : "Declined",
      editorData: content,
    };

    const res = await kycUpdate({ id: userID, formData: approvalStatus });
    console.log(res);
    if (res?.data) {
      Swal.fire({
        icon: "success",
        title: "KYC updated!",
        text: "KYC Updated successfully...!",
      }).then(() => {
        navigate("/users");
      });
    }

    console.log(approvalStatus);
  };


  return (
    <div className="container mt-5">
      {userDetail?.upload.frontProof !== undefined ? (
        <>
          {" "}
          <div className="card p-5">
            <div className="card-body">
              <h3 className="card-title">KycDetail</h3>
               {/* Status  */}
              <p className="card-text mt-3">
                <strong>KYC Status:</strong> {userKycStatus ? <span>Approved</span> : <span>Pending</span>}
              </p>

              {/* Username */}
              <p className="card-text">
                <strong>Username:</strong> {userDetail?.username}
              </p>

              {/* Mobile */}
              <p className="card-text">
                <strong>Mobile:</strong> {userDetail?.mobile}
              </p>

              {/* Address */}
              <p className="card-text">
                <strong>Address:</strong> {userDetail?.address}
              </p>

                    {/* Account */}
                    <p className="card-text">
                <strong>Account No:</strong> {userDetail?.accountNo}
              </p>

              {/* User's Last Update */}
              <p className="card-text">
                <strong className="me-2">User's Last Update:</strong> <span>
                          {" "}
                          {new Date(userDetail?.userLastUpdate).toLocaleDateString()}
                        </span>
                        <span>
                          {" "}
                          {new Date(userDetail?.userLastUpdate).toLocaleTimeString()}
                        </span>
              </p>

              <div className="row">
                {/* Frontside Image */}
                <div className="col-md-6">
                  <img
                    src={`http://localhost:8000/${userDetail?.upload.frontProof}`}
                    alt="Frontside Image"
                    className="img-fluid"
                    style={{ width: "200px", height: "200px" }}
                  />
                
                  <div className="mt-2">
                    {showFrontsideButtons && !userKycStatus && (
                      <>
                        <button
                          type="button"
                          className="btn btn-success me-2"
                          onClick={() => handleApprove("front")}
                        
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          className="btn btn-danger"
                          onClick={() => handleDecline("front")}
                         
                        >
                          Decline
                        </button>
                      </>
                    )}
                    {!showFrontsideButtons && (
                      <p className={getStatusColorClass(frontsideStatus)}>
                        Frontside:{" "}
                        {frontsideStatus === "approved"
                          ? "Approved"
                          : "Declined"}
                      </p>
                    )}
                    <p id="frontside-error" className="text-danger"></p>
                  </div>
                </div>

                {/* Backside Image */}
                <div className="col-md-6">
                  <img
                    src={`http://localhost:8000/${userDetail?.upload.backProof}`}
                    alt="Backside Image"
                    className="img-fluid"
                    style={{ width: "200px", height: "200px" }}
                  />
              
                  <div className="mt-2">
                    {showBacksideButtons && !userKycStatus && (
                      <>
                        <button
                          type="button"
                          className="btn btn-success me-2"
                          onClick={() => handleApprove("back")}
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          className="btn btn-danger"
                          onClick={() => handleDecline("back")}
                        >
                          Decline
                        </button>
                      </>
                    )}
                    {!showBacksideButtons && (
                      <p className={getStatusColorClass(backsideStatus)}>
                        Backside:{" "}
                        {backsideStatus === "approved"
                          ? "Approved"
                          : "Declined"}
                      </p>
                    )}
                    <p id="backside-error" className="text-danger"></p>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-3">
              {!userKycStatus ? (
                <>
                  {" "}
                  <label className="mb-2">Comments:</label>
                  <CKEditor
                    editor={ClassicEditor}
                    style={{ height: "200px" }}
                    onChange={handleData}
                  />{" "}
                </>
              ) : (
                <></>
              )}
            </div>

            <div className="card-footer bg-white">
              {/* Submit Button */}
              {!userKycStatus ? (
                <button
                  type="button"
                  className="btn btn-primary btn-lg mt-4"
                  onClick={handleSubmit}
                >
                  Submit
                </button>
              ) : (
                <></>
              )}
            </div>
          </div>
        </>
      ) : (
        <>
          <div>
            <h3>KYC Details Not Uploaded Yet!</h3>
          </div>
        </>
      )}
    </div>
  );
};

export default KycDetail;
