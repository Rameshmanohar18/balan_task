import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { useNavigate, useParams } from "react-router-dom";
import {
  useHandleTwofactorAuthMutation,
  useTwoFactorDisableMutation,
  useTwoFactorverifySecretCodeMutation,
} from "../../redux/services/securityApi/securityApi";
import { toast } from "react-toastify";

const schema = Yup.object().shape({
  authCode: Yup.string()
    .required("authCode is required")
    .min(6, "Enter Six Digits Number")
    .max(6, "Invalid AuthCode")
    .trim(),
  // authCode: Yup.string().required('authcode is required')
});

const Security = () => {
  const navigate = useNavigate();
  // get admin
  const params = useParams();
  // console.log(params.email);

  // Two Factor authcation RTK query
  const [handleTwoFactorAuth] = useHandleTwofactorAuthMutation();
  const [verifySecretCode] = useTwoFactorverifySecretCodeMutation();
  const [disableAuthCode] = useTwoFactorDisableMutation();

  // UseState

  const [twoFactorStatus, setTwoFactorStatus] = useState(false);
  const [twoFactorAuthCode, setTwoFactorAuthCode] = useState("");
  const [twoFactorAuthQrCode, setTwoFactorAuthQrCode] = useState("");

  // React-hook-form Data function
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema),
    mode: "all",
  });


  useEffect(() => {
    const handleTwoFactorauthData = async () => {
      try {
        const getTwoFactorReponse = await handleTwoFactorAuth({
          body: params.email,
        });
       

        const verifyTwoFactorStatus =
          getTwoFactorReponse.data.twoFactorAuthData.twoFactorAuth;
        // check Status
        if (verifyTwoFactorStatus) {
          setTwoFactorStatus(verifyTwoFactorStatus);
          return;
        }

        const secretKey =
          getTwoFactorReponse.data.twoFactorAuthData.temp_secret.base32;
        setTwoFactorAuthCode(secretKey);
        setTwoFactorAuthQrCode(getTwoFactorReponse.data.qrCodeImgSrc);
        // console.log(secretKey);
      } catch (error) {
        console.log(error);
        toast.error(error.message, {
          position: toast.POSITION.TOP_CENTER,
        });
      }
    };
    handleTwoFactorauthData();
  }, []);

  // verify TwoFactor Code
  const verifyTwoFactorAuth = async (data) => {
    const verifyReponse = await verifySecretCode({
      email: params.email,
      token: data.authCode,
    });
    if (verifyReponse.error) {
      return toast.error(verifyReponse.error.data.message, {
        position: toast.POSITION.TOP_CENTER,
      });
    }

    toast.success(verifyReponse.data.message, {
      position: toast.POSITION.TOP_CENTER,
    });
    navigate('/dash/dashboard')
  };
  // TwoFactor Disabled
  const disableTwoFactorAuthentication = async () => {
    const disableReponse = await disableAuthCode({ email: params.email});
    toast.warning(disableReponse.data.message, {
      position: toast.POSITION.TOP_CENTER,
    });
    navigate('/dash/dashboard')
  };


  return (
    <>
      <div className="usrCrPg mycollectionSec my-5">
        <div className="container-fluid">
          <div className="row justify-content-center">
            <div className="col-lg-9 p-5">
              <h4 className="collectionSecHeading text-center">
                Account Security
              </h4>
              <div className="fs-14 fw-400 text-gray mb-4">
                You need to enable Two-Factor Authentication [Enable Google 2FA]
                
              </div>
           
              <div className="fs-14 fw-400 text-gray mb-4">
                Take care of this code! To verify, please enter your one-time
                password from Google Authenticator
              </div>
              <div className="fs-20 fw-600 mb-3 ">
                {twoFactorStatus ? "" : twoFactorAuthCode}
              </div>
              {twoFactorStatus ? (
                <div>
                  <button
                    onClick={() => disableTwoFactorAuthentication()}
                    className="btn btn-primary py-2"
                    type="button"
                  >
                    Disable
                  </button>
                </div>
              ) : (
                <>
                  <form onSubmit={handleSubmit(verifyTwoFactorAuth)}>
                    <div className="row">
                      <div className="col-lg-6">
                        <div className="form-group formInputs mb-4">
                          <input
                            name="authCode"
                            className={`form-control  ${
                              errors?.authCode ? "is-invalid" : ""
                            } `}
                            {...register("authCode")}
                            type="text"
                            placeholder="Enter 2FA code"
                            style={{border: "2px solid gray"}}
                          />
                          <div className="invalid-feedback ">
                            <span style={{ margin: "13px" }}>
                              {errors?.authCode?.message}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <button className="btn btn-info gradientBtn mx-auto" type="submit">
                        Enable
                      </button>
                    </div>
                  </form>
                </>
              )}
            </div>
            <div className="col-lg-3">
              {twoFactorStatus ? (
                ""
              ) : (
                <>
                  <div className="bordercard text-center p-4">
                    <div className="fs-20 fw-600 mb-4">Enable Google 2FA</div>
                    <div className="text-center">
                      {/* <img alt="" src={qr_code} className="img-fluid" /> */}
                      <img
                        alt=""
                        src={twoFactorAuthQrCode}
                        className="img-fluid"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Security;
