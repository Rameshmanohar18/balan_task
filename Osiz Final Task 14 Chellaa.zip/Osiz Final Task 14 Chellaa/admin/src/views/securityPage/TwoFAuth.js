import React, { useEffect, useState } from "react";
import OTPInput from "otp-input-react";
import { toast } from "react-toastify";
import { useParams, useNavigate } from "react-router-dom";
import {
  useLogInAuthVerificationMutation,
  useGetQrImgQuery,
} from "../../redux/services/securityApi/securityApi";
// import { useGetAdminDetailsQuery } from "../../redux/services/adminAPI";

const TwoFAuth = () => {
  const [OTP, setOTP] = useState("");

  const params = useParams();
  const adminMail = params.email;
  // console.log(params.email);
  const navigate = useNavigate();
  // const { data, isLoading, isError } = useGetAdminDetailsQuery();
  // const authSecret = data?.data?.secret?.base32;
  // console.log(authSecret);

  const [loginAuth] = useLogInAuthVerificationMutation();

  const { data, isLoading, isError } = useGetQrImgQuery(adminMail);
  const qrData = data?.qrCodeImgSrc;
  console.log(qrData);

  const verifyAuthCode = async (e) => {
    e.preventDefault();

    if (OTP === "") {
      toast.warning("input fields cant be empty");
    }
    // console.log(OTP);
    try {
      const response = await loginAuth({ email: adminMail, token: OTP });
      // console.log(response?.data?.token);

      if (response.error) {
        toast.error(response.error.data.message, {
          position: toast.POSITION.TOP_CENTER,
        });
      } else {
        toast.success(response.data.message, {
          position: toast.POSITION.TOP_CENTER,
        });
        const token = response?.data?.token;
        localStorage.setItem("AdminToken", token);
        navigate("/dash/dashboard");
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <>
      {" "}
      <div className="container">
        {" "}
        <div className="pt-4 d-flex justify-content-evenly align-items-center twoFactor-Bg mt-5">
          <div className="col-md-6">
            <h6 className="p-3">
              Copy this secret for key generation:{" "}
              <span className="text-secondary mt-3">{data?.base32}</span>{" "}
            </h6>
            <div className="text-center mb-4">
              (OR)
            </div>
            <div>
              <h6 style={{ marginLeft: "230px" }}>Scan this QR</h6>
              <img src={qrData} alt="qr" style={{ marginLeft: "190px" }} />
            </div>
          </div>

          <div className="col-md-6">
            <div>
              <h1 className="text-center me-5">Authentication Key</h1>
            </div>
            <div className="row border p-5 rounded bg-secondary">
              <div className="col-lg-5">
                <form onSubmit={verifyAuthCode} className="">
                  <div className="mb-5">
                    <div>
                      <>
                        <h5 className="mt-5 mb-3 text-white">
                          Enter Your 2FA Authentication Key
                        </h5>
                        <OTPInput
                          value={OTP}
                          onChange={setOTP}
                          autoFocus
                          OTPLength={6}
                          otpType="number"
                          disabled={false}
                        />
                      </>
                    </div>
                    <button className="btn mt-4 btn-dark " type="submit">
                      Verify
                    </button>
                  </div>
                </form>
              </div>

              <div className="col-lg-7"></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TwoFAuth;
