import React from "react";
import { Link } from "react-router-dom";
import { useGetAdminDetailsQuery } from "../../redux/services/adminAPI";
import { useGetTicketsQuery } from "../../redux/services/ticketApi/ticketApi";
import { useGetProjectsQuery } from "../../redux/services/projectApi/projectApi";
import { useGetReportsQuery } from "src/redux/services/reportApi/reportApi";
import { CBadge } from "@coreui/react";
import { useGetUsersQuery } from "../../redux/services/adminAPI";

const AdminDashboard = () => {
  const { data, isLoading, isError } = useGetAdminDetailsQuery();

  const adminId = data?.data?._id;
  const adminMail = data?.data?.email;
  // console.log(adminId);

  const { data: allProjects, isLoading: loading } = useGetProjectsQuery();
  const projects = allProjects?.data;
  // console.log(projects);

  const { data: allTickets } = useGetTicketsQuery();
  const tickets = allTickets?.data;
  // console.log(tickets);

  const { data: allReports } = useGetReportsQuery();
  const reports = allReports?.data;
  // console.log(reports);

  const repliedReports = reports?.filter(
    (report) => report.adminComment !== ""
  );
  // console.log(repliedReports);

  const { data: regUsers } = useGetUsersQuery();
  const users = regUsers?.data;

  return (
    <div className="container-fluid vh-100">
      <h4>Admin Panel</h4>
      <h5>Mail: {data?.data?.email}</h5>
      <div className="row mt-4">
        <div className="d-flex justify-content-center">
          {/* Projects  */}
          <div className="col-md-4 border rounded">
            <div
              class="card text-white p-3"
              style={{ backgroundColor: "#0047AB" }}
            >
              <div class="card-body">
                <h4 class="card-title">Projects</h4>
                <p class="card-text">
                  Total Projects :{" "}
                  <CBadge
                    color="primary"
                    className="ms-2"
                    style={{ fontSize: "18px" }}
                  >
                    {projects?.length || 0}{" "}
                  </CBadge>
                </p>
                <p class="card-text">
                  New Projects :{" "}
                  <CBadge
                    color="primary"
                    className="ms-2"
                    style={{ fontSize: "15px" }}
                  >
                    {projects?.filter((project) => project.type === "New")
                      ?.length || 0}
                  </CBadge>
                </p>
                <p class="card-text">
                  Ongoing Projects :{" "}
                  <CBadge
                    color="primary"
                    className="ms-2"
                    style={{ fontSize: "15px" }}
                  >
                    {projects?.filter((project) => project.type === "Ongoing")
                      ?.length || 0}
                  </CBadge>
                </p>
                <p class="card-text">
                  Re-Opened Projects :{" "}
                  <CBadge
                    color="primary"
                    className="ms-2"
                    style={{ fontSize: "15px" }}
                  >
                    {projects?.filter((project) => project.type === "Re-opened")
                      ?.length || 0}
                  </CBadge>
                </p>
                <p class="card-text">
                  Closed Projects :{" "}
                  <CBadge
                    color="primary"
                    className="ms-2"
                    style={{ fontSize: "15px" }}
                  >
                    {projects?.filter((project) => project.type === "Closed")
                      ?.length || 0}
                  </CBadge>
                </p>
                <Link to="/admin/projectslist" class="btn btn-primary">
                  See List
                </Link>
              </div>
            </div>
          </div>

          {/* Tickets  */}
          <div className="col-md-4 border rounded">
            <div
              class="card text-white p-3 h-100"
              style={{ backgroundColor: "#FFAA33" }}
            >
              <div class="card-body">
                <h4 class="card-title">Tickets</h4>
                <p class="card-text">
                  Total Tickets:{" "}
                  <CBadge
                    className="ms-2 text-dark"
                    style={{ fontSize: "18px", backgroundColor: "#FFEA00" }}
                  >
                    {tickets?.length || 0}
                  </CBadge>
                </p>
                <p class="card-text">
                  Closed Tickets:{" "}
                  <CBadge
                    className="ms-2 text-dark"
                    style={{ fontSize: "15px", backgroundColor: "#FFEA00" }}
                  >
                    {tickets?.filter((ticket) => ticket.status === "Closed")
                      ?.length || 0}
                  </CBadge>
                </p>
                <p class="card-text">
                  New Tickets:{" "}
                  <CBadge
                    className="ms-2 text-dark"
                    style={{ fontSize: "15px", backgroundColor: "#FFEA00" }}
                  >
                    {tickets?.filter((ticket) => ticket.status === "New")
                      ?.length || 0}
                  </CBadge>
                </p>
                <p class="card-text">
                  In Progress:{" "}
                  <CBadge
                    className="ms-2 text-dark"
                    style={{ fontSize: "15px", backgroundColor: "#FFEA00" }}
                  >
                    {tickets?.filter((ticket) => ticket.status === "Waiting")
                      ?.length || 0}{" "}
                  </CBadge>
                </p>

                <p class="card-text">
                  Re-opened:{" "}
                  <CBadge
                    className="ms-2 text-dark"
                    style={{ fontSize: "15px", backgroundColor: "#FFEA00" }}
                  >
                    {tickets?.filter((ticket) => ticket.status === "Re-opened")
                      ?.length || 0}
                  </CBadge>
                </p>

                <Link
                  to="/tickets"
                  className="btn text-dark"
                  style={{ backgroundColor: "#FFFF00" }}
                >
                  See List
                </Link>
              </div>
            </div>
          </div>

          {/* Reports  */}
          <div className="col-md-4 border rounded">
            <div
              class="card text-white h-100 p-3"
              style={{ backgroundColor: "	#EE4B2B" }}
            >
              <div class="card-body">
                <h4 class="card-title">Reports</h4>
                <p class="card-text">
                  Reports:{" "}
                  <CBadge
                    className="ms-2 text-white"
                    style={{ fontSize: "18px", backgroundColor: "#FF0000" }}
                  >
                    {reports?.length || 0}
                  </CBadge>
                </p>

                <p class="card-text">
                  repliedReports:{" "}
                  <CBadge
                    className="ms-2 text-white"
                    style={{ fontSize: "15px", backgroundColor: "#FF0000" }}
                  >
                    {" "}
                    {repliedReports?.length || 0}
                  </CBadge>
                </p>
                <Link
                  to="/reports"
                  className="btn text-white"
                  style={{ backgroundColor: "#FF0000" }}
                >
                  See List
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        {/* Users  */}
        <div className="col-md-4 border rounded">
          <div
            class="card text-white h-100 w-100 p-3"
            style={{ backgroundColor: "#2AAA8A" }}
          >
            <div class="card-body h-100 w-100">
              <h4 class="card-title">Registered Users</h4>
              <p class="card-text">
                Users:{" "}
                <CBadge
                  className="ms-2 text-white"
                  style={{ fontSize: "18px", backgroundColor: "#009E60" }}
                >
                  {users?.length || 0}
                </CBadge>
              </p>

      
              <Link
                to="/users"
                className="btn text-white"
                style={{ backgroundColor: "#009E60" }}
              >
                See List
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
