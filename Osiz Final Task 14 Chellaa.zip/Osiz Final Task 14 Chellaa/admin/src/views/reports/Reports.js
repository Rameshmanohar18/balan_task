import React, { useState } from "react";
import DataTable from "react-data-table-component";
import { useGetReportsQuery } from "src/redux/services/reportApi/reportApi";
import { Link, useNavigate } from "react-router-dom";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { CBadge } from "@coreui/react";

const Reports = () => {
  const [userCommentModal, setUserCommentModal] = useState(false);
  const [selectedUserComment, setSelectedUserComment] = useState("");

  const { data, isLoading } = useGetReportsQuery();
  const reports = data?.data;
  const navigate = useNavigate();

  const columns = [
    {
      name: "Serial No.",
      selector: (row, index) => index + 1,
      sortable: true,
    },
    {
      name: "Report ID",
      selector: "_id",
      sortable: true,
      style: {
        background: "#d3d3d3",
      },
    },
    {
      name: "Status",
      selector: "status",
      sortable: true,
    },
    {
      name: "Created By",
      selector: "createdBy",
      sortable: true,
    },
    {
      name: "Actions",
      cell: (row) => (
        <button
          className="btn btn-primary"
          onClick={() =>
            navigate(`/reportdetail/${row?._id}`, {
              state: { createdBy: row?.createdBy },
            })
          }
        >
          Report Details
        </button>
      ),
    },
    {
      name: "User Reply",
      cell: (row) => (
        <button
          className="btn btn-primary"
          // onClick={() => {
          //   setSelectedUserComment(row.userReply);
          //   setUserCommentModal(true);
          // }}
          onClick={() =>
            navigate(`/reportdetail/${row?._id}`, {
              state: { createdBy: row?.createdBy },
            })
          }
        >
          View
          {row.userReplyStatus  ? (
            <CBadge
              className="ms-2 text-white"
              style={{ fontSize: "10px", backgroundColor: "#C70039 " }}
            >
              1 New
            </CBadge>
          ) : (
            ""
          )}
        </button>
      ),
    },
  ];

  if (isLoading) {
    return <h3>Loading...</h3>;
  }

  return (
    <>
      <div>
        <h2>All Reports</h2>
        <DataTable
          columns={columns}
          data={reports || []}
          pagination
          paginationPerPage={10}
          striped
          highlightOnHover
          responsive
        />
      </div>

      {/* admin modal  */}
      <Modal
        isOpen={userCommentModal}
        toggle={() => setUserCommentModal(!userCommentModal)}
        modalClassName="CmmnMdl"
        className="modal-sm"
        backdrop="static"
      >
        <ModalHeader className="bg-secondary text-white">
          <div className="d-flex justify-content-evenly align-items-center">
            <div>
              {" "}
              <span>User Reply</span>
            </div>
          </div>
        </ModalHeader>
        <ModalBody style={{ backgroundColor: "#D3D3D3" }}>
          <div> {selectedUserComment || "no message to show"} </div>
        </ModalBody>
        <ModalFooter className="bg-secondary">
          <button
            className="btn btn-primary  mr-2 mb-2"
            type="button"
            onClick={() => {
              setUserCommentModal(!userCommentModal);
            }}
          >
            OK
          </button>
        </ModalFooter>
      </Modal>
    </>
  );
};

export default Reports;
