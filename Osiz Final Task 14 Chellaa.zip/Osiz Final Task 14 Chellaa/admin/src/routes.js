import React from 'react'


const Dashboard = React.lazy(() => import('./views/dashboard/Dashboard'))
const AdminDashboard = React.lazy(() => import('./views/dashboard/AdminDashboard'))
const ChangePassword = React.lazy(() => import('./views/admin/changePassword/ChangePassword'))
const ChangePattern = React.lazy(() => import('./views/admin/changePattern.js/ChangePattern'))

const Projects = React.lazy(() => import('./views/admin/projects/Projects'))
const ProjectList = React.lazy(() => import('./views/admin/projects/ProjectLists'))
const UpdateProject = React.lazy(() => import('./views/admin/projects/UpdateProject'))
const Settings = React.lazy(() => import('./views/admin/settings/settings'))

const Users = React.lazy(() => import('./views/users/Users'))
const Tickets = React.lazy(() => import('./views/tickets/Tickets'))
const Reports = React.lazy(() => import('./views/reports/Reports'))
const SiteSetting = React.lazy(() => import('./views/siteSettings/SiteSetting'))
const CKEditor = React.lazy(() => import('./views/ckEditor/CkEditor'))
const AddContent = React.lazy(() => import('./views/addContent/AddContent'))
const KycDetail = React.lazy(() => import('./views/kycDetails/KycDetail'))
const TicketDetail = React.lazy(() => import('./views/tickets/TicketDetail'))
const ReportDetail = React.lazy(() => import('./views/reports/ReportDetail'))
const Security = React.lazy(() => import('./views/securityPage/security'))



const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/dash/dashboard', name: 'AdminDashboard', element: AdminDashboard },

  { path: '/changePattern/:id', name: 'changePattern', element: ChangePattern },
  { path: '/changePassword/:id', name: 'ChangePassword', element: ChangePassword },
  { path: '/admin/projects', name: 'Projects', element: Projects },
  { path: '/admin/projectslist', name: 'ProjectList', element: ProjectList },
  { path: '/updateproject/:id', name: 'UpdateProject', element: UpdateProject },
  { path: '/users', name: 'Users', element: Users },
  { path: '/tickets', name: 'Tickets', element: Tickets },
  { path: '/reports', name: 'Reports', element: Reports },
  { path: '/sitesettings', name: 'SiteSetting', element: SiteSetting },
  { path: '/ckeditor/:id', name: 'CKEditor', element: CKEditor },
  { path: '/addcontent', name: 'AddContent', element: AddContent },
  { path: '/kycdetail/:id', name: 'KycDetail', element: KycDetail },
  { path: '/ticketdetail/:id', name: 'TicketDetail', element: TicketDetail },
  { path: '/reportdetail/:id', name: 'ReportDetail', element: ReportDetail },
  { path: '/security/:email', name: 'Security', element: Security },
  { path: '/settings', name: 'Settings', element: Settings },
]

export default routes
