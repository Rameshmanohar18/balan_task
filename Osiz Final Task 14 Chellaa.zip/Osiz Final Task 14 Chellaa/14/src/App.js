import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { Routes, Route, Navigate } from "react-router-dom";
import "./assets/scss/custom.scss";
import Login from "./Pages/Login";
import Register from "./Pages/Register";
import Forgot from "./Pages/Forgot";
import ChangePassword from "./Pages/ChangePassword";
import Dashboard from "./Pages/Dashboard";
import EditProfile from "./Pages/EditProfile";
import Profile from "./Pages/Profile";
import Reports from "./Pages/Reports";
import TicketDetails from "./Pages/TicketDetails";
import Ticket from "./Pages/Ticket";
import Projects from "./Pages/Projects";
import KYC from "./Pages/KYC";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Otp from "./Pages/Otp";
import PrivateRoute from "./Components/PrivateRoute";
import LoginRoute from "./Components/LoginRoute";

import SetNewPassword from "./Pages/SetNewPassword";
import PageNotFound from "./Pages/PageNotFound";
import UserReplyComp from "./Pages/UserReplyComp";
import UserTicketReply from "./Pages/UserTicketReply";


// const PrivateRoute = ({ element: Element }) => {
//   const isAuthenticated = localStorage.getItem('LoggedUserToken');
//   return isAuthenticated ? <Element /> : <Navigate to="/" />;
// };

function App() {
  return (
    <>
      <Routes>
        <Route
          path="/"
          element={
            <LoginRoute>
              <Login />
            </LoginRoute>
          }
        />
        <Route
          path="/register"
          element={
            <LoginRoute>
              <Register />
            </LoginRoute>
          }
        />
        <Route path="/forgot" element={<Forgot />} />
        <Route
          path="/change-password"
          element={
            <PrivateRoute>
              <ChangePassword />
            </PrivateRoute>
          }
        />
        <Route path="/setnewpassword/:email" element={<SetNewPassword />} />
        <Route path="/otp/:email" element={<Otp />} />

        <Route
          path="/profile"
          element={
            <PrivateRoute>
              <Profile />
            </PrivateRoute>
          }
        />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />

        <Route
          path="/kyc"
          element={
            <PrivateRoute>
              <KYC />
            </PrivateRoute>
          }
        />

        <Route
          path="/reports"
          element={
            <PrivateRoute>
              <Reports />
            </PrivateRoute>
          }
        />
        <Route
          path="/ticket-details/:id"
          element={
            <PrivateRoute>
              <TicketDetails />
            </PrivateRoute>
          }
        />
        <Route
          path="/ticket"
          element={
            <PrivateRoute>
              <Ticket />
            </PrivateRoute>
          }
        />
        <Route
          path="/projects"
          element={
            <PrivateRoute>
              <Projects />
            </PrivateRoute>
          }
        />
        <Route
          path="/edit-profile"
          element={
            <PrivateRoute>
              <EditProfile />
            </PrivateRoute>
          }
        />

        <Route
          path="/userreply/:id"
          element={
            <PrivateRoute>
              <UserReplyComp />
            </PrivateRoute>
          }
        />
         <Route
          path="/userticketreply/:id"
          element={
            <PrivateRoute>
              <UserTicketReply />
            </PrivateRoute>
          }
        />

        <Route path="*" element={<PageNotFound />} />
      </Routes>
      <ToastContainer />
    </>
  );
}

export default App;
