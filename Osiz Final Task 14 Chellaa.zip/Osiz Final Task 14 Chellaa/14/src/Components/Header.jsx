import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
} from "reactstrap";
import { useGetSingleUserQuery } from "../redux/services/userApi";


const Header = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const { data, isFetching } = useGetSingleUserQuery();
  const user = data?.data;
  // console.log(user);
  
  const navigate = useNavigate();

  const toggle = () => setDropdownOpen((prevState) => !prevState);

  const [menu, setMenu] = useState(false);

  const handleLogout = () => {

    localStorage.removeItem('LoggedUserToken');
    localStorage.removeItem('MetaAddress');
    localStorage.removeItem('MetaBalance');
    window.location.reload();
  };

  return (
    <>
      <header class="HddrBg FxdHeader">
        <div class="container-fluid">
          <nav class="navbar navbar-expand px-0">
            <div class="logo_header">
              <Link class=" ">
                <img
                  src="/static/images/logo.png"
                  class="img-fluid "
                  alt="logo"
                />
              </Link>
            </div>
            <button
              type="button "
              class="btn btn-link navbar-toggle collapsed sm-only TgglBtn d-lg-none"
              aria-controls="navbarNavAltMarkup "
              onClick={() => {
                setMenu(!menu);
              }}
            >
              <span class="plate plate7">
                <svg
                  class="burger"
                  version="1.1"
                  height="100"
                  width="100"
                  viewBox="0 0 100 100"
                >
                  <path
                    class="line line1"
                    d="M 30,35 H 60 C 63.595663,35 65,32.357023 65,30 C 65,27.642977 62.357023,25 60,25 C 57.642977,25 55,25.933659 55,30 V 77.828008"
                  />
                  <path
                    class="line line2"
                    d="M 70,35 H 50 C 46.404337,35 45,32.357023 45,30 C 45,27.642977 47.642977,25 50,25 C 52.357023,25 55,25.933659 55,30 V 77.828008"
                  />
                  <path
                    class="line line3"
                    d="M 30,50 H 55 C 58.595665,50 60.000005,47.357023 60.000005,45 C 60.000005,42.642977 57.357025,40 55,40 C 52.642977,40 50,40.933659 50,45 V 92.828008"
                  />
                  <path
                    class="line line4"
                    d="M 70,50 H 45 C 41.404337,50 40,47.357023 40,45 C 40,42.642977 42.642977,40 45,40 C 47.357023,40 50,40.933659 50,45 V 92.828008"
                  />
                  <path
                    class="line line5"
                    d="M 30,65 H 50 C 53.595665,65 55.000005,62.357023 55.000005,60 C 55.000005,57.642977 52.357025,55 50,55 C 47.642977,55 45,55.933659 45,60 V 107.82801"
                  />
                  <path
                    class="line line6"
                    d="M 70,65 H 40 C 36.404337,65 35,62.357023 35,60 C 35,57.642977 37.642977,55 40,55 C 42.357023,55 45,55.933659 45,60 V 107.82801"
                  />
                </svg>
                <svg
                  class="x"
                  version="1.1"
                  height="100"
                  width="100"
                  viewBox="0 0 100 100"
                >
                  <path class="line" d="M 34,32 L 66,68" />
                  <path class="line" d="M 66,32 L 34,68" />
                </svg>
              </span>
            </button>
            <ul class="navbar-nav ml-auto align-items-center">
              <li class="nav-item">
                <Dropdown
                  isOpen={dropdownOpen}
                  toggle={toggle}
                  className="AfrCnctWllt HddrMnuDrpdwn"
                >
                  <DropdownToggle
                    color=""
                    className="btn btn-link p-0 d-inline-flex align-items-center justify-content-between"
                  >
                    <span class="mr-2">
                    <img
                          className="updatepro userIcon"
                          src={`http://localhost:8000/${user?.profilePic}`}
                          // src= "/static/images/proim.png"
                          alt=""
                          style={{
                            width: "35px",
                            height: "35px",
                            borderRadius: "50%",
                        
                          }}
                        />
                    </span>
                    <span class="d-none d-sm-inline text-white">
                      {user?.username}
                    </span>
                    <i class="ml-md-3">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="10"
                        viewBox="0 0 16 10"
                        fill="none"
                      >
                        <path
                          d="M15 1.5L8 8.5L1 1.5"
                          stroke="white"
                          stroke-width="1.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </i>
                  </DropdownToggle>
                  <DropdownMenu right={true}>
                    <li role="menuitem" class="BrdBttm">
                      <Link to={'/edit-profile'} class="dropdown-item" >
                        <span class="mr-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="20"
                            height="20"
                            viewBox="0 0 20 20"
                            fill="none"
                          >
                            <path
                              d="M9.99992 9.99935C12.3011 9.99935 14.1666 8.13387 14.1666 5.83268C14.1666 3.5315 12.3011 1.66602 9.99992 1.66602C7.69873 1.66602 5.83325 3.5315 5.83325 5.83268C5.83325 8.13387 7.69873 9.99935 9.99992 9.99935Z"
                              stroke="white"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                            <path
                              d="M2.84155 18.3333C2.84155 15.1083 6.04988 12.5 9.99988 12.5C10.7999 12.5 11.5749 12.6083 12.2999 12.8083"
                              stroke="white"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                            <path
                              d="M18.3334 14.9993C18.3334 15.266 18.3001 15.5243 18.2334 15.7743C18.1584 16.1077 18.0251 16.4327 17.8501 16.716C17.2751 17.6827 16.2167 18.3327 15.0001 18.3327C14.1417 18.3327 13.3667 18.0077 12.7834 17.4743C12.5334 17.2577 12.3167 16.9993 12.1501 16.716C11.8417 16.216 11.6667 15.6243 11.6667 14.9993C11.6667 14.0993 12.0251 13.2744 12.6084 12.6744C13.2168 12.0494 14.0667 11.666 15.0001 11.666C15.9834 11.666 16.8751 12.091 17.4751 12.7744C18.0084 13.366 18.3334 14.1493 18.3334 14.9993Z"
                              stroke="white"
                              stroke-miterlimit="10"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                            <path
                              d="M16.2416 14.9844H13.7583"
                              stroke="white"
                              stroke-miterlimit="10"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                            <path
                              d="M15 13.7676V16.2592"
                              stroke="white"
                              stroke-miterlimit="10"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>
                        </span>
                        Edit Profile
                      </Link>
                    </li>

                    <li class="mb-0" role="menuitem">
                      <Link class="dropdown-item" onClick={handleLogout} to={'/'}>
                        <span class="mr-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 18 18"
                            fill="none"
                          >
                            <path
                              d="M6.67505 5.66969C6.90755 2.96969 8.29505 1.86719 11.3325 1.86719H11.43C14.7825 1.86719 16.125 3.20969 16.125 6.56219V11.4522C16.125 14.8047 14.7825 16.1472 11.43 16.1472H11.3325C8.31755 16.1472 6.93005 15.0597 6.68255 12.4047"
                              stroke="white"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                            <path
                              d="M11.2501 9H2.71509"
                              stroke="white"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                            <path
                              d="M4.3875 6.48828L1.875 9.00078L4.3875 11.5133"
                              stroke="white"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>
                        </span>
                        Logout
                      </Link>
                    </li>
                  </DropdownMenu>
                </Dropdown>
              </li>
            </ul>
            <div className={`hdMenu ${menu ? "menuopen" : ""}`}>
              <div class="sdwrp">
                <ul class="sdwrpMnu">
                  <li>
                    <Link to={'/dashboard'} class="active">
                      <svg
                        xmlns="http://www.w3.org/2000/svg "
                        width="20 "
                        height="20 "
                        viewBox="0 0 20 20 "
                        fill="none "
                      >
                        <path
                          fill-rule="evenodd "
                          clip-rule="evenodd "
                          d="M1 4.5C1 1.87479 1.02811 1 4.5 1C7.97189 1 8 1.87479 8 4.5C8 7.12521 8.01107 8 4.5 8C0.988927 8 1 7.12521 1 4.5Z "
                          stroke="#B7CFFF "
                          stroke-width="1.5
                    "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                        <path
                          fill-rule="evenodd "
                          clip-rule="evenodd "
                          d="M12 4.5C12 1.87479 12.0281 1 15.5 1C18.9719 1 19 1.87479 19 4.5C19 7.12521 19.0111 8 15.5 8C11.9889 8 12 7.12521 12 4.5Z "
                          stroke="#B7CFFF "
                          stroke-width="1.5
                    "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                        <path
                          fill-rule="evenodd "
                          clip-rule="evenodd "
                          d="M1 15.5C1 12.8748 1.02811 12 4.5 12C7.97189 12 8 12.8748 8 15.5C8 18.1252 8.01107 19 4.5 19C0.988927 19 1 18.1252 1 15.5Z "
                          stroke="#B7CFFF "
                          stroke-width="1.5
                    "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                        <path
                          fill-rule="evenodd "
                          clip-rule="evenodd "
                          d="M12 15.5C12 12.8748 12.0281 12 15.5 12C18.9719 12 19 12.8748 19 15.5C19 18.1252 19.0111 19 15.5 19C11.9889 19 12 18.1252 12 15.5Z "
                          stroke="#B7CFFF
                    "
                          stroke-width="1.5 "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                      </svg>
                      <span>Dashboard</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={'/projects'} class=" ">
                      <svg
                        xmlns="http://www.w3.org/2000/svg "
                        width="24 "
                        height="24 "
                        viewBox="0 0 24 24 "
                        fill="none "
                      >
                        <g clip-path="url(#clip0_37_13925) ">
                          <path
                            d="M3 7C3 6.20435 3.31607 5.44129 3.87868 4.87868C4.44129 4.31607 5.20435 4 6 4H18C18.7956 4 19.5587 4.31607 20.1213 4.87868C20.6839 5.44129 21 6.20435 21 7V17C21 17.7956 20.6839 18.5587 20.1213 19.1213C19.5587
                    19.6839 18.7956 20 18 20H6C5.20435 20 4.44129 19.6839 3.87868 19.1213C3.31607 18.5587 3 17.7956 3 17V7Z "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                          <path
                            d="M7 10C7 10.5304 7.21071 11.0391 7.58579 11.4142C7.96086 11.7893 8.46957 12 9 12C9.53043 12 10.0391 11.7893 10.4142 11.4142C10.7893 11.0391 11 10.5304 11 10C11 9.46957 10.7893 8.96086 10.4142 8.58579C10.0391
                    8.21071 9.53043 8 9 8C8.46957 8 7.96086 8.21071 7.58579 8.58579C7.21071 8.96086 7 9.46957 7 10Z "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                          <path
                            d="M15 8H17 "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                          <path
                            d="M15 12H17 "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                          <path
                            d="M7 16H17 "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                        </g>
                        <defs>
                          <clipPath id="clip0_37_13925 ">
                            <rect width="24 " height="24 " fill="white " />
                          </clipPath>
                        </defs>
                      </svg>
                      <span>projects</span>
                    </Link>
                  </li>

                  <li>
                    <Link to={'/ticket'} class=" ">
                      <svg
                        xmlns="http://www.w3.org/2000/svg "
                        width="24 "
                        height="24 "
                        viewBox="0 0 24 24 "
                        fill="none "
                      >
                        <path
                          d="M18.5 12.6504V16.3504C18.5 19.4704 15.59 22.0004 12 22.0004C8.41 22.0004 5.5 19.4704 5.5 16.3504V12.6504C5.5 15.7704 8.41 18.0004 12 18.0004C15.59 18.0004 18.5 15.7704 18.5 12.6504Z "
                          stroke="#B7CFFF
                    "
                          stroke-width="1.5 "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                        <path
                          d="M18.5 7.65C18.5 8.56 18.25 9.4 17.81 10.12C16.74 11.88 14.54 13 12 13C9.46 13 7.26 11.88 6.19 10.12C5.75 9.4 5.5 8.56 5.5 7.65C5.5 6.09 6.22999 4.68 7.39999 3.66C8.57999 2.63 10.2 2 12 2C13.8 2 15.42
                    2.63 16.6 3.65C17.77 4.68 18.5 6.09 18.5 7.65Z "
                          stroke="#B7CFFF "
                          stroke-width="1.5 "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                        <path
                          d="M18.5 7.65V12.65C18.5 15.77 15.59 18 12 18C8.41 18 5.5 15.77 5.5 12.65V7.65C5.5 4.53 8.41 2 12 2C13.8 2 15.42 2.63 16.6 3.65C17.77 4.68 18.5 6.09 18.5 7.65Z "
                          stroke="#B7CFFF "
                          stroke-width="1.5
                    "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                      </svg>
                      <span>Tickets</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={'/reports'} class=" ">
                      <svg
                        xmlns="http://www.w3.org/2000/svg "
                        width="20 "
                        height="20 "
                        viewBox="0 0 20 20 "
                        fill="none "
                      >
                        <path
                          fill-rule="evenodd "
                          clip-rule="evenodd "
                          d="M10 0.75C15.108 0.75 19.25 4.891 19.25 10C19.25 15.108 15.108 19.25 10 19.25C4.891 19.25 0.75 15.108 0.75 10C0.75 4.891 4.891 0.75 10 0.75Z "
                          stroke="#B7CFFF
                    "
                          stroke-width="1.5 "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                        <path
                          d="M9.99414 6.2041V10.6231 "
                          stroke="#B7CFFF "
                          stroke-width="1.5 "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                        <path
                          d="M9.995 13.7959H10.005 "
                          stroke="#B7CFFF "
                          stroke-width="2 "
                          stroke-linecap="round "
                          stroke-linejoin="round "
                        />
                      </svg>
                      <span>Reports</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={'/profile'}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg "
                        width="24 "
                        height="24 "
                        viewBox="0 0 24 24 "
                        fill="none "
                      >
                        <g clip-path="url(#clip0_37_13918) ">
                          <path
                            d="M3 12C3 13.1819 3.23279 14.3522 3.68508 15.4442C4.13738 16.5361 4.80031 17.5282 5.63604 18.364C6.47177 19.1997 7.46392 19.8626 8.55585 20.3149C9.64778 20.7672 10.8181 21 12 21C13.1819 21 14.3522 20.7672
                    15.4442 20.3149C16.5361 19.8626 17.5282 19.1997 18.364 18.364C19.1997 17.5282 19.8626 16.5361 20.3149 15.4442C20.7672 14.3522 21 13.1819 21 12C21 10.8181 20.7672 9.64778 20.3149 8.55585C19.8626 7.46392 19.1997 6.47177 18.364 5.63604C17.5282
                    4.80031 16.5361 4.13738 15.4442 3.68508C14.3522 3.23279 13.1819 3 12 3C10.8181 3 9.64778 3.23279 8.55585 3.68508C7.46392 4.13738 6.47177 4.80031 5.63604 5.63604C4.80031 6.47177 4.13738 7.46392 3.68508 8.55585C3.23279 9.64778 3 10.8181
                    3 12Z "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                          <path
                            d="M9 10C9 10.7956 9.31607 11.5587 9.87868 12.1213C10.4413 12.6839 11.2044 13 12 13C12.7956 13 13.5587 12.6839 14.1213 12.1213C14.6839 11.5587 15 10.7956 15 10C15 9.20435 14.6839 8.44129 14.1213 7.87868C13.5587
                    7.31607 12.7956 7 12 7C11.2044 7 10.4413 7.31607 9.87868 7.87868C9.31607 8.44129 9 9.20435 9 10Z "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                          <path
                            d="M6.16797 18.849C6.41548 18.0252 6.92194 17.3032 7.61221 16.79C8.30249 16.2768 9.13982 15.9997 9.99997 16H14C14.8612 15.9997 15.6996 16.2774 16.3904 16.7918C17.0811 17.3062 17.5874 18.0298 17.834 18.855
                    "
                            stroke="#B7CFFF "
                            stroke-width="1.5 "
                            stroke-linecap="round "
                            stroke-linejoin="round "
                          />
                        </g>
                        <defs>
                          <clipPath id="clip0_37_13918 ">
                            <rect width="24 " height="24 " fill="white " />
                          </clipPath>
                        </defs>
                      </svg>

                      <span>Profile</span>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </header>
    </>
  );
};
export default Header;
