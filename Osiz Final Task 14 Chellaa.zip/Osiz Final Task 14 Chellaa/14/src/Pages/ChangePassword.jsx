import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import Header from "../Components/Header";
import {
  useChangeNewPasswordMutation,
  useGetSingleUserQuery,
  useGetContentQuery,
} from "../redux/services/userApi";
import { toast } from "react-toastify";
import Swal from "sweetalert2";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";

const schema = yup.object().shape({
  oldPassword: yup
    .string()
    .required("Old Password is required")
    .min(8, "invalid Password"),
  newPassword: yup
    .string()
    .required("Password is required")
    .matches(/[A-Z]/, "Password Must Contain atlease One UpperCase Letter")
    .matches(/[0-9]/, "Password Must Contain atlease One Number")
    .matches(
      /[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/,
      "Password Must Contain atlease One Special Character.. like @#$"
    )
    .trim()
    .min(8, "Password must be at least 8 characters"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("newPassword"), null], "Passwords must match")
    .required("Confirm Password is required"),
});

const ChangePassword = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showCnfrmPassword, setShowCnfrmPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const { data, isFetching } = useGetSingleUserQuery();
  const user = data?.data;
  const [changeNewPwd] = useChangeNewPasswordMutation();
  const navigate = useNavigate();
  const { handleSubmit, register, formState, reset } = useForm({
    resolver: yupResolver(schema),
    mode: "all",
  });

  const { data: allContents, isLoading, isError } = useGetContentQuery();
  const contents = allContents?.data;
  const Copyrights = contents?.find(
    (content) => content.content === "copyrights"
  );

  const onSubmit = async (data) => {
    const dataWithId = { ...data, userID: user._id };
    const res = await changeNewPwd(dataWithId);
    // console.log(res);
    if (res.data) {
      Swal.fire({
        icon: "success",
        title: "Success!",
        text: "Password updated successfully!",
      }).then(() => {
        reset();
        navigate("/profile");
      });
    } else if (res.error) {
      Swal.fire({
        icon: "error",
        title: "Error!",
        text: res.error.data.error,
      });
    }
    if (res.error) {
      toast.error(res?.error?.data?.error);
      reset();
    }
  };

  //PASSWORD VISIBILITY
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  //PASSWORD VISIBILITY
  const toggleCnfrmPasswordVisibility = () => {
    setShowCnfrmPassword(!showCnfrmPassword);
  };
  //PASSWORD VISIBILITY
  const toggleNewPasswordVisibility = () => {
    setShowNewPassword(!showNewPassword);
  };

  return (
    <>
      <Header />
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12 col-md-auto col-lg-auto pgCntC-lt "></div>
          <div class="col-sm-12 col-md-12 col-lg pgCntC-rt ">
            <div class="pgCntCon ">
              <div class="pade_padding_wrap ">
                <div class="InrPgHdrSec mb-4 ">
                  <h2>Change password</h2>
                </div>
                <div class="HelpDskMain ">
                  <div class="AdTcktBtn d-flex flex-wrap ">
                    <Link
                      to="/edit-profile"
                      class="btn BtnPrimry Btn-148-40 mb-2 mr-2 "
                    >
                      Edit Profile
                    </Link>
                    <Link to="/profile" class="btn BtnPrimry Btn-148-40 mb-2 ">
                      View Profile{" "}
                    </Link>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12 mx-auto">
                    <div class="MyWlltTbbBox mt-4">
                      <form
                        onSubmit={handleSubmit(onSubmit)}
                        className="pt-md-5 pt-3 pb-3"
                      >
                        <div className="row">
                          <div className="col-md-6">
                            <div className="Frmstl mb-20">
                              <h1>Old password</h1>
                              <div className="form-group">
                                <div className="input-group">
                                  <input
                                    type={
                                      showCnfrmPassword ? "text" : "password"
                                    }
                                    className={`form-control ${
                                      formState.errors.oldPassword
                                        ? "is-invalid"
                                        : ""
                                    }`}
                                    placeholder="Enter your old password"
                                    {...register("oldPassword")}
                                  />
                                  <button
                                    type="button"
                                    className="input-group-text bg-secondary"
                                    onClick={toggleCnfrmPasswordVisibility}
                                    style={{
                                      border: "none",
                                      borderRadius: "none",
                                      backgroundColor: "#A9A9A9",
                                    }}
                                  >
                                    {showCnfrmPassword ? (
                                      <FontAwesomeIcon
                                        icon={faEyeSlash}
                                        style={{ color: "black" }}
                                      />
                                    ) : (
                                      <FontAwesomeIcon
                                        icon={faEye}
                                        style={{ color: "black" }}
                                      />
                                    )}
                                  </button>
                                  {formState.errors.oldPassword && (
                                    <div className="invalid-feedback">
                                      {formState.errors.oldPassword.message}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-6">
                            <div className="Frmstl mb-20">
                              <h1>New password</h1>
                              <div className="form-group">
                                <div className="input-group">
                                  <input
                                    type={showPassword ? "text" : "password"}
                                    className={`form-control ${
                                      formState.errors.newPassword
                                        ? "is-invalid"
                                        : ""
                                    }`}
                                    placeholder="Enter your new password"
                                    {...register("newPassword")}
                                  />
                                  <button
                                    type="button"
                                    className="input-group-text bg-secondary"
                                    onClick={togglePasswordVisibility}
                                    style={{
                                      border: "none",
                                      borderRadius: "none",
                                      backgroundColor: "#A9A9A9",
                                    }}
                                  >
                                    {showPassword ? (
                                      <FontAwesomeIcon
                                        icon={faEyeSlash}
                                        style={{ color: "black" }}
                                      />
                                    ) : (
                                      <FontAwesomeIcon
                                        icon={faEye}
                                        style={{ color: "black" }}
                                      />
                                    )}
                                  </button>
                                  {formState.errors.newPassword && (
                                    <div className="invalid-feedback">
                                      {formState.errors.newPassword.message}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-6">
                            <div className="Frmstl mb-20">
                              <h1>Confirm password</h1>
                              <div className="form-group">
                                <div className="input-group">
                                  <input
                                    type={showNewPassword ? "text" : "password"}
                                    className={`form-control ${
                                      formState.errors.confirmPassword
                                        ? "is-invalid"
                                        : ""
                                    }`}
                                    placeholder="Enter your Confirm password"
                                    {...register("confirmPassword")}
                                  />
                                  <button
                                    type="button"
                                    className="input-group-text bg-secondary"
                                    onClick={toggleNewPasswordVisibility}
                                    style={{
                                      border: "none",
                                      borderRadius: "none",
                                      backgroundColor: "#A9A9A9",
                                    }}
                                  >
                                    {showNewPassword ? (
                                      <FontAwesomeIcon
                                        icon={faEyeSlash}
                                        style={{ color: "black" }}
                                      />
                                    ) : (
                                      <FontAwesomeIcon
                                        icon={faEye}
                                        style={{ color: "black" }}
                                      />
                                    )}
                                  </button>
                                  {formState.errors.confirmPassword && (
                                    <div className="invalid-feedback">
                                      {formState.errors.confirmPassword.message}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <button
                          type="submit"
                          className="btn BtnPrimry fntsize Btn-182-44 m-auto"
                        >
                          Update
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <footer>
                <div class="FtrSecMain ">
                  <div class="container ">
                    <div class="FtrCntMain text-center ">
                      <div class="FtrCpyRt ">
                        <div
                          dangerouslySetInnerHTML={{
                            __html: Copyrights?.editorData,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default ChangePassword;
