import React, { useState, useEffect } from "react";
import OTPInput from "react-otp-input";
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import Swal from "sweetalert2";
import { toast } from "react-toastify";
import { Link } from "react-router-dom";



const Otp = () => {
  const params = useParams()
  const [otp, setOtp] = useState(null);
  const navigate = useNavigate()
  const location = useLocation();
  let randomOtp = location.state.otp || null;
  const email = params.email;
  console.log(randomOtp);
  // console.log(email);

    // OTP expiry Time
    useEffect(() => {
      const expireOtp = () => {
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "OTP Expired!",
          
        }).then(()=>{
          navigate('/forgot')
        })
      };
  
     
      if (randomOtp !== null) {
        const otpExpirationTimeout = setTimeout(expireOtp, 30000);
      
        return () => clearTimeout(otpExpirationTimeout);
      }
    }, [randomOtp]);

  const renderInput = (props, index) => {
    return (
      <input
        key={index}
        {...props}
        style={{
          width: "40px",
          height: "40px",
          marginRight: "5px",
          textAlign: "center",
          backgroundColor: "gray",
        }}
      />
    );
  };



  const handleVerify = (e) => {
    e.preventDefault()
    if(otp === randomOtp){
     navigate(`/setnewpassword/${email}`)
    }else{
       toast.error("Otp is Invalid!");
       setOtp("")
    }
  };





  return (
    <>
      <div class="LogInMainSec">
        <div class="LogInCntMain">
          <div class="container-fluid ">
            <div class="row align-items-center">
              <div class="col-lg-6 pl-0">
                <div class="LogInMainBg"></div>
              </div>
              <div class="col-lg-6 LgnFrmMain">
                <div class="LgnCntMain">
                  <div class="LgnCntSec">
                    <div class="LgnCntLogo mb-2">
                      <img
                        src="/static/images/logo.png"
                        alt=""
                        class="img-fluid"
                      />
                    </div>
                    {/* <div class="LgnCntHdd mb-5">
                      <h2>
                        <span>Forget</span> Your password?
                      </h2>
                      <p>We’ll send you a link to reset your password</p>
                    </div> */}
                    <form className="CmmnLgnFrm">
                      <h3>OTP Input here</h3>
                      <OTPInput
                        value={otp}
                        onChange={(otp) => setOtp(otp)}
                        numInputs={6}
                        renderSeparator={
                          <span
                            style={{
                              color: "gold",
                              marginRight: "5px",
                            }}
                          >
                            -
                          </span>
                        }
                        containerStyle={{
                          display: "flex",
                          marginBottom: "20px",
                        }}
                        renderInput={renderInput}
                      />
                      <button
                        onClick={handleVerify}
                        className="btn BtnPrimry Btn-182-44 BtnInrpg mb-2"
                      >
                        verify
                      </button>
                      <div className="DntRgt">
                        <p>
                          Didn’t receive the OTP ?{" "}
                          <Link className="" to={'/forgot'} state={{resendOTPEmail:email}}>
                            Resend OTP
                          </Link>
                        </p>
                      </div>
                    </form>
                  </div>
                  <div class="InrCpyRtSec text-center">
                    <p>© 2023 BTSMART. All rights reserved.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Otp;
