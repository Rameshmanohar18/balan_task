import React, { useState } from "react";
import { useUpdateReplyIdMutation } from "../redux/services/ticketApi/ticketApi";
import { useParams, useNavigate, Link } from "react-router-dom";
import Header from "../Components/Header";
import { toast } from "react-toastify";
import Swal from "sweetalert2";

const UserTicketReply = () => {
  const [userRply, setUserReply] = useState("");
  const [addReply] = useUpdateReplyIdMutation();
  const params = useParams();
  const navigate = useNavigate();
  console.log(params.id);

  //Send User Reply
  const handleUserReply = async () => {
    if(userRply === ''){
        toast.warning("Reply Field cant be empty")
    }
    console.log(userRply);
    const replyData = userRply;
    const res = await addReply({ id: params.id, replyData: replyData})
    console.log(res);
    if(res.data){
        Swal.fire({
            icon: "success",
            title: "Success!",
            text: "Reply Send!",
          }).then(() => {
            setUserReply("")
            navigate('/ticket')
          });
    }
  };

  return (
    <>
      <div class="container-fluid mt-5">
    
        <div className="row d-flex justify-content-center">
       
          <form className="border p-5">
          <h3 className="text-center">Send Reply</h3>
            <div className="col-md-12">
              <div className="Frmstl mb-20">
                <h1>Add reply</h1>
                <div className="form-group">
                  <textarea
                    value={userRply}
                    name="description"
                    id="description"
                    cols="30"
                    rows="10"
                    onChange={(e) => setUserReply(e.target.value)}
                  ></textarea>
                </div>
              </div>
            </div>
            <button
              className="btn BtnPrimry Btn-148-40 BtnScndry ml-3"
              type="button"
              onClick={handleUserReply}
            >
              Send Reply
            </button >
            <Link className="btn BtnPrimry Btn-148-40 BtnScndry ml-3 mt-4" to='/tickets'>Go back</Link>
          </form>
        </div>
      </div>
    </>
  );
};

export default UserTicketReply;
