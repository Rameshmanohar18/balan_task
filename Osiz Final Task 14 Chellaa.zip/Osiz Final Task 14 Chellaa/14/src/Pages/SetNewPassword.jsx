import React, { useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import {
  useSetNewPasswordMutation,
  useGetContentQuery,
} from "../redux/services/userApi";
import Swal from "sweetalert2";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";

const schema = yup.object().shape({
  newPassword: yup
    .string()
    .required("Password is required")
    .matches(/[A-Z]/, "Password Must Contain atlease One UpperCase Letter")
    .matches(/[0-9]/, "Password Must Contain atlease One Number")
    .matches(
      /[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/,
      "Password Must Contain atlease One Special Character.. like @#$"
    )
    .trim()
    .min(8, "Password must be at least 8 characters"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("newPassword"), null], "Passwords must match")
    .required("Confirm Password is required"),
});

const SetNewPassword = () => {
  const navigate = useNavigate();
  const params = useParams();
  const [showPassword, setShowPassword] = useState(false);
  const [showCnfrmPassword, setShowCnfrmPassword] = useState(false);
  const userEmail = params.email;

  const [setNewPassword] = useSetNewPasswordMutation();

  const { handleSubmit, register, formState } = useForm({
    resolver: yupResolver(schema),
    mode: "all",
  });

  const { data, isLoading, isError } = useGetContentQuery();
  const contents = data?.data;
  const Copyrights = contents?.find(
    (content) => content.content === "copyrights"
  );

  const onSubmit = async (data) => {
    const res = await setNewPassword({ userEmail, data });
    console.log(res);

    if (res.data) {
      Swal.fire({
        icon: "success",
        title: "OTP",
        text: "Password updated Successfully!",
      }).then(() => {
        navigate("/");
      });
    }

    if (res.error) {
      Swal.fire({
        icon: "Error",
        title: "error",
        text: "Something Went wrong!",
      });
    }
  };
  //PASSWORD VISIBILITY
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  //PASSWORD VISIBILITY
  const toggleCnfrmPasswordVisibility = () => {
    setShowCnfrmPassword(!showCnfrmPassword);
  };
  return (
    <>
      <div class="LogInMainSec">
        <div class="LogInCntMain">
          <div class="container-fluid ">
            <div class="row align-items-center">
              <div class="col-lg-6 pl-0">
                <div class="LogInMainBg"></div>
              </div>
              <div class="col-lg-6 LgnFrmMain">
                <div class="LgnCntMain">
                  <div class="LgnCntSec">
                    <div class="LgnCntLogo mb-2">
                      <img
                        src="/static/images/logo.png"
                        alt=""
                        class="img-fluid"
                      />
                    </div>
                    <form
                      onSubmit={handleSubmit(onSubmit)}
                      className="pt-md-5 pt-3 pb-3"
                    >
                      <h3 className="text-warning">Set New Password</h3>
                      <div className="row">
                        <div className="col-md-10">
                          <div className="Frmstl mb-20">
                            <h1>New password</h1>
                            <div className="form-group">
                              <div className="input-group">
                                <input
                                  type={showPassword ? "text" : "password"}
                                  className={`form-control ${
                                    formState.errors.newPassword
                                      ? "is-invalid"
                                      : ""
                                  }`}
                                  placeholder="Enter your new password"
                                  {...register("newPassword")}
                                />
                                <button
                                  type="button"
                                  className="input-group-text bg-secondary"
                                  onClick={togglePasswordVisibility}
                                  style={{
                                    border: "none",
                                    borderRadius: "none",
                                    backgroundColor: "#A9A9A9",
                                  }}
                                >
                                  {showPassword ? (
                                    <FontAwesomeIcon
                                      icon={faEyeSlash}
                                      style={{ color: "black" }}
                                    />
                                  ) : (
                                    <FontAwesomeIcon
                                      icon={faEye}
                                      style={{ color: "black" }}
                                    />
                                  )}
                                </button>
                                {formState.errors.newPassword && (
                                  <div className="invalid-feedback">
                                    {formState.errors.newPassword.message}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-10">
                          <div className="Frmstl mb-20">
                            <h1>Confirm password</h1>
                            <div className="form-group">
                              <div className="input-group">
                                <input
                                  type={showCnfrmPassword ? "text" : "password"}
                                  className={`form-control ${
                                    formState.errors.confirmPassword
                                      ? "is-invalid"
                                      : ""
                                  }`}
                                  placeholder="Enter your Confirm password"
                                  {...register("confirmPassword")}
                                />
                                <button
                                  type="button"
                                  className="input-group-text bg-secondary"
                                  onClick={toggleCnfrmPasswordVisibility}
                                  style={{
                                    border: "none",
                                    borderRadius: "none",
                                    backgroundColor: "#A9A9A9",
                                  }}
                                >
                                  {showCnfrmPassword ? (
                                    <FontAwesomeIcon
                                      icon={faEyeSlash}
                                      style={{ color: "black" }}
                                    />
                                  ) : (
                                    <FontAwesomeIcon
                                      icon={faEye}
                                      style={{ color: "black" }}
                                    />
                                  )}
                                </button>
                                {formState.errors.confirmPassword && (
                                  <div className="invalid-feedback">
                                    {formState.errors.confirmPassword.message}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <button
                        type="submit"
                        className="btn BtnPrimry fntsize Btn-182-44 "
                      >
                        Save Change
                      </button>
                    </form>
                  </div>
                  <div class="InrCpyRtSec text-center">
                    <div
                      dangerouslySetInnerHTML={{
                        __html: Copyrights?.editorData,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SetNewPassword;
