import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import Header from "../Components/Header";
import Web3 from "web3";
import {
  useGetSingleUserQuery,
  useGetContentQuery,
} from "../redux/services/userApi";

const schema = yup.object().shape({
  firstName: yup.string().required("First Name is required"),
  lastName: yup.string().required("Last Name is required"),
  username: yup.string().required("Username is required"),
  email: yup.string().email("Invalid email").required("Email is required"),
  mobile: yup.string().required("Mobile is required"),
  addressLine1: yup.string().required("Address Line 1 is required"),
  addressLine2: yup.string().required("Address Line 2 is required"),
  country: yup.string().required("Country is required"),
  pincode: yup.string().required("Pincode is required"),
});

const Profile = () => {
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState("");
  const { data, isFetching } = useGetSingleUserQuery();
  const user = data?.data;
  // console.log(user);

  const { data: cms, isLoading: buffering, isError } = useGetContentQuery();
  const contents = cms?.data;
  const Copyrights = contents?.find(
    (content) => content.content === "copyrights"
  );

  //Metamask connect and get balance
  useEffect(() => {
    const checkMetaMaskLockState = async () => {
      try {
        const web3 = new Web3(window.ethereum);

        if (web3) {
          const isUnlocked = await window.ethereum._metamask.isUnlocked();

          if (!isUnlocked) {
            setAddress("");
            setBalance("");
            console.warn("MetaMask is locked. Please unlock your wallet.");
          } else {
            const storedAddress = localStorage.getItem("address");
            const storedBalance = localStorage.getItem("balance");

            if (storedAddress) {
              setAddress(storedAddress);
            }

            if (storedBalance) {
              setBalance(storedBalance);
            }
          }
        } else {
          console.error("MetaMask not installed.");
        }
      } catch (error) {
        console.error("Error checking MetaMask lock state:", error.message);
      }
    };

    checkMetaMaskLockState();
  }, []);

  const connectWallet = async () => {
    try {
      const web3 = new Web3(window.ethereum);
      if (web3) {
        const accounts = await window.ethereum.request({
          method: "eth_requestAccounts",
        });

        setAddress(accounts[0]);
        localStorage.setItem("MetaAddress", accounts[0]);

        if (accounts.length > 0) {
          const balance = await web3.eth.getBalance(accounts[0]);
          const balanceInEther = web3.utils.fromWei(balance, "ether");
          setBalance(balanceInEther);
          localStorage.setItem("MetaBalance", balanceInEther);
          // console.log(balanceInEther);
        } else {
          console.error("MetaMask not connected. Please connect your wallet.");
        }
      } else {
        console.error("MetaMask not installed.");
      }
    } catch (error) {
      console.error("Error connecting to MetaMask:", error.message);
    }
  };

  //  console.log(address, balance);
  const { handleSubmit, control, register, formState } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = (data) => {
    console.log(data);
  };

  const metaAdd = localStorage.getItem("MetaAddress") || "";
  const metaBal = localStorage.getItem("MetaBalance") || "";

  return (
    <>
      <Header />
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12 col-md-auto col-lg-auto pgCntC-lt "></div>
          <div class="col-sm-12 col-md-12 col-lg pgCntC-rt ">
            <div class="pgCntCon ">
              <div class="pade_padding_wrap ">
                <div class="InrPgHdrSec mb-4 ">
                  <h2>Profile</h2>
                </div>
                {/* buttons  */}
                <div class="HelpDskMain ">
                  <div class="AdTcktBtn d-flex flex-wrap ">
                    <Link
                      to={"/edit-profile"}
                      class="btn BtnPrimry Btn-148-40 mb-2 mr-2 "
                    >
                      Edit Profile
                    </Link>
                    <Link
                      to={"/change-password"}
                      class="btn BtnPrimry Btn-148-40 mb-2 "
                    >
                      Change Password
                    </Link>
                    <Link
                      to={"/kyc"}
                      class="btn BtnPrimry Btn-148-40 mb-2 ml-2"
                    >
                      KYC
                    </Link>

                    {metaAdd === "" ? (
                      <Link
                        onClick={connectWallet}
                        class="btn BtnPrimry Btn-148-40 mb-2 ml-2"
                      >
                        Connect Wallet
                      </Link>
                    ) : (
                      ""
                    )}
                  </div>
                </div>

                {/* metamask details  */}
                <div className="row">
                  <div className="col-lg-12 mx-auto">
                    <div class="MyWlltTbbBox mt-120">
                      <div class="prfimgcd">
                        <img
                          className="updatepro"
                          src={`http://localhost:8000/${user?.profilePic}`}
                          // src= "/static/images/proim.png"
                          alt=""
                          style={{
                            width: "110px",
                            height: "110px",
                            borderRadius: "50%",
                            marginTop: "25px",
                          }}
                        />
                      </div>
                      <div class="detscds">
                        <div class="row">
                          <div class="col-md-6 mb-4">
                            <div>
                              <h1>Wallet address</h1>
                              <h2>{metaAdd}</h2>
                            </div>
                          </div>

                          <div class="col-md-6 mb-4">
                            <div>
                              <h1>Balance</h1>
                              <h2>{metaBal} TBNB</h2>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* profile details  */}
                <div class="row">
                  <div class="col-lg-12 mx-auto">
                    <div class="MyWlltTbbBox mt-120">
                      {user ? (
                        <>
                          <div class="prfimgcd">
                            <img
                              className="updatepro"
                              src={`http://localhost:8000/${user?.profilePic}`}
                              // src= "/static/images/proim.png"
                              alt=""
                              style={{
                                width: "110px",
                                height: "110px",
                                borderRadius: "50%",
                                marginTop: "25px",
                              }}
                            />
                          </div>
                          <div class="detscds">
                            <div class="row">
                              <div class="col-md-6 mb-4">
                                <div>
                                  <h1>First Name</h1>
                                  <h2>{user.firstName}</h2>
                                </div>
                              </div>
                              <div class="col-md-6 mb-4 text-md-right">
                                <div>
                                  <h1>Last Name</h1>
                                  <h2> {user.lastName}</h2>
                                </div>
                              </div>
                              <div class="col-md-6 mb-4">
                                <div>
                                  <h1>Username</h1>
                                  <h2>{user.username}</h2>
                                </div>
                              </div>
                              <div class="col-md-6 mb-4 text-md-right">
                                <div>
                                  <h1>Email ID</h1>
                                  <h2>{user.email}</h2>
                                </div>
                              </div>
                              <div class="col-md-6 mb-4">
                                <div>
                                  <h1>Mobile</h1>
                                  <h2>
                                    {user.address ? user.address.mobile : "---"}
                                  </h2>
                                </div>
                              </div>
                              <div class="col-md-6 mb-4 text-md-right">
                                <div>
                                  <h1>Address Line 1</h1>
                                  <h2>
                                    {" "}
                                    {user.address
                                      ? user.address.addressLine1
                                      : "---"}
                                  </h2>
                                </div>
                              </div>
                              <div class="col-md-6 mb-4">
                                <div>
                                  <h1>Address Line 2</h1>
                                  <h2>
                                    {user.address
                                      ? user.address.addressLine1
                                      : "---"}
                                  </h2>
                                </div>
                              </div>
                              <div class="col-md-6 mb-4 text-md-right">
                                <div>
                                  <h1>Country</h1>
                                  <h2>
                                    {user.address
                                      ? user.address.country
                                      : "---"}
                                  </h2>
                                </div>
                              </div>
                            </div>{" "}
                          </div>
                        </>
                      ) : (
                        <p>Loading user data...</p>
                      )}

                      <Link
                        to={"/edit-profile"}
                        class="btn BtnPrimry fntsize Btn-182-44 m-auto"
                      >
                        Edit Profile
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              {/* footer  */}
              <footer>
                <div class="FtrSecMain ">
                  <div class="container ">
                    <div class="FtrCntMain text-center ">
                      <div class="FtrCpyRt ">
                        <div
                          dangerouslySetInnerHTML={{
                            __html: Copyrights?.editorData,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Profile;
