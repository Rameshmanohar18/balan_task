import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import { useForgotPasswordMutation } from "../redux/services/userApi";
import Swal from "sweetalert2";

const schema = Yup.object().shape({
  email: Yup.string().email("Invalid email").required("Email is required"),
});

const Forgot = () => {
  const location = useLocation();
  const [forgotPwd] = useForgotPasswordMutation();
  const navigate = useNavigate();
  const { resendOTPEmail } = location.state || {};
  console.log(resendOTPEmail);
  const {
    register,
    handleSubmit,
    formState: { errors },reset
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(()=>{
    if(resendOTPEmail){
      reset({"email": resendOTPEmail})
    }
  },[resendOTPEmail])

  const onSubmit = async (data) => {
    // Swal.fire("SweetAlert2 is working!");
    const res = await forgotPwd(data);
    
    if(res.error){
      toast.error(res?.error?.data.msg)
      reset()
      return
    }
    if(res.data){
      const otp = res?.data?.otp 
      Swal.fire({
        icon: "success",
        title: "OTP",
        text: `Your Otp is! ${otp}`,
        
      }).then(()=>{
        navigate(`/otp/${data.email}`, {
          state: {
            otp: otp,
          },
        });
      })
    }
    // console.log(res?.data?.msg);
    
    // console.log(otp);
  

  };

  return (
    <>
      <div class="LogInMainSec">
        <div class="LogInCntMain">
          <div class="container-fluid ">
            <div class="row align-items-center">
              <div class="col-lg-6 pl-0">
                <div class="LogInMainBg"></div>
              </div>
              <div class="col-lg-6 LgnFrmMain">
                <div class="LgnCntMain">
                  <div class="LgnCntSec">
                    <div class="LgnCntLogo mb-2">
                      <img
                        src="/static/images/logo.png"
                        alt=""
                        class="img-fluid"
                      />
                    </div>
                    <div class="LgnCntHdd mb-5">
                      <h2>
                        <span>Forget</span> Your password?
                      </h2>
                      <p>We’ll send you a link to reset your password</p>
                    </div>
                    <form
                      onSubmit={handleSubmit(onSubmit)}
                      className="CmmnLgnFrm"
                    >
                      <div className="form-group">
                        <label className="FrmLbl">Email</label>
                        <input
                          type="text"
                          className={`form-control ${
                            errors.email ? "is-invalid" : ""
                          }`}
                          placeholder="Enter your Email Id"
                          {...register("email")}
                        />
                        {errors.email && (
                          <div className="invalid-feedback">
                            {errors.email.message}
                          </div>
                        )}
                      </div>
                      <div className="mb-3 mt-5">
                        <button
                          type="submit"
                          className="btn BtnPrimry Btn-182-44 BtnInrpg"
                        >
                          Send
                        </button>
                      </div>
                      <div className="DntRgt">
                        <p>
                          Didn’t receive the OTP ?{" "}
                          <a className="" href="">
                            Resend OTP
                          </a>
                        </p>
                      </div>
                    </form>
                  </div>
                  <div class="InrCpyRtSec text-center">
                    <p>© 2023 BTSMART. All rights reserved.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Forgot;
