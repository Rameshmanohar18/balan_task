import React, { useEffect, useState } from "react";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import Header from "../Components/Header";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useGetSingleUserQuery } from "../redux/services/userApi";
import {
  useDeleteTicketMutation,
  useUpdateTicketByIdMutation,
  useGetTicketByIDQuery,
  useGetTicketRepliesQuery,
} from "../redux/services/ticketApi/ticketApi";
import Swal from "sweetalert2";

const schema = yup.object().shape({
  department: yup.string().required("Department is required"),
  type: yup.string().required("Type is required"),
  status: yup.string().required("Status is required"),
  subject: yup.string().required("Subject is required"),
  description: yup.string(),
  notify: yup.array(),
  upload: yup.mixed(),
});
const TicketDetails = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFileName, setSelectedFileName] = useState(null);
  const [modal, setModal] = useState(false);
  const params = useParams();
  const ticketId = params.id;
  const navigate = useNavigate();

  const [updateTicket] = useUpdateTicketByIdMutation();
  const [deleteTicket] = useDeleteTicketMutation();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
    setValue,
  } = useForm({
    resolver: yupResolver(schema),
  });

  //logged User

  const {
    data: user,
    isLoading: Loading,
    isError: error,
  } = useGetSingleUserQuery();

  const loggedUser = user?.data;

  //Single Ticket
  const { data, isLoading, isError } = useGetTicketByIDQuery({ id: ticketId });

  //Single Ticket
  const { data: replies, isLoading: loading } = useGetTicketRepliesQuery();
  // console.log(replies);

  const adminReplies = replies?.data.filter(
    (reply) => reply.ticketId == ticketId
  );
  // console.log(adminReplies);

  const ticket = data?.data;
  // console.log(ticket);
  const ticketUpload = ticket?.upload;
  //  console.log(ticketUpload);
  const slicedTicketUpload = ticketUpload?.slice(22);

  useEffect(() => {
    if (ticket) {
      reset({
        department: ticket?.department,
        type: ticket?.type,
        status: ticket?.status,
        subject: ticket?.subject,
        description: ticket?.description,
        notify: ticket?.notify?.split(","),
      });
    }
  }, [ticket, reset]);

  const toggle = () => setModal(!modal);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setSelectedFile(file);
    setValue("upload", file);
  };

  const onSubmit = async (data) => {
    const formData = new FormData();

    Object.keys(data).forEach((key) => {
      formData.append(key, data[key]);
    });

    // if (selectedFile) {
    //   formData.append("upload", selectedFile);
    // }
    const response = await updateTicket({
      updatedData: formData,
      id: ticketId,
    });

    setModal(!modal);
    reset();
    navigate("/ticket");
  };

  //Delete Ticket Functionality

  const handleDelete = async () => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Yes, delete it!",
    });

    if (result.isConfirmed) {
      try {
        const res = await deleteTicket(ticketId);
        if (res?.data) {
          Swal.fire({
            icon: "success",
            title: "Success!",
            text: "Ticket Deleted!",
          }).then(() => {
            navigate("/ticket");
          });
        }
      } catch (error) {
        console.error("Error deleting ticket:", error);
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "An error occurred while deleting the ticket.",
        });
      }
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <Header />

      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12 col-md-auto col-lg-auto pgCntC-lt "></div>
          <div class="col-sm-12 col-md-12 col-lg pgCntC-rt ">
            <div class="pgCntCon ">
              <div class="pade_padding_wrap ">
                <div class="InrPgHdrSec mb-4 ">
                  <h2>Ticket Details</h2>
                </div>
                <div class="MyWlltTbbBox">
                  <div class="TcktDtlsBx mb-3 UsrBox">
                    <div class="AdTcktBtn d-flex flex-wrap ">
                      <button
                        class="btn BtnPrimry Btn-148-40 mb-2 mr-2 "
                        type="button "
                        onClick={toggle}
                      >
                        Edit Details
                      </button>
                      <button
                        class="btn BtnPrimry Btn-148-40 mb-2 "
                        type="button "
                        onClick={handleDelete}
                      >
                        Delete
                      </button>
                    </div>
                    <div class="TcktDtlsCnt">
                      <p>Hi,</p>
                      <p>{ticket?.description}</p>
                    </div>
                  </div>
                  <div class="TcktDtlsBx AdmnBox">
                    <div class="TcktDtlsFlx">
                      <div class="TcktDtlsBxCnt">
                        <p>Admin</p>
                        <p>Hi {loggedUser?.username},</p>
                      </div>
                      <div class="TcktDtlsBxCnt"></div>
                    </div>
                    <div class="TcktDtlsCnt">
                      {/* <p
                        dangerouslySetInnerHTML={{
                          __html: ticket?.adminComment,
                        }}
                      ></p> */}
                      {adminReplies?.map((reply) => {
                        return (
                          <>
                            <div
                              className="rounded m-4 p-4"
                              style={{ border: "2px solid red" }}
                            >
                              {" "}
                              <span>Admin Res Date:</span>
                              <span>
                                <span>
                                  {" "}
                                  {reply?.repliedAt === null
                                    ? "--"
                                    : new Date(
                                        reply?.repliedAt
                                      ).toLocaleDateString()}
                                </span>
                                ({" "}
                                {reply?.repliedAt === null
                                  ? "--"
                                  : new Date(
                                      reply?.repliedAt
                                    ).toLocaleTimeString()}
                                )
                              </span>
                              <br />
                              <span className="text-warning mt-5">
                                Admin:
                              </span>{" "}
                              <i
                                dangerouslySetInnerHTML={{
                                  __html: reply?.adminComment,
                                }}
                              ></i>
                              <span className="text-danger">You:</span>{" "}
                              <i>{reply?.userComment}</i> <br />
                              
                              {reply?.userComment === "" ? (
                                <Link
                                  className="btn btn-info"
                                  to={`/userticketreply/${reply?._id}`}
                                >
                                  Reply
                                </Link>
                              ) : (
                                ""
                              )}
                              <br/>
                              
                              <span>Replied At:</span>
                              <span>
                                <span>
                                  {" "}
                                  {reply?.userRepliedAt === null
                                    ? "--"
                                    : new Date(
                                        reply?.repliedAt
                                      ).toLocaleDateString()}
                                </span>
                                ({" "}
                                {reply?.userRepliedAt === null
                                  ? "--"
                                  : new Date(
                                      reply?.userRepliedAt
                                    ).toLocaleTimeString()}
                                )
                              </span>
                              <hr style={{ color: "red" }} />
                            </div>
                          </>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
              <footer>
                <div class="FtrSecMain ">
                  <div class="container ">
                    <div class="FtrCntMain text-center ">
                      <div class="FtrCpyRt ">
                        <p>© 2023 Osiz Support. All rights reserved.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>

      <Modal
        isOpen={modal}
        toggle={toggle}
        modalClassName="CmmnMdl"
        className="modal-xl "
      >
        <ModalBody>
          <div class="MdlHdr BrdBttm pb-3 mb-3 ">
            <div class="StkMdlHdd ">
              <h4 class="mb-0 ">
                <span>Edit </span> Ticket
              </h4>
            </div>
            <div class="MdlClose ">
              <button class="btn btn-link p-0 " type="button " onClick={toggle}>
                <svg
                  xmlns="http://www.w3.org/2000/svg "
                  width="11 "
                  height="11 "
                  viewBox="0 0 11 11 "
                  fill="none "
                >
                  <path d="M1 1L10.5 10.5 " stroke="white " />
                  <path d="M1 10.5L10.5 1 " stroke="white " />
                </svg>
              </button>
            </div>
          </div>
          <form class="pt-3 pb-3 px-4 ">
            <div class="row ">
              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Department</h1>
                  <div className="form-group">
                    <select
                      className={`form-control ${
                        errors.department ? "is-invalid" : ""
                      }`}
                      {...register("department")}
                    >
                      <option value="">Select Department</option>
                      <option value="Support">Support</option>
                      <option value="Delivery">Delivery</option>
                      <option value="Purchase">Purchase</option>
                    </select>
                    {errors.department && (
                      <div className="invalid-feedback">
                        {errors.department.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Type</h1>
                  <div className="form-group">
                    <select
                      className={`form-control ${
                        errors.type ? "is-invalid" : ""
                      }`}
                      id="exampleFormControlSelect1"
                      {...register("type")}
                    >
                      <option value="">Select Type</option>
                      <option value="Request change">Request change</option>
                      <option value="Report support">Report support</option>
                      <option value="Ask a Question">Ask a Question</option>
                      <option value="Raise an issue">Raise an issue</option>
                    </select>
                    {errors.type && (
                      <div className="invalid-feedback">
                        {errors.type.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Status</h1>
                  <div className="form-group">
                    <select
                      className={`form-control ${
                        errors.status ? "is-invalid" : ""
                      }`}
                      id="exampleFormControlSelect1"
                      {...register("status")}
                    >
                      <option value="">Select Status</option>
                      <option value="New">New</option>
                      <option value="Open">Open</option>
                      <option value="Re-opened">Re-opened</option>
                      <option value="Resolved">Resolved</option>
                      <option value="Waiting">Waiting</option>
                      <option value="Closed">Closed</option>
                      <option value="Cancel">Cancel</option>
                      <option value="InProgress">InProgress</option>
                    </select>
                    {errors.status && (
                      <div className="invalid-feedback">
                        {errors.status.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>
                    Subject<span>*</span>
                  </h1>
                  <div className="form-group">
                    <input
                      type="text"
                      className={`form-control ${
                        errors.subject ? "is-invalid" : ""
                      }`}
                      placeholder="Please enter subject"
                      {...register("subject")}
                    />
                    {errors.subject && (
                      <div className="invalid-feedback">
                        {errors.subject.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-12">
                <div className="Frmstl mb-20">
                  <h1>Description</h1>
                  <div className="form-group">
                    <textarea
                      name="description"
                      id="description"
                      cols="30"
                      rows="10"
                      className={`form-control ${
                        errors.description ? "is-invalid" : ""
                      }`}
                      {...register("description")}
                    ></textarea>
                    {errors.description && (
                      <div className="invalid-feedback">
                        {errors.description.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Notify</h1>
                  <div className="row">
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck1"
                          {...register("notify")}
                          value="Delivery Manager"
                        />
                        <label htmlFor="chck1">Delivery Manager</label>
                      </div>
                    </div>
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck2"
                          {...register("notify")}
                          value="Designer Manager"
                        />
                        <label htmlFor="chck2">Designer Manager</label>
                      </div>
                    </div>
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck3"
                          {...register("notify")}
                          value="Inventory & Purchase"
                        />
                        <label htmlFor="chck3">Inventory & Purchase</label>
                      </div>
                    </div>
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck4"
                          {...register("notify")}
                          value="IT Admin Lead"
                        />
                        <label htmlFor="chck4">IT Admin Lead</label>
                      </div>
                    </div>
                  </div>
                  {errors.notify && (
                    <div className="invalid-feedback">
                      {errors.notify.message}
                    </div>
                  )}
                </div>
              </div>

              <div className="col-md-6">
                <div className="upareacd">
                  <h1>Upload</h1>
                  <div className="upareain1 p-3">
                    <div className="upareain2 text-center">
                      <div>
                        <img
                          className="img-fluid"
                          src="/static/images/upload.png"
                          alt=""
                        />
                      </div>

                      <h3>Upload Or Drop Drown Image</h3>

                      <div className="uploadimgs">
                        <div className="variants">
                          <div className="file">
                            <label htmlFor="upload">Choose File</label>
                            <input
                              id="upload"
                              type="file"
                              {...register("upload")}
                              onChange={handleFileChange}
                            />
                            {selectedFile ? (
                              <p className="selected-file">
                                {selectedFile.name}
                              </p>
                            ) : (
                              <p className="selected-file">
                                {slicedTicketUpload || "No file selected"}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {errors.upload && (
                    <div className="invalid-feedback">
                      {errors.upload.message}
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="mt-md-3 d-flex justify-content-center flex-wrap">
              <button
                className="btn BtnPrimry Btn-148-40 mr-2 mb-2"
                type="submit"
                onClick={handleSubmit(onSubmit)}
              >
                Save
              </button>
              <button
                className="btn BtnPrimry Btn-148-40 BtnScndry mr-2 mb-2"
                type="button"
                onClick={toggle}
              >
                Close
              </button>
            </div>
          </form>
        </ModalBody>
      </Modal>
    </>
  );
};
export default TicketDetails;
