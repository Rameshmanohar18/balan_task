import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useNavigate, Link } from "react-router-dom";
import {
  useLogInUserMutation,
  useGetContentQuery,
  useLoginOtpMutation,
} from "../redux/services/userApi";

import ReCAPTCHA from "react-google-recaptcha";
import OTPInput from "react-otp-input";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { toast } from "react-toastify";
import Swal from "sweetalert2";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";

const schema = yup.object().shape({
  username: yup
    .string()
    .required("User Name is required")
    .min(3, "Invalid UserName")
    .matches(/[A-Za-z]/, "Invalid UserName")
    .trim(),
  password: yup
    .string()
    .required("Password is required")
    .min(8, "Password must be at least 8 characters"),
});

const Login = () => {
  const [captchaValue, setCaptchaValue] = useState(null);
  const [modal, setModal] = useState(false);
  const [otp, setOtp] = useState("");
  const [randomOtp, setRandomOtp] = useState(null);
  const [userName, setUserName] = useState(null);
  const [otpAttempts, setOtpAttempts] = useState(0);
  const [showPassword, setShowPassword] = useState(false);

  const [logOtp] = useLoginOtpMutation();
  const [logUser] = useLogInUserMutation();

  const navigate = useNavigate();

  const { data, isLoading, isError } = useGetContentQuery();
  const contents = data?.data;
  const Copyrights = contents?.find(
    (content) => content.content === "copyrights"
  );
  // console.log(Copyrights.editorData);

  //OTP INPUT
  const renderInput = (props, index) => {
    return (
      <input
        key={index}
        {...props}
        style={{
          width: "40px",
          height: "40px",
          marginRight: "5px",
          textAlign: "center",
          backgroundColor: "gray",
        }}
      />
    );
  };

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    mode: "all",
  });

  //FORM SUBMIT
  const onSubmit = async (data) => {
    try {
      setUserName(data.username);
      let res = await logOtp({ ...data, captchaValue }).unwrap();
      toast.success(res.OTP);
      const OTP = res ? res.OTP : null;
      setRandomOtp(OTP);

      const alert = Swal.fire({
        position: "center",
        icon: "success",
        title: "OTP has been sent to your mail",
        showConfirmButton: false,
        timer: 2000,
      });

      if (alert) {
        setTimeout(() => {
          toggle();
        }, 2500);
      }
    } catch (error) {
      toast.error(error.data.message);
    }
  };

  const toggle = () => {
    setModal(!modal);
    setOtp("");
  };

  //OTP expiry Time
  useEffect(() => {
    const expireOtp = () => {
      setRandomOtp(null);
      setModal(false);
      toast.error("OTP expired. Please try again.");
      reset();
    };

    if (randomOtp !== null) {
      const otpExpirationTimeout = setTimeout(expireOtp, 30000);

      return () => clearTimeout(otpExpirationTimeout);
    }
  }, [randomOtp]);

  //OTP Verify
  const handleVerify = async () => {
    if (otp == randomOtp) {
      let res = await logUser({ username: userName }).unwrap();

      localStorage.setItem("LoggedUserToken", res.token);
      toast.success(res.message);
      setTimeout(() => {
        navigate("/dashboard");
      }, 2000);

      if (res.error) {
        toast.error(res.error);
        reset();
        return;
      } else {
        console.log("Login Success:", res);
      }

      setOtpAttempts(0);
      setOtp("");
      toggle();
      toast.success("OTP verified");
    } else {
      setOtpAttempts(otpAttempts + 1);

      if (otpAttempts >= 2) {
        toast.error(" Please try again.");
        setOtpAttempts(0);
        toggle();
        reset();
      } else {
        toast.error("Incorrect OTP! Try again");
      }
    }
  };

  const handleCancel = () => {
    // setOtpAttempts(0);

    toggle();
    reset();
    navigate("/register");
    toast.error("Login Cancelled!");
  };

  //PASSWORD VISIBILITY

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <>
      <div className="LogInMainSec">
        <div className="LogInCntMain">
          <div className="container-fluid ">
            <div className="row align-items-center">
              <div className="col-lg-6 pl-0">
                <div className="LogInMainBg"></div>
              </div>
              <div className="col-lg-6 LgnFrmMain">
                <div className="LgnCntMain">
                  <div className="LgnCntSec">
                    <div className="LgnCntLogo mb-2">
                      <img
                        src="/static/images/logo.png"
                        alt=""
                        className="img-fluid"
                      />
                    </div>
                    <div className="LgnCntHdd mb-5">
                      <h2>
                        <span>Welcome</span> Back !
                      </h2>
                      <p>Login your Account</p>
                    </div>
                    <form
                      onSubmit={handleSubmit(onSubmit)}
                      className="CmmnLgnFrm"
                    >
                      <div className="form-group">
                        <label className="FrmLbl">Username</label>
                        <input
                          type="text"
                          className={`form-control ${
                            errors.username ? "is-invalid" : ""
                          }`}
                          placeholder="Enter your Username"
                          {...register("username")}
                        />
                        <div className="invalid-feedback">
                          {errors.username?.message}
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="FrmLbl">Password</label>
                        <div className="input-group">
                          <input
                            type={showPassword ? "text" : "password"}
                            className={`form-control ${
                              errors.password ? "is-invalid" : ""
                            }`}
                            placeholder="Enter your Password"
                            {...register("password")}
                          />
                          <button
                            type="button"
                            className="input-group-text bg-secondary"
                            onClick={togglePasswordVisibility}
                            style={{
                              border: "none",
                              borderRadius: "none",
                              backgroundColor: "#A9A9A9",
                            }}
                          >
                            {showPassword ? (
                              <FontAwesomeIcon
                                icon={faEyeSlash}
                                style={{ color: "black" }}
                              />
                            ) : (
                              <FontAwesomeIcon
                                icon={faEye}
                                style={{ color: "black" }}
                              />
                            )}
                          </button>
                          <div className="invalid-feedback">
                            {errors.password?.message}
                          </div>
                        </div>
                      </div>

                      <div className="form-group">
                        <ReCAPTCHA
                          sitekey="6LfVIB4pAAAAALZAX_zTvLLy-4YwWiwRdqF1y5Zf"
                          onChange={(value) => setCaptchaValue(value)}
                        />
                      </div>

                      <div className="FrmFlxBetwn mb-5">
                        <div className="form-group CusCheck mb-0">
                          <input type="checkbox" id="chck1" />
                          <label htmlFor="chck1">Remember Me</label>
                        </div>
                        <div className="FrgtSec">
                          <Link to="/forgot" className="">
                            Forgot Password?
                          </Link>
                        </div>
                      </div>
                      <div className="mb-4">
                        <button
                          type="submit"
                          className="btn BtnPrimry Btn-182-44 BtnInrpg"
                        >
                          Login
                        </button>
                      </div>
                      <div className="DntRgt">
                        <p>
                          Don’t have an account?{" "}
                          <Link to={"/register"}>Register</Link>
                        </p>
                      </div>
                    </form>
                  </div>
                  <div className="InrCpyRtSec text-center">
                    <div
                      dangerouslySetInnerHTML={{
                        __html: Copyrights?.editorData,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      <Modal
        isOpen={modal}
        toggle={toggle}
        modalClassName="CmmnMdl"
        className="modal-md "
        backdrop="static"
      >
        <ModalBody>
          <div class="MdlHdr BrdBttm pb-3 mb-3 ">
            <div class="StkMdlHdd ">
              <h4 class="mb-0 ">
                <span>Verfiy </span> Your Mail
              </h4>
            </div>
          </div>
          <div className="modal-body">
            <OTPInput
              value={otp}
              onChange={(otp) => setOtp(otp)}
              numInputs={6}
              renderSeparator={
                <span
                  style={{
                    color: "gold",
                    marginRight: "5px",
                  }}
                >
                  -
                </span>
              }
              containerStyle={{ display: "flex", justifyContent: "center" }}
              renderInput={renderInput}
            />
          </div>
        </ModalBody>
        <div class="modal-footer">
          <Link
            onClick={handleCancel}
            className="btn BtnPrimry Btn-182-44 BtnInrpg me-3"
          >
            Cancel
          </Link>
          <button
            onClick={handleVerify}
            className="btn BtnPrimry Btn-182-44 BtnInrpg"
          >
            verify
          </button>
        </div>
      </Modal>
    </>
  );
};

export default Login;
