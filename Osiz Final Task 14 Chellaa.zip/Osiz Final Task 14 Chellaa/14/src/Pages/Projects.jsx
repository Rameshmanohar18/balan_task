import Header from "../Components/Header";
import {
  useGetProjectsQuery,
  useGetContentQuery,
} from "../redux/services/userApi";

const Projects = () => {
  const { data, isLoading } = useGetProjectsQuery();
  const projects = data?.data;
  // console.log(projects);

  const { data: cms, isLoading: loading, isError } = useGetContentQuery();
  const contents = cms?.data;
  const Copyrights = contents?.find(
    (content) => content.content === "copyrights"
  );

  const search = () => {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("table");
    tr = table.getElementsByTagName("tr");

    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[2];

      if (td) {
        txtValue = td.innerHTML || td.innerText;
        // console.log(txtValue[0]);
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  };

  return (
    <>
      <Header />

      <div class="container-fluid ">
        <div class="row ">
          <div class="col-sm-12 col-md-auto col-lg-auto pgCntC-lt "></div>
          <div class="col-sm-12 col-md-12 col-lg pgCntC-rt ">
            <div class="pgCntCon ">
              <div class="pade_padding_wrap ">
                <div class="InrPgHdrSec mb-4 ">
                  <h2>Projects</h2>
                </div>
                <div class="TransDtlsMain ">
                  <div class="TrnsTblHddSec ">
                    <div class="TrnsTblShow mb-2 ">
                      <span class="TrnsTblSlct ">
                        Showing
                        <select class="px-1 py-1 mx-2 ms-1 form-select ">
                          <option value=" ">01</option>
                          <option value=" ">02</option>
                          <option value=" ">03</option>
                        </select>
                        of {projects?.length} results
                      </span>
                    </div>
                    <div class="TrnsTblOPtn ">
                      <div class="SlctTknSrch ">
                        <div class="input-group mb-2 ">
                          <input
                            id="searchInput"
                            onKeyUp={search}
                            type="text "
                            class="form-control "
                            placeholder="Search Project"
                            aria-label="Search "
                            aria-describedby="addon2 "
                          />
                          <button
                            class="btn btn-link "
                            type="button "
                            id="addon2 "
                          >
                            <img
                              src="/static/images/search-icon1.svg "
                              class="img-fluid "
                              alt=" "
                            />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="TrnsTblMain table-responsive table-borderless mb-3 ">
                    <table class="table" id="table">
                      <thead>
                        <tr>
                          <th scope="col ">S.no</th>
                          <th scope="col ">Id</th>
                          <th scope="col ">Project Name</th>
                          <th scope="col ">Type</th>
                          <th scope="col ">Created By</th>
                          <th scope="col ">Created At</th>
                        </tr>
                      </thead>
                      <tbody>
                        {projects?.map((project, index) => (
                          <tr key={project._id}>
                            <td className="serial-no py-3">{index + 1}</td>
                            <td className="py-3">{project._id}</td>
                            <td className="py-3">{project.projectName}</td>
                            <td className="py-3">{project.type}</td>
                            <td className="py-3">{project.createdBy}</td>
                            <td className="py-3">
                              {" "}
                              <div>
                                {new Date(
                                  project.createdAt
                                ).toLocaleDateString()}
                              </div>
                              <div>
                                {new Date(
                                  project.createdAt
                                ).toLocaleTimeString()}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div class="TrnsTblHddSec ">
                    <div class="TrnsTblShow mb-2 ">
                      <span class="TrnsTblSlct ">
                        Showing <span> {projects?.length}</span> of
                        <span className="mx-1">{projects?.length}</span> entries
                      </span>
                    </div>
                    <div class="TrnsTblPgnt ">
                      <ul class="pagination ">
                        <li class="page-item ">
                          <a class="page-link " href="# ">
                            <span>
                              <svg
                                xmlns="http://www.w3.org/2000/svg "
                                width="6 "
                                height="11 "
                                viewBox="0 0 6 11 "
                                fill="none "
                              >
                                <path
                                  d="M5 10L1 5.5L5 1 "
                                  stroke="white "
                                  stroke-miterlimit="10 "
                                  stroke-linecap="round "
                                  stroke-linejoin="round "
                                />
                              </svg>
                            </span>
                          </a>
                        </li>
                        <li class="page-item ">
                          <a class="page-link " href="# ">
                            1
                          </a>
                        </li>
                        <li class="page-item ">
                          <a class="page-link " href="# ">
                            2
                          </a>
                        </li>
                        <li class="page-item ">
                          <a class="page-link " href="# ">
                            3
                          </a>
                        </li>
                        <li class="page-item ">
                          <a class="page-link " href="# ">
                            <span>
                              <svg
                                xmlns="http://www.w3.org/2000/svg "
                                width="6 "
                                height="11 "
                                viewBox="0 0 6 11 "
                                fill="none "
                              >
                                <path
                                  d="M1 10L5 5.5L1 1 "
                                  stroke="white "
                                  stroke-miterlimit="10 "
                                  stroke-linecap="round "
                                  stroke-linejoin="round "
                                />
                              </svg>
                            </span>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div
                  class="modal fade CmmnMdl "
                  tabindex="-1 "
                  role="dialog "
                  aria-labelledby="dialog-static-name "
                >
                  <div class="modal-dialog modal-dialog-centered modal-xl ">
                    <div class="modal-content ">
                      <div class="modal-body StkPlnMdlMain ">
                        <div class="MdlHdr BrdBttm pb-3 mb-3 ">
                          <div class="StkMdlHdd ">
                            <h4 class="mb-0 ">
                              <span>Add </span> Ticket
                            </h4>
                          </div>
                          <div class="MdlClose ">
                            <button class="btn btn-link p-0 " type="button ">
                              <svg
                                xmlns="http://www.w3.org/2000/svg "
                                width="11 "
                                height="11 "
                                viewBox="0 0 11 11 "
                                fill="none "
                              >
                                <path d="M1 1L10.5 10.5 " stroke="white " />
                                <path d="M1 10.5L10.5 1 " stroke="white " />
                              </svg>
                            </button>
                          </div>
                        </div>
                        <form class="pt-3 pb-3 ">
                          <div class="row ">
                            <div class="col-md-6 ">
                              <div class="Frmstl mb-20 ">
                                <h1>Name</h1>
                                <div class="form-group ">
                                  <input
                                    type="email "
                                    class="form-control "
                                    placeholder="Mariana James"
                                  />
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 ">
                              <div class="Frmstl mb-20 ">
                                <h1>Subject</h1>
                                <div class="form-group ">
                                  <select
                                    class="form-control "
                                    id="exampleFormControlSelect1 "
                                  >
                                    <option>Select</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 ">
                              <div class="Frmstl mb-20 ">
                                <h1>Transaction #</h1>
                                <div class="form-group ">
                                  <input
                                    type="email "
                                    class="form-control "
                                    placeholder="Enter your Transaction # "
                                  />
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 ">
                              <div class="Frmstl mb-20 ">
                                <h1>Date</h1>
                                <div class="form-group ">
                                  <select
                                    class="form-control "
                                    id="exampleFormControlSelect1 "
                                  >
                                    <option>DD / MM / YY</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 ">
                              <div class="Frmstl mb-20 ">
                                <h1>No of Coins #</h1>
                                <div class="form-group ">
                                  <input
                                    type="email "
                                    class="form-control "
                                    placeholder="Enter your Transaction # "
                                  />
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 "></div>
                            <div class="col-md-6 ">
                              <div class="Frmstl mb-20 ">
                                <h1>Type your message</h1>
                                <div class="form-group ">
                                  <textarea
                                    class="form-control "
                                    name=" "
                                    id=" "
                                    cols="30 "
                                    rows="8 "
                                    placeholder="Type your Message "
                                  ></textarea>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 ">
                              <div class="upareacd ">
                                <h1>Upload</h1>
                                <div class="upareain1 p-3 ">
                                  <div class=" upareain2 text-center ">
                                    <div>
                                      <img
                                        class="img-fluid "
                                        src="/static/images/profile/upload.png "
                                        alt=" "
                                      />
                                    </div>

                                    <h3>Upload Or Drop Drown Image</h3>

                                    <div class="uploadimgs ">
                                      <div class="variants ">
                                        <div class="file ">
                                          <label for="input-file ">
                                            Choose File
                                          </label>
                                          <input
                                            id="input-file "
                                            type="file "
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="mt-md-3 d-flex justify-content-center flex-wrap ">
                            <button
                              class="btn BtnPrimry Btn-148-40 mr-2 mb-2 "
                              type="button "
                            >
                              Submit
                            </button>
                            <button
                              class="btn BtnPrimry Btn-148-40 BtnScndry mr-2 mb-2 "
                              type="button "
                            >
                              Cancel
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <footer>
                <div class="FtrSecMain ">
                  <div class="container ">
                    <div class="FtrCntMain text-center ">
                      <div class="FtrCpyRt ">
                        <div
                          dangerouslySetInnerHTML={{
                            __html: Copyrights?.editorData,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Projects;


