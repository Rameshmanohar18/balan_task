import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link, useNavigate } from "react-router-dom";
import OTPInput from "react-otp-input";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { toast } from "react-toastify";
import Swal from "sweetalert2";
import {
  useAddUserMutation,
  useGetUsersQuery,
  useVerifiedUserMutation,
} from "../redux/services/userApi";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";

const validationSchema = yup.object().shape({
  firstName: yup
    .string()
    .required("First Name is required")
    .min(3, "First Name should be atleast 3 Characters")
    .matches(/[A-Za-z]+/, "First Name should contain only Alphabets"),
  lastName: yup
    .string()
    .required("Last Name is required")
    .min(3, "Last Name should be atleast 3 Characters")
    .matches(/[A-Za-z]+/, "Last Name should contain only Alphabets"),
  email: yup
    .string()
    .required("Email is required")
    .email("Email is invalid")
    .matches(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/, "enter valid email")
    .trim(),
  username: yup
    .string()
    .required("User Name is required")
    .min(3, "UserName should contain atleaset 3 characters")
    .matches(/[A-Za-z]/, "UserName should contain alphabets")
    .trim(),
  password: yup
    .string()
    .required("Password is required")
    .matches(/[A-Z]/, "Password Must Contain atlease One UpperCase Letter")
    .matches(/[0-9]/, "Password Must Contain atlease One Number")
    .matches(
      /[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/,
      "Password Must Contain atlease One Special Character.. like @#$"
    )
    .trim()
    .min(8, "Password must be at least 8 characters"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("password"), null], "Passwords doesnt match")
    .required("Confirm Password is required")
    .trim(),
  profilePic: yup
    .mixed()
    .test("fileRequired", "Profile Pic is Required", (value) => {
      return value && value.length > 0;
    })
    .test("fileSize", "File size is too large", (value) => {
      return value && value[0] && value[0].size <= 1024000;
    })
    .test("fileFormat", "Invalid file format", (value) => {
      return (
        value &&
        value.length > 0 &&
        ["image/jpeg", "image/png"].includes(value[0].type)
      );
    }),
  acceptTerms: yup.bool().oneOf([true], "Accept Ts & Cs is required"),
});

const Register = () => {
  const [modal, setModal] = useState(false);
  const [otp, setOtp] = useState("");
  const [randomOtp, setRandomOtp] = useState(null);
  const [otpAttempts, setOtpAttempts] = useState(0);
  const [datas, setDatas] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showCnfrmPassword, setShowCnfrmPassword] = useState(false);

  const [addUser] = useAddUserMutation();
  const [verifiedUser] = useVerifiedUserMutation();
  const { data: users = [], isLoading, isError } = useGetUsersQuery();
  // console.log(users.data);
  const usersFromDB = users.data || [];

  const navigate = useNavigate();

  const renderInput = (props, index) => {
    return (
      <input
        key={index}
        {...props}
        style={{
          width: "40px",
          height: "40px",
          marginRight: "5px",
          textAlign: "center",
          backgroundColor: "gray",
        }}
      />
    );
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "all",
  });

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    setSelectedFile(file);
  };

  const onSubmit = async (data) => {
    const emailExists = usersFromDB.some((user) => user.email == data.email);
    const userNameExists = usersFromDB.some(
      (user) => user.username == data.username
    );

    if (emailExists) {
      toast.error("Email is already registered!");
      return;
    }
    if (userNameExists) {
      toast.error("Username is already registered!");
      return;
    }

    setDatas(data);
    let res = await addUser(data.email);

    const OTP = res.data ? res.data.otp : null;
    toast.success(OTP);
    console.log(OTP);
    setRandomOtp(OTP);

    const alert = Swal.fire({
      position: "center",
      icon: "success",
      title: "OTP has been sent to your mail",
      showConfirmButton: false,
      timer: 2000,
    });

    if (alert) {
      setTimeout(() => {
        toggle();
      }, 2500);
    }
  };

  const toggle = () => {
    setModal(!modal);
    setOtp("");
  };

  //OTP expiry Time
  useEffect(() => {
    const expireOtp = () => {
      setRandomOtp(null);
      setModal(false);
      toast.error("OTP expired. Please try again.");
    };

    if (randomOtp !== null) {
      const otpExpirationTimeout = setTimeout(expireOtp, 30000);

      return () => clearTimeout(otpExpirationTimeout);
    }
  }, [randomOtp]);

  const handleVerify = async () => {
    if (otp == randomOtp) {
      const profileImageFile = datas.profilePic[0];
      const formData = new FormData();
      formData.append("firstName", datas.firstName);
      formData.append("lastName", datas.lastName);
      formData.append("email", datas.email);
      formData.append("username", datas.username);
      formData.append("password", datas.password);
      formData.append("confirmPassword", datas.confirmPassword);
      formData.append("acceptTerms", datas.acceptTerms);
      formData.append("profilePic", profileImageFile);

      let result = await verifiedUser(formData);

      if (result.error) {
        toast.error(result.error);
        return;
      } else {
        console.log("User added:", result);
      }

      setOtpAttempts(0);
      setDatas(null);
      setRandomOtp(null);
      setOtp("");
      toggle();
      reset();
      toast.success("OTP verified");

      Swal.fire("Registered Successfully!", "", "success");
      navigate("/register");
    } else {
      setOtpAttempts(otpAttempts + 1);

      if (otpAttempts >= 2) {
        toast.error("Registration failed. Please try again.");
        setRandomOtp(null);
        setOtpAttempts(0);
        toggle();
        reset();
      } else {
        toast.error("Incorrect OTP! Try again");
      }
    }
  };

  const handleCancel = () => {
    setOtpAttempts(0);
    setDatas(null);
    setRandomOtp(null);
    toggle();
    reset();
    navigate("/register");
    toast.error("Registration Canceled");
  };

  console.log(randomOtp);

  //PASSWORD VISIBILITY
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  //PASSWORD VISIBILITY
  const toggleCnfrmPasswordVisibility = () => {
    setShowCnfrmPassword(!showCnfrmPassword);
  };

  return (
    <>
      <div className="LogInMainSec">
        <div className="LogInCntMain">
          <div className="container-fluid ">
            <div className="row align-items-center">
              <div className="col-lg-5 pl-0">
                <div className="LogInMainBg"></div>
              </div>
              <div className="col-lg-7 LgnFrmMain RegFrmMain">
                <div className="Lgn">
                  <div className="LgnCntSec">
                    <div className="LgnCntLogo mb-2">
                      <img
                        src="/static/images/logo.png"
                        alt=""
                        className="img-fluid"
                      />
                    </div>
                    <div className="LgnCntHdd mb-5">
                      <h2>
                        <span>Welcome</span> Back !
                      </h2>
                      <p>Register your Account</p>
                    </div>
                    <form
                      onSubmit={handleSubmit(onSubmit)}
                      className="CmmnLgnFrm"
                    >
                      <div className="row">
                        <div className="col-lg-6">
                          <div className="form-group">
                            <label className="FrmLbl">First Name</label>
                            <input
                              name="firstName"
                              type="text"
                              {...register("firstName")}
                              className={`form-control ${
                                errors.firstName ? "is-invalid" : ""
                              }`}
                              placeholder="Enter your First Name"
                            />
                            {errors.firstName && (
                              <div className="invalid-feedback">
                                {errors.firstName.message}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="form-group">
                            <label className="FrmLbl">Last Name</label>
                            <input
                              name="lastName"
                              type="text"
                              {...register("lastName")}
                              className={`form-control ${
                                errors.lastName ? "is-invalid" : ""
                              }`}
                              placeholder="Enter your Last Name"
                            />
                            {errors.lastName && (
                              <div className="invalid-feedback">
                                {errors.lastName.message}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="form-group">
                            <label className="FrmLbl">Email</label>
                            <input
                              name="email"
                              type="text"
                              {...register("email")}
                              className={`form-control ${
                                errors.email ? "is-invalid" : ""
                              }`}
                              placeholder="Enter your Email"
                            />
                            {errors.email && (
                              <div className="invalid-feedback">
                                {errors.email.message}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="form-group">
                            <label className="FrmLbl">Username</label>
                            <input
                              name="username"
                              type="text"
                              {...register("username")}
                              className={`form-control ${
                                errors.username ? "is-invalid" : ""
                              }`}
                              placeholder="Enter your Username"
                            />
                            {errors.username && (
                              <div className="invalid-feedback">
                                {errors.username.message}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="form-group">
                            <label className="FrmLbl">Password</label>
                            <div className="input-group">
                              <input
                                name="password"
                                type={showPassword ? "text" : "password"}
                                {...register("password")}
                                className={`form-control ${
                                  errors.password ? "is-invalid" : ""
                                }`}
                                placeholder="Enter your Password"
                              />
                              <button
                                type="button"
                                className="input-group-text bg-secondary"
                                onClick={togglePasswordVisibility}
                                style={{
                                  border: "none",
                                  borderRadius: "none",
                                  backgroundColor: "#A9A9A9",
                                }}
                              >
                                {showPassword ? (
                                  <FontAwesomeIcon
                                    icon={faEyeSlash}
                                    style={{ color: "black" }}
                                  />
                                ) : (
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "black" }}
                                  />
                                )}
                              </button>
                              {errors.password && (
                                <div className="invalid-feedback">
                                  {errors.password.message}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="form-group">
                            <label className="FrmLbl">Confirm Password</label>
                            <div className="input-group">
                              <input
                                name="confirmPassword"
                                type={showCnfrmPassword ? "text" : "password"}
                                {...register("confirmPassword")}
                                className={`form-control ${
                                  errors.confirmPassword ? "is-invalid" : ""
                                }`}
                                placeholder="Enter your Confirm Password"
                              />
                              <button
                                type="button"
                                className="input-group-text bg-secondary"
                                onClick={toggleCnfrmPasswordVisibility}
                                style={{
                                  border: "none",
                                  borderRadius: "none",
                                  backgroundColor: "#A9A9A9",
                                }}
                              >
                                {showCnfrmPassword ? (
                                  <FontAwesomeIcon
                                    icon={faEyeSlash}
                                    style={{ color: "black" }}
                                  />
                                ) : (
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "black" }}
                                  />
                                )}
                              </button>
                              {errors.confirmPassword && (
                                <div className="invalid-feedback">
                                  {errors.confirmPassword.message}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Image Upload */}
                        <div className="col-lg-6">
                          <div className="form-group">
                            <label className="form-label">Profile </label>
                            <input
                              name="profilePic"
                              type="file"
                              onChange={handleImageUpload}
                              {...register("profilePic")}
                              className={`form-control ${
                                errors.profilePic ? "is-invalid" : ""
                              }`}
                            />
                            <div className="invalid-feedback">
                              {errors.profilePic?.message}
                            </div>
                            {selectedFile && (
                              <p>
                                Selected file: {selectedFile.name} (
                                {selectedFile.type})
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="FrmFlxBetwn mb-5">
                        <div className="form-check mb-0">
                          <input
                            name="acceptTerms"
                            type="checkbox"
                            {...register("acceptTerms")}
                            className={`form-check-input ${
                              errors.acceptTerms ? "is-invalid" : ""
                            }`}
                            id="acceptTermsCheckbox"
                          />
                          <label
                            className="form-check-label"
                            htmlFor="acceptTermsCheckbox"
                          >
                            I agree to the conditions of Use and privacy notice.
                          </label>
                          <div className="invalid-feedback">
                            {errors.acceptTerms?.message}
                          </div>
                        </div>
                      </div>

                      <div className="mb-4">
                        <button
                          type="submit"
                          className="btn BtnPrimry Btn-182-44 BtnInrpg"
                        >
                          Register
                        </button>
                      </div>
                      <div className="DntRgt">
                        <p>
                          Already have an account? <Link to={"/"}>Login</Link>
                        </p>
                      </div>
                    </form>
                  </div>
                  <div className="InrCpyRtSec text-center">
                    <p>© 2023 Osiz. All rights reserved.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      <Modal
        isOpen={modal}
        toggle={toggle}
        modalClassName="CmmnMdl"
        className="modal-md "
        backdrop="static"
      >
        <ModalBody>
          <div class="MdlHdr BrdBttm pb-3 mb-3 ">
            <div class="StkMdlHdd ">
              <h4 class="mb-0 ">
                <span>Verfiy </span> Your Mail
              </h4>
            </div>
          </div>
          <div className="modal-body">
            <OTPInput
              value={otp}
              onChange={(otp) => setOtp(otp)}
              numInputs={6}
              renderSeparator={
                <span
                  style={{
                    color: "gold",
                    marginRight: "5px",
                  }}
                >
                  -
                </span>
              }
              containerStyle={{ display: "flex", justifyContent: "center" }}
              renderInput={renderInput}
            />
          </div>
        </ModalBody>
        <div class="modal-footer">
          <Link
            onClick={handleCancel}
            className="btn BtnPrimry Btn-182-44 BtnInrpg me-3"
          >
            Cancel
          </Link>
          <button
            onClick={handleVerify}
            className="btn BtnPrimry Btn-182-44 BtnInrpg"
          >
            verify
          </button>
        </div>
      </Modal>
    </>
  );
};

export default Register;
