import React, { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import Header from "../Components/Header";
import { Link, useNavigate } from "react-router-dom";
import {
  useGetSingleUserQuery,
  useGetContentQuery,
} from "../redux/services/userApi";
import {
  useGetReportsQuery,
  useAddReportMutation,
  useDeleteReportMutation,
  useAddReplyMutation
} from "../redux/services/reportApi/reportApi";
import { toast } from "react-toastify";
import Swal from "sweetalert2";

const schema = yup.object().shape({
  department: yup.string().required("Department is required"),
  type: yup.string().required("Type is required"),
  status: yup.string().required("Status is required"),
  subject: yup.string().required("Subject is required"),
  description: yup.string(),
  notify: yup.array(),
  file: yup.mixed(),
});

const Reports = () => {
  const [modal, setModal] = useState(false);
  const [adminCommentModal, setAdminCommentModal] = useState(false);

  const [selectedAdminComment, setSelectedAdminComment] = useState("");

  const [selectedFile, setSelectedFile] = useState(null);
  const navigate = useNavigate();

  const [addReport] = useAddReportMutation();
  const [deleteReport] = useDeleteReportMutation();

  const { data, isLoading } = useGetSingleUserQuery();
  const user = data?.data;

  const userID = user?._id;
  // console.log(userID);

  const { data: allReports, isLoading: loading } = useGetReportsQuery();
  const reportsfromDB = allReports?.data;
  // console.log(reportsfromDB);

  const reports = reportsfromDB?.filter(
    (report) => report?.createdBy === userID
  );
  // console.log(reports);

  const { data: cms, isLoading: buffering, isError } = useGetContentQuery();
  const contents = cms?.data;
  const Copyrights = contents?.find(
    (content) => content.content === "copyrights"
  );


  const toggle = () => {
    if (user.kyc.isApproved === false) {
      toast.error("Please Check Your KYC Status!");
    } else {
      setModal(!modal);
    }
    // setModal(!modal);
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
  } = useForm({
    resolver: yupResolver(schema),
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setSelectedFile(file);
    setValue("upload", file);
  };

  const onSubmit = async (data) => {
    const formData = new FormData();
    Object.keys(data).forEach((key) => {
      formData.append(key, data[key]);
    });
    const response = await addReport({ userId: userID, formData });

    if (response.data) {
      Swal.fire({
        icon: "success",
        title: "Success!",
        text: "New Report Added!",
      }).then(() => {
        setModal(!modal);
        setSelectedFile(null);
        reset();
        setModal(!modal);
      });
    } else if (response.error) {
      Swal.fire({
        icon: "error",
        title: "Error!",
        text: response?.error?.data?.error,
      });
    }
  };

  if (isLoading) {
    return <h5>Loadingg...</h5>;
  }

  //Search Input
  const search = () => {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("table");
    tr = table.getElementsByTagName("tr");

    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[3];

      if (td) {
        txtValue = td.innerHTML || td.innerText;
        // console.log(txtValue[0]);
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  };

  return (
    <>
      <Header />

      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12 col-md-auto col-lg-auto pgCntC-lt "></div>
          <div class="col-sm-12 col-md-12 col-lg pgCntC-rt ">
            <div class="pgCntCon ">
              <div class="pade_padding_wrap ">
                <div class="InrPgHdrSec mb-4 ">
                  <h2>Reports</h2>
                </div>
                <div class="HelpDskMain ">
                  <div class="AdTcktBtn d-flex flex-wrap ">
                    <button
                      class="btn BtnPrimry Btn-148-40 mb-2 mr-2 "
                      type="button"
                      onClick={toggle}
                    >
                      Add Report
                    </button>
                  </div>
                </div>
                <div class="TransDtlsMain ">
                  <div class="TrnsTblHddSec ">
                    <div class="TrnsTblShow mb-2 ">
                      <span class="TrnsTblSlct ">
                        Showing
                        <select class="px-1 py-1 mx-2 ms-1 form-select ">
                          <option value=" ">01</option>
                          <option value=" ">02</option>
                          <option value=" ">03</option>
                        </select>
                        of 21 results
                      </span>
                    </div>
                    <div class="TrnsTblOPtn ">
                      <div class="SlctTknSrch ">
                        <div class="input-group mb-2 ">
                          <input
                            id="searchInput"
                            onKeyUp={search}
                            type="text "
                            class="form-control "
                            placeholder="Search "
                            aria-label="Search "
                            aria-describedby="addon2 "
                          />
                          <button
                            class="btn btn-link "
                            type="button "
                            id="addon2 "
                          >
                            <img
                              src="/static/images/search-icon1.svg "
                              class="img-fluid "
                              alt=" "
                            />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="TrnsTblMain table-responsive table-borderless mb-3 ">
                    <table class="table " id="table">
                      <thead>
                        <tr>
                          <th scope="col ">S.no</th>
                          <th scope="col "> Report Id</th>

                          <th scope="col ">Type</th>
                          <th scope="col ">Description</th>
                          <th scope="col ">Created By</th>
                          {/* <th scope="col ">Created At</th> */}
                          <th scope="col ">Admin Reply</th>

                          <th scope="col ">Reply</th>
                          <th scope="col ">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {reports ? (
                          reports.length > 0 ? (
                            reports?.map((report, index) => (
                              <tr key={report._id}>
                                <td>{index + 1}</td>
                                <td>{report._id}</td>
                                <td>{report.status}</td>
                                <td>{report.description}</td>
                                {/* <td>{report.createdBy}</td> */}

                                <td>
                                  <div>
                                    {new Date(
                                      report.createdAt
                                    ).toLocaleDateString()}
                                  </div>
                                  <div>
                                    {new Date(
                                      report.createdAt
                                    ).toLocaleTimeString()}
                                  </div>
                                </td>

                                <td>
                                  {report.adminReplyStatus ? (
                                    <button
                                      class="btn btn-primary position-relative"
                                      onClick={() => {
                                        setSelectedAdminComment(
                                          report.adminComment
                                        );
                                        setAdminCommentModal(true);
                                      }}
                                    >
                                      View
                                      {report.adminReplyStatus ? (
                                        <>
                                          {" "}
                                          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                            1
                                            <span class="visually-hidden m-1">
                                              New
                                            </span>
                                          </span>
                                        </>
                                      ) : (
                                        ""
                                      )}
                                    </button>
                                  ) : (
                                    "no Messages to show"
                                  )}
                                </td>
                                <td>
                                  {report.adminComment === "" ? (
                                    "No messages to reply"
                                  ) : (
                                    <button
                                      className="btn btn-info"
                                      onClick={() =>
                                        navigate(`/userreply/${report?._id}`)
                                      }
                                    >
                                      Reply
                                    </button>
                                  )}
                                </td>
                                <td>
                                  <button
                                    className="btn btn-warning"
                                    onClick={async () => {
                                      const result = await Swal.fire({
                                        title: "Are you sure?",
                                        text: "You won't be able to revert this!",
                                        icon: "warning",
                                        showCancelButton: true,
                                        confirmButtonText: "Yes, delete it!",
                                        cancelButtonText: "No, cancel!",
                                      });

                                      if (result.isConfirmed) {
                                        const res = await deleteReport({
                                          reportId: report?._id,
                                        });

                                        if (res.data && res.data.message) {
                                          Swal.fire({
                                            title: "Deleted!",
                                            text: "Your report has been deleted.",
                                            icon: "success",
                                          });

                                          navigate("/reports");
                                        } else {
                                          Swal.fire({
                                            title: "Error!",
                                            text: "Failed to delete the report.",
                                            icon: "error",
                                          });
                                        }
                                      }
                                    }}
                                  >
                                    Delete
                                  </button>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan="7" className="text-center">
                                No Reports found.
                              </td>
                            </tr>
                          )
                        ) : (
                          <tr>
                            <td colSpan="7" className="text-center">
                              Loading...
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <footer>
                <div class="FtrSecMain ">
                  <div class="container ">
                    <div class="FtrCntMain text-center ">
                      <div class="FtrCpyRt ">
                        <div
                          dangerouslySetInnerHTML={{
                            __html: Copyrights?.editorData,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>

      {/* add report form  */}
      <Modal
        isOpen={modal}
        toggle={toggle}
        modalClassName="CmmnMdl"
        className="modal-xl "
      >
        <ModalBody>
          <div class="MdlHdr BrdBttm pb-3 mb-3 ">
            <div class="StkMdlHdd ">
              <h4 class="mb-0 ">
                <span>Add </span> Report
              </h4>
            </div>
            <div class="MdlClose ">
              <button class="btn btn-link p-0 " type="button " onClick={toggle}>
                <svg
                  xmlns="http://www.w3.org/2000/svg "
                  width="11 "
                  height="11 "
                  viewBox="0 0 11 11 "
                  fill="none "
                >
                  <path d="M1 1L10.5 10.5 " stroke="white " />
                  <path d="M1 10.5L10.5 1 " stroke="white " />
                </svg>
              </button>
            </div>
          </div>
          <form class="pt-3 pb-3 px-4 ">
            <div class="row ">
              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Department</h1>
                  <div className="form-group">
                    <select
                      className={`form-control ${
                        errors.department ? "is-invalid" : ""
                      }`}
                      {...register("department")}
                    >
                      <option value="">Select Department</option>
                      <option value="Support">Support</option>
                      <option value="Delivery">Delivery</option>
                      <option value="Purchase">Purchase</option>
                    </select>
                    {errors.department && (
                      <div className="invalid-feedback">
                        {errors.department.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Type</h1>
                  <div className="form-group">
                    <select
                      className={`form-control ${
                        errors.type ? "is-invalid" : ""
                      }`}
                      id="exampleFormControlSelect1"
                      {...register("type")}
                    >
                      <option value="">Select Type</option>
                      <option value="Request change">Request change</option>
                      <option value="Report support">Report support</option>
                      <option value="Ask a Question">Ask a Question</option>
                      <option value="Raise an issue">Raise an issue</option>
                    </select>
                    {errors.type && (
                      <div className="invalid-feedback">
                        {errors.type.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Status</h1>
                  <div className="form-group">
                    <select
                      className={`form-control ${
                        errors.status ? "is-invalid" : ""
                      }`}
                      id="exampleFormControlSelect1"
                      {...register("status")}
                    >
                      <option value="">Select Status</option>
                      <option value="New">New</option>
                      <option value="Open">Open</option>
                      <option value="Re-opened">Re-opened</option>
                      <option value="Resolved">Resolved</option>
                      <option value="Waiting">Waiting</option>
                      <option value="Closed">Closed</option>
                      <option value="Cancel">Cancel</option>
                    </select>
                    {errors.status && (
                      <div className="invalid-feedback">
                        {errors.status.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>
                    Subject<span>*</span>
                  </h1>
                  <div className="form-group">
                    <input
                      type="text"
                      className={`form-control ${
                        errors.subject ? "is-invalid" : ""
                      }`}
                      placeholder="Please enter subject"
                      {...register("subject")}
                    />
                    {errors.subject && (
                      <div className="invalid-feedback">
                        {errors.subject.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-12">
                <div className="Frmstl mb-20">
                  <h1>Description</h1>
                  <div className="form-group">
                    <textarea
                      name="description"
                      id="description"
                      cols="30"
                      rows="10"
                      className={`form-control ${
                        errors.description ? "is-invalid" : ""
                      }`}
                      {...register("description")}
                    ></textarea>
                    {errors.description && (
                      <div className="invalid-feedback">
                        {errors.description.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <div className="Frmstl mb-20">
                  <h1>Notify</h1>
                  <div className="row">
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck1"
                          {...register("notify")}
                          value="Delivery Manager"
                        />
                        <label htmlFor="chck1">Delivery Manager</label>
                      </div>
                    </div>
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck2"
                          {...register("notify")}
                          value="Designer Manager"
                        />
                        <label htmlFor="chck2">Designer Manager</label>
                      </div>
                    </div>
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck3"
                          {...register("notify")}
                          value="Inventory & Purchase"
                        />
                        <label htmlFor="chck3">Inventory & Purchase</label>
                      </div>
                    </div>
                    <div className="col-sm-6 mb-3">
                      <div className="form-group CusCheck mb-0">
                        <input
                          type="checkbox"
                          id="chck4"
                          {...register("notify")}
                          value="IT Admin Lead"
                        />
                        <label htmlFor="chck4">IT Admin Lead</label>
                      </div>
                    </div>
                  </div>
                  {errors.notify && (
                    <div className="invalid-feedback">
                      {errors.notify.message}
                    </div>
                  )}
                </div>
              </div>

              <div className="col-md-6">
                <div className="upareacd">
                  <h1>Upload</h1>
                  <div className="upareain1 p-3">
                    <div className="upareain2 text-center">
                      <div>
                        <img
                          className="img-fluid"
                          src="/static/images/upload.png"
                          alt=""
                        />
                      </div>

                      <h3>Upload Or Drop Drown Image</h3>

                      <div className="uploadimgs">
                        <div className="variants">
                          <div className="file">
                            <label htmlFor="upload">Choose File</label>
                            <input
                              id="upload"
                              type="file"
                              {...register("upload")}
                              onChange={handleFileChange}
                            />
                            {selectedFile && (
                              <p className="selected-file">
                                {selectedFile.name}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {errors.upload && (
                    <div className="invalid-feedback">
                      {errors.upload.message}
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="mt-md-3 d-flex justify-content-center flex-wrap">
              <button
                className="btn BtnPrimry Btn-148-40 mr-2 mb-2"
                type="submit"
                onClick={handleSubmit(onSubmit)}
              >
                Save
              </button>
              <button
                className="btn BtnPrimry Btn-148-40 BtnScndry mr-2 mb-2"
                type="button"
                onClick={toggle}
              >
                Close
              </button>
            </div>
          </form>
        </ModalBody>
      </Modal>

      {/* admin modal  */}
      <Modal
        isOpen={adminCommentModal}
        toggle={() => setAdminCommentModal(!adminCommentModal)}
        modalClassName="CmmnMdl"
        className="modal-sm"
      >
        <ModalHeader>
          <div className="d-flex justify-content-evenly align-items-center">
            <div>
              {" "}
              <span>Admin Comment</span>
            </div>

            <div
              className="MdlClose"
              style={{ marginLeft: "60px", marginBottom: "25px" }}
            >
              <button
                className="btn btn-link"
                type="button"
                onClick={() => setAdminCommentModal(!adminCommentModal)}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="11"
                  height="11"
                  viewBox="0 0 11 11"
                  fill="none"
                >
                  <path d="M1 1L10.5 10.5" stroke="white" />
                  <path d="M1 10.5L10.5 1" stroke="white" />
                </svg>
              </button>
            </div>
          </div>
        </ModalHeader>
        <ModalBody>
          <div dangerouslySetInnerHTML={{ __html: selectedAdminComment }}></div>
        </ModalBody>
        <ModalFooter>
          <Button
            className="btn BtnPrimry Btn-148-40 BtnScndry mr-2 mb-2"
            type="button"
            onClick={() => setAdminCommentModal(!adminCommentModal)}
          >
            OK
          </Button>
        </ModalFooter>
      </Modal>
    </>
  );
};
export default Reports;
