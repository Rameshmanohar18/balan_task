
import { configureStore } from "@reduxjs/toolkit";
import { usersApi } from "./services/userApi";
import { ticketApi } from "./services/ticketApi/ticketApi";
import { reportApi } from "./services/reportApi/reportApi";

const store = configureStore({
  reducer: {
    [usersApi.reducerPath]: usersApi.reducer,
    [ticketApi.reducerPath]: ticketApi.reducer,
    [reportApi.reducerPath]: reportApi.reducer,
  
  },
 
    middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(usersApi.middleware, ticketApi.middleware, reportApi.middleware),
   
});

export default store;