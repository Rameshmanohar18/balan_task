// reportApi.js
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const reportApi = createApi({
  reducerPath: "reportApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  endpoints: (builder) => ({
    getReports: builder.query({
      query: () => `users/getreports`,
      providesTags: (result, error, userId) => [{ type: "Report" }],
    }),

    addReport: builder.mutation({
      query: ({ userId, formData }) => ({
        url: `users/reports/${userId}`,
        method: "POST",
        body: formData,
      }),
      providesTags: (result, error, { userId }) => [{ type: "Report", userId }],
      invalidatesTags: ["Report"],
    }),

    deleteReport: builder.mutation({
      query: ({ reportId }) => ({
        url: `users/deletereport/${reportId}`,
        method: "DELETE",
      }),
      providesTags: (result, error, { reportId }) => [
        { type: "Report", reportId },
      ],
      invalidatesTags: ["Report"],
    }),

    addReply: builder.mutation({
      query: ({ reportId, replyData }) => ({
        url: `users/addreply/${reportId}`,
        method: "POST",
        body: {replyData},
      }),
      providesTags: (result, error, { reportId }) => [{ type: "Report", reportId }],
      invalidatesTags: ["Report"],
    }),

  }),
});

export const {
  useGetReportsQuery,
  useAddReportMutation,
  useDeleteReportMutation,
  useAddReplyMutation,

} = reportApi;
