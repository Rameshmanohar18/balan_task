// ticketApi.js
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const ticketApi = createApi({
  reducerPath: "ticketApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  endpoints: (builder) => ({
    getTickets: builder.query({
      query: () => `users/gettickets`,
      providesTags: (result) => (result ? [{ type: "Ticket", id: "all" }] : []),
      invalidatesTags: ["Ticket"],
    }),
    addTicket: builder.mutation({
      query: ({ userId, formData }) => ({
        url: `users/tickets/${userId}`,
        method: "POST",
        body: formData,
      }),
      providesTags: (result, error, { userId }) => [{ type: "Ticket", userId }],
      invalidatesTags: ["Ticket"],
    }),
    updateTicketById: builder.mutation({
      query: ({ id, updatedData }) => ({
        url: `users/updateticket/${id}`,
        method: 'POST',
        body: updatedData,
      }),
      providesTags: (result, error, { id }) => [{ type: "Ticket", id }],
      invalidatesTags: ["Ticket"],
   
    }),
    getTicketByID: builder.query({
      query: ({ id }) => ({
        url: `users/getticketbyid/${id}`,
        method: "GET",
      }),
      providesTags: (result, error, { id }) =>
        result ? [{ type: "Ticket", id }] : [],
      invalidatesTags: [{ type: "Ticket" }],
  
    }),
    deleteTicket: builder.mutation({
      query: (ticketId) => ({
        url: `users/deleteticket/${ticketId}`,
        method: "DELETE",
      }),
      providesTags: (result, error, { ticketId }) => [
        { type: "Ticket", ticketId },
      ],
      invalidatesTags: ["Ticket"],
    }),
    getTicketReplies: builder.query({
      query: () => `users/getticketreplies`,
      providesTags: (result) => (result ? [{ type: "Ticket", id: "all" }] : []),
      invalidatesTags: ["Ticket"],
    }),
    updateReplyId: builder.mutation({
      query: ({ id, replyData }) => ({
        url: `users/updateuserReply/${id}`,
        method: 'POST',
        body: {replyData},
      }),
      providesTags: (result, error, { id }) => [{ type: "Ticket", id }],
      invalidatesTags: ["Ticket"],
   
    }),
  }),
});

export const {
  useGetTicketsQuery,
  useAddTicketMutation,
 useUpdateTicketByIdMutation,
  useDeleteTicketMutation,
  useGetTicketByIDQuery,
  useGetTicketRepliesQuery,
  useUpdateReplyIdMutation
} = ticketApi;
