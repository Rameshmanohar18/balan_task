import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const getToken = () => {
  return localStorage.getItem("LoggedUserToken");
};

export const usersApi = createApi({
  reducerPath: "usersApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  endpoints: (builder) => ({
    getUsers: builder.query({
      query: () => "users",
      providesTags: ["User"],
   
    }),
    // getUser: builder.query({
    //   query: (id) => `users/fetchuser/${id}`,
    // }),
    loginOtp: builder.mutation({
      query: (user) => ({
        url: "users/loginOtp",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["User"],
    }),
    logInUser: builder.mutation({
      query: (data) => ({
        url: "users/login",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["User"],
    }),
    getSingleUser: builder.query({
      query: () => ({
        url: `users/getSingle`,
        headers: {
          Authorization: `Bearer ${getToken()}`,
        },
      }),
      providesTags: ["User"],
    }),
    deleteUser: builder.mutation({
      query: (userId) => ({
        url: `users/deleteuser/${userId}`,
        method: "DELETE",
      }),
      invalidatesTags: ["User"],
    }),
    addUser: builder.mutation({
      query: (user) => ({
        url: "users",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["User"],
    }),
    verifiedUser: builder.mutation({
      query: (user) => ({
        url: "users/verifiedUser",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["User"],
    }),
  
    updateUser: builder.mutation({
      query: ({ userId, formData }) => ({
        url: `users/updateuser/${userId}`,
        method: "PUT",
        body: formData,
      }),
      invalidatesTags: ["User"],
    }),
    forgotPassword: builder.mutation({
      query: (user) => ({
        url: "users/forgetPwd",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["User"],
    }),
    
    setNewPassword: builder.mutation({
      query: (user) => ({
        url: "users/setNewPwd",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["User"],
    }),

    changeNewPassword: builder.mutation({
      query: (user) => ({
        url: "users/changeNewPwd",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["User"],
    }),
  
    kycDetails: builder.mutation({
      query: ({ userId, userWithId }) => ({
        url: `users/kyc/${userId}`, 
        method: "POST",
        body: userWithId,
      }),
      invalidatesTags: ["User"],
    }),



    //Report Endpoints
    // reportDetails: builder.mutation({
    //   query: ({ userId, formData }) => ({
    //     url: `users/reports/${userId}`, 
    //     method: "POST",
    //     body: formData,
    //   }),
    //   invalidatesTags: ["User"],
    // }),

    // deleteReport: builder.mutation({
    //   query: ({reportId, username}) => ({
    //     url: `users/deletereport/${reportId}`,
    //     method: "DELETE",
    //     body:{username}
    //   }),
    //   invalidatesTags: ["User"],
    // }),

    //project
    getProjects: builder.query({
      query: () => 'admin/getprojects',
      providesTags: ['User'],
    }),

    //get Contents
    getContent: builder.query({
      query: () => 'admin/getcontents',
      providesTags: ['User'],
    }),

  
  }),
});


export const {
  useGetSingleUserQuery,
  useGetUsersQuery,
  useGetUserQuery,
  useAddUserMutation,
  useDeleteUserMutation,
  useUpdateUserMutation,
  useLogInUserMutation,
  useForgotPasswordMutation,
  useKycDetailsMutation,
  useVerifiedUserMutation,
  useSetNewPasswordMutation,
  useLoginOtpMutation,

  useChangeNewPasswordMutation,


  useGetProjectsQuery,
  useGetContentQuery
} = usersApi;
